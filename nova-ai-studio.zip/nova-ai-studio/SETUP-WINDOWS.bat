@echo off
echo ============================================
echo  NOVA AI STUDIO - Windows Setup
echo ============================================
echo.
echo [1/5] Checking Node.js...
node --version >nul 2>&1
if errorlevel 1 (
  echo ERROR: Node.js nahi mila! Pehle https://nodejs.org se Node.js 20+ install karo.
  pause
  exit /b 1
)
node --version
echo.
echo [2/5] Installing dependencies (2-4 min lag sakte hain)...
call npm install --no-audit --no-fund
if errorlevel 1 (
  echo ERROR: npm install fail ho gaya.
  pause
  exit /b 1
)
echo.
echo [3/5] Setting up .env file...
if not exist .env (
  copy .env.example .env
  echo .env ban gaya! Isko Notepad me kholo aur DATABASE_URL set karo.
) else (
  echo .env pehle se mojood hai.
)
echo.
echo [4/5] Database migrate karna...
echo NOTE: Pehle DATABASE_URL .env me set karo (Neon/Supabase free Postgres use kar sakte ho)
echo Phir ye command chalao: npx prisma migrate dev
echo.
echo [5/5] Done! App chalane ke liye: npm run dev
echo Phir browser me kholo: http://localhost:3000
echo.
pause
