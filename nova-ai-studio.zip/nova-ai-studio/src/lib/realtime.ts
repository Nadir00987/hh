// ─── Realtime event bus ─────────────────────────────────────────────────────
// Generation status changes are published here; the SSE route
// (/api/generations/[id]/events) subscribes and streams to the browser.
// Redis pub/sub when REDIS_URL is set (multi-instance), otherwise an
// in-process emitter (single instance — dev default, clearly documented).

import { EventEmitter } from "events";
import { getEnv } from "./env";

export interface GenerationUpdate {
  status: string;
  progress?: number | null;
  errorCode?: string | null;
  errorMessage?: string;
  outputAssetId?: string;
}

const local = new EventEmitter();
local.setMaxListeners(1000);

let redisPub: { publish(c: string, m: string): Promise<unknown> } | null = null;
let redisSub: {
  subscribe(c: string): Promise<unknown>;
  on(e: string, cb: (channel: string, message: string) => void): void;
} | null = null;
let redisReady = false;

async function ensureRedis() {
  if (redisReady) return;
  const { REDIS_URL } = getEnv();
  if (!REDIS_URL) return;
  try {
    // Lazy import so the app boots without ioredis installed/configured.
    const { default: Redis } = await import("ioredis");
    redisPub = new Redis(REDIS_URL, { maxRetriesPerRequest: 2, lazyConnect: true });
    redisSub = new Redis(REDIS_URL, { maxRetriesPerRequest: 2, lazyConnect: true });
    await (redisPub as unknown as { connect(): Promise<void> }).connect().catch(() => {});
    await (redisSub as unknown as { connect(): Promise<void> }).connect().catch(() => {});
    redisSub.on("message", (channel, message) => {
      local.emit(channel, JSON.parse(message) as GenerationUpdate);
    });
    redisReady = true;
  } catch {
    redisReady = false; // fall back to in-process bus
  }
}

const channel = (generationId: string) => `gen:${generationId}`;

export async function publishGenerationEvent(generationId: string, update: GenerationUpdate) {
  await ensureRedis();
  const ch = channel(generationId);
  local.emit(ch, update);
  if (redisReady && redisPub) {
    const sub = redisSub as unknown as { subscribe(c: string): Promise<unknown> } | null;
    if (sub) await sub.subscribe(ch).catch(() => {});
    await redisPub.publish(ch, JSON.stringify(update)).catch(() => {});
  }
}

export async function subscribeToGeneration(
  generationId: string,
  onUpdate: (u: GenerationUpdate) => void,
): Promise<() => void> {
  await ensureRedis();
  const ch = channel(generationId);
  if (redisReady && redisSub) {
    await (redisSub as unknown as { subscribe(c: string): Promise<unknown> }).subscribe(ch).catch(() => {});
  }
  local.on(ch, onUpdate);
  return () => {
    local.off(ch, onUpdate);
  };
}
