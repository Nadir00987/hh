// ─── Shared API validation schemas ──────────────────────────────────────────
// Single source of truth for GenerationType values (mirrors Prisma enum).

import { z } from "zod";

export const GENERATION_TYPES = [
  "TEXT_TO_VIDEO",
  "IMAGE_TO_VIDEO",
  "VIDEO_TO_VIDEO",
  "VIDEO_EXTEND",
  "TEXT_TO_IMAGE",
  "IMAGE_EDIT",
  "BACKGROUND_REMOVE",
  "IMAGE_UPSCALE",
  "TEXT_TO_SPEECH",
  "VOICE_CLONE",
  "SOUND_EFFECT",
  "MUSIC",
  "SUBTITLES",
  "SCRIPT",
  "STORYBOARD",
  "PROMPT_ENHANCE",
] as const;

export const GENERATION_STATUSES = [
  "QUEUED",
  "PROCESSING",
  "GENERATING",
  "FINALIZING",
  "COMPLETED",
  "FAILED",
  "CANCELLED",
] as const;

export const generationTypeSchema = z.enum(GENERATION_TYPES);
export const generationStatusSchema = z.enum(GENERATION_STATUSES);

export type GenerationTypeInput = z.infer<typeof generationTypeSchema>;
