import { describe, it, expect } from "vitest";
import { moderatePrompt, isProviderModerationError } from "@/lib/moderation";

describe("moderatePrompt", () => {
  it("allows ordinary creative prompts", () => {
    const r = moderatePrompt("A cinematic drone shot over a misty forest at dawn");
    expect(r.allowed).toBe(true);
  });

  it("rejects empty prompts", () => {
    const r = moderatePrompt("   ");
    expect(r.allowed).toBe(false);
    expect(r.reason).toBeTruthy();
  });

  it("blocks sexual content involving minors (conservative local list)", () => {
    const r = moderatePrompt("a minor in an explicit video");
    expect(r.allowed).toBe(false);
    expect(r.reason).toContain("minors");
  });

  it("leaves nuanced moderation to the provider's own filters", () => {
    // The local list is intentionally minimal; providers enforce the rest.
    expect(moderatePrompt("how to make a bomb at home").allowed).toBe(true);
  });
});

describe("isProviderModerationError", () => {
  it("detects safety rejections", () => {
    expect(isProviderModerationError("Content was flagged by safety filters")).toBe(true);
    expect(isProviderModerationError("Blocked by content policy")).toBe(true);
  });

  it("ignores unrelated errors", () => {
    expect(isProviderModerationError("Rate limit exceeded")).toBe(false);
    expect(isProviderModerationError("Internal server error")).toBe(false);
  });
});
