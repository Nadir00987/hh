import { describe, it, expect } from "vitest";
import { AppError, toUserFacing } from "@/lib/errors";

describe("AppError", () => {
  it("carries code, message, and status", () => {
    const e = new AppError("NOT_FOUND", "Missing thing.", 404);
    expect(e.code).toBe("NOT_FOUND");
    expect(e.message).toBe("Missing thing.");
    expect(e.status).toBe(404);
  });

  it("defaults to status 400; callers pass explicit statuses", () => {
    expect(new AppError("NOT_FOUND").status).toBe(400);
    expect(new AppError("FORBIDDEN", undefined, 403).status).toBe(403);
  });

  it("falls back to the catalog title when no message given", () => {
    expect(new AppError("NOT_FOUND").message).toBe("Not found");
  });
});

describe("toUserFacing", () => {
  it("formats the catalog entry and appends the error id as a hint", () => {
    const out = toUserFacing("NOT_FOUND", undefined, "err-123");
    expect(out.code).toBe("NOT_FOUND");
    expect(JSON.stringify(out)).toContain("err-123");
  });

  it("appends caller-provided detail (callers must pre-sanitize)", () => {
    const out = toUserFacing("NOT_FOUND", "item 42");
    expect(out.message).toContain("item 42");
  });
});
