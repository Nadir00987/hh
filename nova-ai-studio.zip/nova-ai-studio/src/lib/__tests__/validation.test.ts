import { describe, it, expect } from "vitest";
import { generationTypeSchema, generationStatusSchema, GENERATION_TYPES } from "@/lib/validation";

describe("generationTypeSchema", () => {
  it("accepts all 16 registry types", () => {
    expect(GENERATION_TYPES).toHaveLength(16);
    for (const t of GENERATION_TYPES) {
      expect(generationTypeSchema.safeParse(t).success).toBe(true);
    }
  });

  it("rejects unknown types", () => {
    expect(generationTypeSchema.safeParse("IMAGE_TO_IMAGE").success).toBe(false);
    expect(generationTypeSchema.safeParse("TEXT").success).toBe(false);
    expect(generationTypeSchema.safeParse("").success).toBe(false);
  });
});

describe("generationStatusSchema", () => {
  it("accepts the full lifecycle", () => {
    for (const s of ["QUEUED", "PROCESSING", "GENERATING", "FINALIZING", "COMPLETED", "FAILED", "CANCELLED"] as const) {
      expect(generationStatusSchema.safeParse(s).success).toBe(true);
    }
  });

  it("rejects unknown statuses", () => {
    expect(generationStatusSchema.safeParse("RUNNING").success).toBe(false);
  });
});
