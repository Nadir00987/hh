// ─── Pollinations adapter (image) ───────────────────────────────────────────
// Free tier, NO API key required. Real generation via image.pollinations.ai.
// Synchronous HTTP → we model it as an instantly-completing provider job.

import type { AIImageProvider, GenerationInput, ProviderJobState } from "../types";
import { getEnv } from "@/lib/env";

function aspectToDims(aspect: string | undefined): { width: number; height: number } {
  switch (aspect) {
    case "16:9": return { width: 1280, height: 720 };
    case "9:16": return { width: 720, height: 1280 };
    case "4:3": return { width: 1024, height: 768 };
    case "3:4": return { width: 768, height: 1024 };
    case "21:9": return { width: 1344, height: 576 };
    default: return { width: 1024, height: 1024 };
  }
}

export class PollinationsImageProvider implements AIImageProvider {
  readonly id = "pollinations";
  readonly displayName = "Pollinations";

  async generateImage(input: GenerationInput): Promise<ProviderJobState> {
    const s = input.settings as Record<string, unknown>;
    const { width, height } = aspectToDims(s.aspectRatio as string | undefined);
    const seed = typeof s.seed === "number" ? s.seed : Math.floor(Math.random() * 1_000_000);
    const model = (s.model as string | undefined) ?? "flux";

    const params = new URLSearchParams({
      width: String(width),
      height: String(height),
      seed: String(seed),
      model,
      nologo: "true",
      private: "true",
    });
    const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(input.prompt)}?${params}`;

    // Verify the image actually renders (HEAD/GET) before declaring success.
    const res = await fetch(url, { method: "GET" });
    if (!res.ok) {
      return { providerJobId: `poll-${seed}`, status: "failed", errorMessage: `Pollinations returned ${res.status}` };
    }
    const ct = res.headers.get("content-type") ?? "";
    if (!ct.startsWith("image/")) {
      return { providerJobId: `poll-${seed}`, status: "failed", errorMessage: "Pollinations did not return an image" };
    }
    return { providerJobId: `poll-${seed}`, status: "succeeded", outputUrls: [url] };
  }

  async getJobStatus(providerJobId: string): Promise<ProviderJobState> {
    // Pollinations is synchronous — jobs complete inside generateImage.
    return { providerJobId, status: "succeeded" };
  }
}

export function isPollinationsAvailable(): boolean {
  return getEnv().POLLINATIONS_ENABLED;
}
