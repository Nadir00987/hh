// ─── Replicate adapter (video + image) ──────────────────────────────────────
// Real async jobs via api.replicate.com. Requires REPLICATE_API_TOKEN.
// Progress is reported ONLY from prediction status — never invented.

import type { AIVideoProvider, AIImageProvider, GenerationInput, ProviderJobState } from "../types";
import { getEnv } from "@/lib/env";

const API = "https://api.replicate.com/v1";

// Registry model id → Replicate model version. Extend as models are added.
const VERSIONS: Record<string, string> = {
  "replicate:wan-2.5-t2v": "wan-2.5-t2v",
  "replicate:wan-2.5-i2v": "wan-2.5-i2v",
  "replicate:flux-schnell": "black-forest-labs/flux-schnell",
};

function headers() {
  return {
    Authorization: `Token ${getEnv().REPLICATE_API_TOKEN}`,
    "Content-Type": "application/json",
  };
}

interface ReplicatePrediction {
  id: string;
  status: "starting" | "processing" | "succeeded" | "failed" | "canceled";
  output?: string | string[] | null;
  error?: string | null;
  urls?: { get: string; cancel: string };
}

async function createPrediction(model: string, input: Record<string, unknown>, webhookUrl?: string) {
  const version = VERSIONS[model] ?? model;
  const body: Record<string, unknown> = { version, input };
  if (webhookUrl) {
    body.webhook = webhookUrl;
    body.webhook_events_filter = ["completed"];
  }
  const res = await fetch(`${API}/predictions`, { method: "POST", headers: headers(), body: JSON.stringify(body) });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`Replicate API ${res.status}: ${text.slice(0, 300)}`);
  }
  return (await res.json()) as ReplicatePrediction;
}

async function getPrediction(id: string): Promise<ReplicatePrediction> {
  const res = await fetch(`${API}/predictions/${id}`, { headers: headers() });
  if (!res.ok) throw new Error(`Replicate API ${res.status}`);
  return (await res.json()) as ReplicatePrediction;
}

function toJobState(p: ReplicatePrediction): ProviderJobState {
  const status =
    p.status === "succeeded" ? "succeeded"
    : p.status === "failed" ? "failed"
    : p.status === "canceled" ? "canceled"
    : p.status === "processing" ? "generating"
    : "queued";
  const output = p.output;
  const outputUrls = output ? (Array.isArray(output) ? output : [output]).filter((u) => typeof u === "string") : undefined;
  return { providerJobId: p.id, status, outputUrls, errorMessage: p.error ?? undefined };
  // NOTE: Replicate predictions don't expose a numeric progress field here —
  // progress stays undefined and the UI shows state-based progress. Honest.
}

function buildVideoInput(input: GenerationInput): Record<string, unknown> {
  const s = input.settings as Record<string, unknown>;
  const out: Record<string, unknown> = { prompt: input.prompt };
  if (input.negativePrompt) out.negative_prompt = input.negativePrompt;
  if (s.duration) out.duration = s.duration;
  if (s.aspectRatio) out.aspect_ratio = s.aspectRatio;
  if (s.seed) out.seed = s.seed;
  const img = input.inputAssets.find((a) => a.kind === "image");
  if (img) out.image = img.url;
  const vid = input.inputAssets.find((a) => a.kind === "video");
  if (vid) out.video = vid.url;
  if (s.motionIntensity) out.motion_intensity = s.motionIntensity;
  if (s.cameraMovement) out.camera_movement = s.cameraMovement;
  return out;
}

class ReplicateProvider implements AIVideoProvider, AIImageProvider {
  readonly id = "replicate";
  readonly displayName = "Replicate";

  private webhookUrl(): string | undefined {
    const env = getEnv();
    const secret = env.REPLICATE_WEBHOOK_SECRET;
    if (!secret) return undefined; // polling fallback
    return `${env.APP_URL}/api/webhooks/replicate`;
  }

  async generateVideo(input: GenerationInput): Promise<ProviderJobState> {
    const p = await createPrediction(input.modelId, buildVideoInput(input), this.webhookUrl());
    return toJobState(p);
  }

  async generateImage(input: GenerationInput): Promise<ProviderJobState> {
    const s = input.settings as Record<string, unknown>;
    const p = await createPrediction(input.modelId, {
      prompt: input.prompt,
      aspect_ratio: s.aspectRatio ?? "1:1",
      num_outputs: s.outputCount ?? 1,
      ...(typeof s.seed === "number" ? { seed: s.seed } : {}),
    }, this.webhookUrl());
    return toJobState(p);
  }

  async getJobStatus(providerJobId: string): Promise<ProviderJobState> {
    return toJobState(await getPrediction(providerJobId));
  }

  async cancelJob(providerJobId: string): Promise<void> {
    await fetch(`${API}/predictions/${providerJobId}/cancel`, { method: "POST", headers: headers() });
  }
}

export const replicateProvider = new ReplicateProvider();

export function isReplicateAvailable(): boolean {
  return Boolean(getEnv().REPLICATE_API_TOKEN);
}
