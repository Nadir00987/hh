// ─── OpenAI-compatible text provider ────────────────────────────────────────
// Powers: prompt enhancement, script writer, storyboard, captions.
// Works with OpenAI or any OpenAI-compatible endpoint (OPENAI_BASE_URL).
// Requires OPENAI_API_KEY — otherwise text tools show "not configured".

import type { AITextProvider } from "../types";
import { getEnv } from "@/lib/env";

class OpenAICompatibleTextProvider implements AITextProvider {
  readonly id = "openai-compatible";
  readonly displayName = "Text (OpenAI-compatible)";

  async completeText(input: {
    systemPrompt: string;
    userPrompt: string;
    maxTokens?: number;
    json?: boolean;
  }): Promise<string> {
    const env = getEnv();
    if (!env.OPENAI_API_KEY) throw new Error("Text provider not configured (OPENAI_API_KEY)");
    const res = await fetch(`${env.OPENAI_BASE_URL}/chat/completions`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${env.OPENAI_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: env.OPENAI_TEXT_MODEL,
        messages: [
          { role: "system", content: input.systemPrompt },
          { role: "user", content: input.userPrompt },
        ],
        max_tokens: input.maxTokens ?? 1200,
        temperature: 0.7,
        ...(input.json ? { response_format: { type: "json_object" } } : {}),
      }),
    });
    if (!res.ok) {
      const text = await res.text().catch(() => "");
      throw new Error(`Text API ${res.status}: ${text.slice(0, 300)}`);
    }
    const data = (await res.json()) as {
      choices?: { message?: { content?: string } }[];
      error?: { message?: string };
    };
    if (data.error) throw new Error(data.error.message ?? "Text API error");
    const content = data.choices?.[0]?.message?.content?.trim();
    if (!content) throw new Error("Text API returned empty response");
    return content;
  }
}

export const textProvider = new OpenAICompatibleTextProvider();

export function isTextProviderAvailable(): boolean {
  return Boolean(getEnv().OPENAI_API_KEY);
}

// ── Prompt enhancement (spec §11) ────────────────────────────────────────────

const ENHANCE_SYSTEM = `You are a professional video prompt engineer for AI video generation.
Rewrite the user's simple idea into a detailed, production-ready cinematic video prompt.
Structure it with: subject, environment, lighting, camera, lens, movement, composition, atmosphere, visual style, and continuity requirements.
Preserve the user's creative intent — do not change the subject or add unrelated elements.
Output ONLY the enhanced prompt, no preamble, no quotes, no explanations.`;

export async function enhancePrompt(idea: string): Promise<string> {
  const clean = idea.trim().slice(0, 800);
  if (!clean) throw new Error("Idea is empty");
  return textProvider.completeText({
    systemPrompt: ENHANCE_SYSTEM,
    userPrompt: clean,
    maxTokens: 600,
  });
}
