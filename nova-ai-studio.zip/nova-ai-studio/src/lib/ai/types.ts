// ─── AI Provider Abstraction ────────────────────────────────────────────────
// Provider-independent interfaces. Every provider adapter implements these.
// Adapters run ONLY on the server (worker / route handlers) — never in the browser.

export type MediaKind = "image" | "video" | "audio";
export type GenerationMode =
  | "text-to-video"
  | "image-to-video"
  | "video-to-video"
  | "video-extend"
  | "text-to-image"
  | "image-edit"
  | "background-remove"
  | "image-upscale"
  | "text-to-speech"
  | "voice-clone"
  | "sound-effect"
  | "music"
  | "subtitles"
  | "script"
  | "storyboard"
  | "prompt-enhance";

export interface ReferenceAsset {
  /** Publicly fetchable URL (presigned) handed to the provider. */
  url: string;
  kind: MediaKind;
  /** Semantic label: character | product | location | style | composition */
  label?: string;
}

export interface GenerationInput {
  prompt: string;
  negativePrompt?: string;
  /** Registry model id, e.g. "replicate:wan-2.5-t2v" */
  modelId: string;
  /** Validated settings: duration, aspectRatio, quality, seed, motion, camera... */
  settings: Record<string, unknown>;
  inputAssets: ReferenceAsset[];
  idempotencyKey: string;
  userId: string;
}

/** What a provider reports about a job. `progress` is ONLY set when the
 *  provider exposes a real percentage — otherwise it stays undefined and the
 *  UI shows indeterminate, state-based progress. Never invent it. */
export interface ProviderJobState {
  providerJobId: string;
  status: "queued" | "processing" | "generating" | "succeeded" | "failed" | "canceled";
  /** 0–100, real provider progress only */
  progress?: number;
  /** Direct URLs to finished media (provider CDN) */
  outputUrls?: string[];
  errorMessage?: string;
}

/** Truthful capability declaration. The UI renders controls ONLY from this. */
export interface ModelCapabilities {
  modes: GenerationMode[];
  durations?: number[]; // seconds
  aspectRatios?: string[]; // "16:9" | "9:16" | "1:1" ...
  resolutions?: string[]; // "720p" | "1080p" ...
  outputCounts?: number[]; // e.g. image variations
  maxReferences?: number;
  referenceLabels?: string[];
  supportsNegativePrompt?: boolean;
  supportsSeed?: boolean;
  supportsCameraControls?: boolean;
  supportsMotionControls?: boolean;
  supportsStylePreset?: boolean;
  creditCost: { base: number; perSecond?: number; perOutput?: number };
  speed: "fast" | "medium" | "slow";
  maxPromptChars?: number;
}

export interface AIVideoProvider {
  readonly id: string;
  readonly displayName: string;
  generateVideo(input: GenerationInput): Promise<ProviderJobState>;
  getJobStatus(providerJobId: string): Promise<ProviderJobState>;
  cancelJob?(providerJobId: string): Promise<void>;
}

export interface AIImageProvider {
  readonly id: string;
  readonly displayName: string;
  generateImage(input: GenerationInput): Promise<ProviderJobState>;
  getJobStatus(providerJobId: string): Promise<ProviderJobState>;
  cancelJob?(providerJobId: string): Promise<void>;
}

export interface AITextProvider {
  readonly id: string;
  readonly displayName: string;
  /** Synchronous text tasks: prompt enhance, scripts, storyboards, captions. */
  completeText(input: {
    systemPrompt: string;
    userPrompt: string;
    maxTokens?: number;
    json?: boolean;
  }): Promise<string>;
}

export interface AIAudioProvider {
  readonly id: string;
  readonly displayName: string;
  generateAudio(input: GenerationInput & { voice?: string }): Promise<ProviderJobState>;
  getJobStatus(providerJobId: string): Promise<ProviderJobState>;
}

export type AnyProvider = { readonly id: string; readonly displayName: string };

/** Normalize provider-native states to our lifecycle. */
export function normalizeProviderStatus(s: ProviderJobState["status"]): "queued" | "processing" | "generating" | "completed" | "failed" | "cancelled" {
  switch (s) {
    case "queued": return "queued";
    case "processing": return "processing";
    case "generating": return "generating";
    case "succeeded": return "completed";
    case "failed": return "failed";
    case "canceled": return "cancelled";
  }
}
