// ─── Provider factory ───────────────────────────────────────────────────────
// Maps registry provider ids → adapter instances. Server-only.

import type {
  AIVideoProvider, AIImageProvider, AITextProvider, AIAudioProvider,
} from "./types";
import { PollinationsImageProvider } from "./providers/pollinations";
import { replicateProvider } from "./providers/replicate";
import { textProvider } from "./providers/openai-compat";
import { getEnv } from "@/lib/env";

const videoProviders = new Map<string, AIVideoProvider>([
  ["replicate", replicateProvider],
]);

const imageProviders = new Map<string, AIImageProvider>([
  ["pollinations", new PollinationsImageProvider()],
  ["replicate", replicateProvider],
]);

const textProviders = new Map<string, AITextProvider>([
  ["openai-compatible", textProvider],
]);

export function getVideoProvider(id: string): AIVideoProvider | null {
  const p = videoProviders.get(id);
  if (!p) return null;
  // Gate on real credentials — never hand out an unusable adapter.
  if (id === "replicate" && !getEnv().REPLICATE_API_TOKEN) return null;
  return p;
}

export function getImageProvider(id: string): AIImageProvider | null {
  const p = imageProviders.get(id);
  if (!p) return null;
  if (id === "pollinations" && !getEnv().POLLINATIONS_ENABLED) return null;
  if (id === "replicate" && !getEnv().REPLICATE_API_TOKEN) return null;
  return p;
}

export function getTextProvider(id: string): AITextProvider | null {
  const p = textProviders.get(id);
  if (!p) return null;
  if (id === "openai-compatible" && !getEnv().OPENAI_API_KEY) return null;
  return p;
}

export type { AIAudioProvider };
