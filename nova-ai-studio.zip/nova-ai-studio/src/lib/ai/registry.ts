// ─── Model registry ─────────────────────────────────────────────────────────
// Loads the centralized backend configuration (DB-seeded from config/models.json).
// The frontend model selector reads ONLY this — never hardcoded models.

import { db } from "@/lib/db";
import type { GenerationType } from "@prisma/client";
import type { ModelCapabilities } from "./types";

export interface RegistryModel {
  id: string;
  providerId: string;
  providerName: string;
  providerEnabled: boolean;
  name: string;
  type: GenerationType;
  enabled: boolean;
  capabilities: ModelCapabilities;
  /** Resolved at request time: does the server actually have credentials? */
  configured: boolean;
}

let cache: { at: number; models: RegistryModel[] } | null = null;
const CACHE_TTL_MS = 30_000;

function isProviderConfigured(providerId: string): boolean {
  // Imported lazily to keep this module importable from edge/client-safe paths.
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  const { providerAvailability } = require("@/lib/env") as typeof import("@/lib/env");
  const a = providerAvailability();
  switch (providerId) {
    case "pollinations": return a.pollinations;
    case "replicate": return a.replicate;
    case "openai-compatible": return a.text;
    default: return false;
  }
}

export async function getModelRegistry(): Promise<RegistryModel[]> {
  const now = Date.now();
  if (cache && now - cache.at < CACHE_TTL_MS) return cache.models;

  const rows = await db.aiModel.findMany({
    where: { enabled: true },
    include: { provider: true },
    orderBy: { sortOrder: "asc" },
  });

  const models: RegistryModel[] = rows.map((m) => ({
    id: m.id,
    providerId: m.providerId,
    providerName: m.provider.name,
    providerEnabled: m.provider.enabled,
    name: m.name,
    type: m.type,
    enabled: m.enabled && m.provider.enabled,
    capabilities: m.capabilities as unknown as ModelCapabilities,
    configured: m.provider.enabled && isProviderConfigured(m.providerId),
  }));

  cache = { at: now, models };
  return models;
}

export async function getModel(modelId: string): Promise<RegistryModel | null> {
  const models = await getModelRegistry();
  return models.find((m) => m.id === modelId) ?? null;
}

export async function getModelsForType(type: GenerationType): Promise<RegistryModel[]> {
  const models = await getModelRegistry();
  return models.filter((m) => m.type === type);
}

/** Clear the registry cache (called by admin provider toggles). */
export function invalidateRegistryCache() {
  cache = null;
}

/** Credit estimate from capabilities — single formula used by API + UI. */
export function estimateCredits(cap: ModelCapabilities, settings: Record<string, unknown>): number {
  const { base, perSecond, perOutput } = cap.creditCost;
  let total = base;
  if (perSecond && typeof settings.duration === "number") total += perSecond * settings.duration;
  if (perOutput && typeof settings.outputCount === "number") total += perOutput * Math.max(0, settings.outputCount - 1);
  if (typeof settings.variations === "number" && settings.variations > 1) total *= settings.variations;
  return Math.max(1, Math.ceil(total));
}
