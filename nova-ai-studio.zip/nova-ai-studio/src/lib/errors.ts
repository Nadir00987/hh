// ─── Structured errors → user-friendly messages ────────────────────────────
// Rule: never surface "Something went wrong" without a reason + recovery hints.

export type ErrorCode =
  | "PROVIDER_NOT_CONFIGURED"
  | "INSUFFICIENT_CREDITS"
  | "INVALID_PROMPT"
  | "UNSUPPORTED_FORMAT"
  | "PROVIDER_UNAVAILABLE"
  | "PROVIDER_TIMEOUT"
  | "RATE_LIMITED"
  | "NETWORK_FAILURE"
  | "STORAGE_FAILURE"
  | "WEBHOOK_FAILURE"
  | "MODERATION_REJECTED"
  | "JOB_EXPIRED"
  | "UNAUTHORIZED"
  | "FORBIDDEN"
  | "NOT_FOUND"
  | "VALIDATION_ERROR"
  | "CONFLICT"
  | "EMAIL_TAKEN"
  | "INVALID_TOKEN"
  | "TOKEN_EXPIRED"
  | "FILE_TOO_LARGE"
  | "INVALID_STATE"
  | "UNKNOWN";

export interface UserFacingError {
  code: ErrorCode;
  title: string;
  message: string;
  hints: string[];
  retryable: boolean;
}

const CATALOG: Record<ErrorCode, Omit<UserFacingError, "code">> = {
  PROVIDER_NOT_CONFIGURED: {
    title: "Provider not configured",
    message: "This model needs API credentials that haven't been added to the server environment yet.",
    hints: ["Add the required API key in the server environment (see docs/providers.md).", "Try a different model that is currently available."],
    retryable: false,
  },
  INSUFFICIENT_CREDITS: {
    title: "Not enough credits",
    message: "Your credit balance is too low for this generation. No credits were charged.",
    hints: ["Upgrade your plan or buy a credit pack.", "Choose a shorter duration or lighter model."],
    retryable: false,
  },
  INVALID_PROMPT: {
    title: "Prompt needs attention",
    message: "The prompt was rejected — it may be empty, too long, or contain unsupported content.",
    hints: ["Shorten or simplify the prompt.", "Remove special formatting or URLs.", "Try the Prompt Enhancer for a clean rewrite."],
    retryable: true,
  },
  UNSUPPORTED_FORMAT: {
    title: "Unsupported file",
    message: "The uploaded file's type, size, or dimensions aren't supported by this model.",
    hints: ["Check the accepted formats listed on the upload control.", "Convert the file and try again."],
    retryable: false,
  },
  PROVIDER_UNAVAILABLE: {
    title: "Provider temporarily unavailable",
    message: "The AI provider didn't respond. Your credits were not charged.",
    hints: ["Wait a moment and retry.", "Switch to a different model."],
    retryable: true,
  },
  PROVIDER_TIMEOUT: {
    title: "Generation timed out",
    message: "The provider took too long to respond. Your credits were not charged.",
    hints: ["Retry the generation.", "Try a faster model or shorter duration."],
    retryable: true,
  },
  RATE_LIMITED: {
    title: "Too many requests",
    message: "You've hit the rate limit for your plan. Please slow down a little.",
    hints: ["Wait a minute before retrying.", "Higher plans include higher limits."],
    retryable: true,
  },
  NETWORK_FAILURE: {
    title: "Network issue",
    message: "A network error interrupted the request. Nothing was charged.",
    hints: ["Check your connection and retry."],
    retryable: true,
  },
  STORAGE_FAILURE: {
    title: "Storage error",
    message: "The result couldn't be saved to storage.",
    hints: ["Retry — the generation itself may have succeeded.", "Contact support if it persists."],
    retryable: true,
  },
  WEBHOOK_FAILURE: {
    title: "Status update delayed",
    message: "The provider's completion callback failed. The job will be reconciled automatically.",
    hints: ["The generation may still complete — check History shortly."],
    retryable: false,
  },
  MODERATION_REJECTED: {
    title: "Blocked by safety filters",
    message: "This request was blocked by content safety filters. No credits were charged.",
    hints: ["Rephrase the prompt to remove sensitive content.", "See our content policy in Settings → Data & Privacy."],
    retryable: false,
  },
  JOB_EXPIRED: {
    title: "Job expired",
    message: "The generation job expired before completing.",
    hints: ["Start a new generation with the same settings."],
    retryable: true,
  },
  UNAUTHORIZED: {
    title: "Sign in required",
    message: "You need to be signed in to do that.",
    hints: ["Sign in and try again."],
    retryable: false,
  },
  FORBIDDEN: {
    title: "Not allowed",
    message: "You don't have permission to access this resource.",
    hints: ["If this is your content, try signing in with the right account."],
    retryable: false,
  },
  NOT_FOUND: {
    title: "Not found",
    message: "The requested item doesn't exist or was deleted.",
    hints: ["Check the URL or return to the dashboard."],
    retryable: false,
  },
  VALIDATION_ERROR: {
    title: "Invalid input",
    message: "Some fields didn't pass validation.",
    hints: ["Review the highlighted fields and try again."],
    retryable: true,
  },
  CONFLICT: {
    title: "Conflict",
    message: "This action conflicts with the current state.",
    hints: ["Refresh and try again."],
    retryable: true,
  },
  EMAIL_TAKEN: {
    title: "Email already registered",
    message: "An account with this email already exists.",
    hints: ["Try signing in instead.", "Use the password reset if you've forgotten it."],
    retryable: false,
  },
  INVALID_TOKEN: {
    title: "Invalid link",
    message: "This link is invalid or has already been used.",
    hints: ["Request a new link and try again."],
    retryable: false,
  },
  TOKEN_EXPIRED: {
    title: "Link expired",
    message: "This link has expired.",
    hints: ["Request a new link and try again."],
    retryable: false,
  },
  FILE_TOO_LARGE: {
    title: "File too large",
    message: "The uploaded file exceeds the size limit.",
    hints: ["Compress the file or choose a smaller one."],
    retryable: false,
  },
  INVALID_STATE: {
    title: "Action not allowed",
    message: "This action isn't available in the current state.",
    hints: ["Refresh to see the latest status."],
    retryable: false,
  },
  UNKNOWN: {
    title: "Unexpected error",
    message: "Something unexpected happened on our side. The team has been notified.",
    hints: ["Try again in a moment.", "If it persists, contact support with the error ID below."],
    retryable: true,
  },
};

export function toUserFacing(code: ErrorCode, detail?: string, errorId?: string): UserFacingError {
  const base = CATALOG[code] ?? CATALOG.UNKNOWN;
  return {
    code,
    ...base,
    message: detail ? `${base.message} ${detail}` : base.message,
    ...(errorId ? { hints: [...base.hints, `Error ID: ${errorId}`] } : {}),
  };
}

/** Map raw provider / SDK errors to our codes. Never leak raw stack traces. */
export function mapProviderError(err: unknown): { code: ErrorCode; detail: string } {
  const msg = err instanceof Error ? err.message : String(err ?? "");
  const lower = msg.toLowerCase();
  if (/moderation|policy|safety|nsfw|blocked.*content/i.test(msg)) return { code: "MODERATION_REJECTED", detail: "" };
  if (/429|rate limit|too many/i.test(lower)) return { code: "RATE_LIMITED", detail: "" };
  if (/timeout|timed out|etimedout/i.test(lower)) return { code: "PROVIDER_TIMEOUT", detail: "" };
  if (/unauthorized|401|invalid.*(key|token)/i.test(msg)) return { code: "PROVIDER_NOT_CONFIGURED", detail: "The provider rejected the configured credentials." };
  if (/econn|enotfound|network|fetch failed/i.test(lower)) return { code: "NETWORK_FAILURE", detail: "" };
  if (/5\d\d|unavailable|bad gateway|service unavailable/i.test(lower)) return { code: "PROVIDER_UNAVAILABLE", detail: "" };
  // Fall back to a sanitized one-line detail (no stacks, no secrets).
  const detail = msg.split("\n")[0].slice(0, 220);
  return { code: "UNKNOWN", detail };
}

export class AppError extends Error {
  constructor(
    public code: ErrorCode,
    message?: string,
    public status = 400,
  ) {
    super(message ?? CATALOG[code].title);
    this.name = "AppError";
  }
}
