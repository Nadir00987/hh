// ─── Generation lifecycle service ───────────────────────────────────────────
// The ONLY place that creates or transitions generations. Enforces:
//  - valid status transitions (terminal states are final)
//  - credit reserve → finalize | release on every path
//  - a GenerationEvent row + realtime publish on every transition
//  - idempotency keys on create

import { randomUUID } from "crypto";
import type { GenerationStatus, GenerationType, Prisma } from "@prisma/client";
import { db } from "./db";
import { AppError, toUserFacing } from "./errors";
import { reserveCredits } from "./credits";
import { getModel, estimateCredits } from "./ai/registry";
import { publishGenerationEvent } from "./realtime";
import { enqueueGenerationJob } from "./queue";
import { log } from "./logger";

const TERMINAL: GenerationStatus[] = ["COMPLETED", "FAILED", "CANCELLED"];

const ALLOWED: Record<GenerationStatus, GenerationStatus[]> = {
  QUEUED: ["PROCESSING", "CANCELLED"],
  PROCESSING: ["GENERATING", "FAILED", "CANCELLED"],
  GENERATING: ["FINALIZING", "FAILED", "CANCELLED"],
  FINALIZING: ["COMPLETED", "FAILED", "CANCELLED"],
  COMPLETED: [],
  FAILED: [],
  CANCELLED: [],
};

export interface CreateGenerationInput {
  userId: string;
  type: GenerationType;
  modelId: string;
  prompt: string;
  negativePrompt?: string;
  settings: Record<string, unknown>;
  inputAssetIds?: string[];
  projectId?: string;
  parentId?: string;
  idempotencyKey?: string;
}

export async function createGeneration(input: CreateGenerationInput) {
  const model = await getModel(input.modelId);
  if (!model || !model.enabled) throw new AppError("NOT_FOUND", "Model not available", 404);
  if (!model.configured) throw new AppError("PROVIDER_NOT_CONFIGURED", undefined, 503);
  if (!model.capabilities.modes.length) throw new AppError("VALIDATION_ERROR", "Model has no capabilities");

  const maxChars = model.capabilities.maxPromptChars ?? 2000;
  const prompt = input.prompt.trim();
  if (!prompt) throw new AppError("INVALID_PROMPT", "Prompt is empty", 400);
  if (prompt.length > maxChars) {
    throw new AppError("INVALID_PROMPT", `Prompt exceeds ${maxChars} characters`, 400);
  }

  const cost = estimateCredits(model.capabilities, input.settings);
  const idempotencyKey = input.idempotencyKey ?? randomUUID();

  // Idempotent create: same key → return existing row, never double-reserve.
  const existing = await db.generation.findUnique({ where: { idempotencyKey } });
  if (existing) {
    if (existing.userId !== input.userId) throw new AppError("CONFLICT", undefined, 409);
    return existing;
  }

  // Verify input assets belong to the user.
  let assetIds: string[] = [];
  if (input.inputAssetIds?.length) {
    const assets = await db.asset.findMany({
      where: { id: { in: input.inputAssetIds }, userId: input.userId, deletedAt: null },
      select: { id: true },
    });
    if (assets.length !== input.inputAssetIds.length) {
      throw new AppError("NOT_FOUND", "One or more input assets were not found", 404);
    }
    assetIds = assets.map((a) => a.id);
  }

  if (input.projectId) {
    const project = await db.project.findFirst({
      where: { id: input.projectId, userId: input.userId, deletedAt: null },
    });
    if (!project) throw new AppError("NOT_FOUND", "Project not found", 404);
  }

  // Create row FIRST (status QUEUED) so the reserve has a generationId to link.
  const generation = await db.generation.create({
    data: {
      userId: input.userId,
      projectId: input.projectId,
      type: input.type,
      provider: model.providerId,
      model: model.id,
      prompt,
      negativePrompt: input.negativePrompt,
      settings: input.settings as Prisma.InputJsonValue,
      status: "QUEUED",
      creditsReserved: cost,
      parentId: input.parentId,
      idempotencyKey,
      inputAssets: assetIds.length ? { connect: assetIds.map((id) => ({ id })) } : undefined,
    },
  });

  try {
    await reserveCredits({
      userId: input.userId,
      amount: cost,
      generationId: generation.id,
      idempotencyKey: `reserve:${generation.id}`,
      reason: `Reserve for ${model.name}`,
    });
  } catch (e) {
    // Reservation failed (e.g. insufficient credits) → mark generation failed,
    // never leave a QUEUED row holding phantom credits.
    await transitionGeneration(generation.id, "FAILED", {
      errorCode: e instanceof AppError ? e.code : "UNKNOWN",
      errorMessage: e instanceof Error ? e.message : undefined,
      internal: true,
    });
    throw e;
  }

  await db.generationEvent.create({
    data: { generationId: generation.id, toStatus: "QUEUED", message: "Generation queued" },
  });

  await enqueueGenerationJob(generation.id);
  await publishGenerationEvent(generation.id, { status: "QUEUED" });

  log.info({ generationId: generation.id, model: model.id, cost }, "generation created");
  return generation;
}

export async function transitionGeneration(
  id: string,
  to: GenerationStatus,
  opts: {
    message?: string;
    metadata?: Record<string, unknown>;
    progress?: number | null;
    providerJobId?: string;
    errorCode?: string;
    errorMessage?: string;
    /** internal transitions (e.g. reserve failure) skip credit side-effects */
    internal?: boolean;
  } = {},
) {
  return db.$transaction(async (tx) => {
    const gen = await tx.generation.findUnique({ where: { id } });
    if (!gen) throw new AppError("NOT_FOUND", "Generation not found", 404);
    if (TERMINAL.includes(gen.status)) {
      log.warn({ id, from: gen.status, to }, "transition from terminal state ignored");
      return gen;
    }
    if (!ALLOWED[gen.status].includes(to)) {
      throw new AppError("CONFLICT", `Cannot transition ${gen.status} → ${to}`, 409);
    }

    const data: Record<string, unknown> = { status: to };
    if (to === "PROCESSING" && !gen.startedAt) data.startedAt = new Date();
    if (TERMINAL.includes(to)) data.completedAt = new Date();
    if (opts.progress !== undefined) data.progress = opts.progress;
    if (opts.providerJobId) data.providerJobId = opts.providerJobId;
    if (opts.errorCode) data.errorCode = opts.errorCode;
    if (opts.errorMessage) data.errorMessage = opts.errorMessage?.slice(0, 2000);

    const updated = await tx.generation.update({ where: { id }, data: data as never });

    await tx.generationEvent.create({
      data: {
        generationId: id,
        fromStatus: gen.status,
        toStatus: to,
        message: opts.message,
        metadata: (opts.metadata ?? {}) as Prisma.InputJsonValue,
      },
    });

    // Credit side-effects on terminal transitions (skip for internal bookkeeping).
    if (!opts.internal && TERMINAL.includes(to) && gen.creditsReserved > 0) {
      const { releaseReservation: rel, finalizeCharge: fin } = await import("./credits");
      if (to === "COMPLETED") {
        await fin({
          userId: gen.userId,
          amount: gen.creditsReserved,
          generationId: id,
          idempotencyKey: `charge:${id}`,
        });
        await tx.generation.update({
          where: { id },
          data: { creditsCharged: gen.creditsReserved, creditsReserved: 0 },
        });
      } else {
        await rel({
          userId: gen.userId,
          amount: gen.creditsReserved,
          generationId: id,
          idempotencyKey: `release:${id}`,
          reason: to === "CANCELLED" ? "Generation cancelled — reservation released" : "Generation failed — reservation released",
        });
        await tx.generation.update({ where: { id }, data: { creditsReserved: 0 } });
      }
    }

    return updated;
  }).then(async (updated) => {
    // Publish outside the transaction.
    await publishGenerationEvent(id, {
      status: updated.status,
      progress: updated.progress,
      errorCode: updated.errorCode,
      errorMessage: updated.errorMessage
        ? toUserFacing(updated.errorCode as never).message
        : undefined,
    });
    return updated;
  });
}

/** Retry: creates a new attempt row + re-queues. Same generation, new lifecycle. */
export async function retryGeneration(id: string, userId: string, withChanges?: Partial<CreateGenerationInput>) {
  const gen = await db.generation.findFirst({ where: { id, userId } });
  if (!gen) throw new AppError("NOT_FOUND", "Generation not found", 404);
  if (!TERMINAL.includes(gen.status) && gen.status !== "FAILED") {
    throw new AppError("CONFLICT", "Only completed, failed or cancelled generations can be retried", 409);
  }

  const model = await getModel(withChanges?.modelId ?? gen.model);
  if (!model?.configured) throw new AppError("PROVIDER_NOT_CONFIGURED", undefined, 503);
  const settings = { ...(gen.settings as Record<string, unknown>), ...(withChanges?.settings ?? {}) };
  const cost = estimateCredits(model.capabilities, settings);

  const retried = await db.$transaction(async (tx) => {
    const attemptCount = await tx.generationAttempt.count({ where: { generationId: id } });
    await tx.generationAttempt.create({
      data: {
        generationId: id,
        attemptNumber: attemptCount + 1,
        provider: model.providerId,
        model: model.id,
        status: "QUEUED",
      },
    });
    return tx.generation.update({
      where: { id },
      data: {
        status: "QUEUED",
        provider: model.providerId,
        model: model.id,
        prompt: withChanges?.prompt ?? gen.prompt,
        settings: settings as Prisma.InputJsonValue,
        progress: null,
        errorCode: null,
        errorMessage: null,
        completedAt: null,
        creditsReserved: cost,
      },
    });
  });

  await reserveCredits({
    userId,
    amount: cost,
    generationId: id,
    idempotencyKey: `reserve:${id}:retry:${Date.now()}`,
    reason: `Retry reserve for ${model.name}`,
  });

  await db.generationEvent.create({
    data: { generationId: id, fromStatus: gen.status, toStatus: "QUEUED", message: "Retried by user" },
  });
  await enqueueGenerationJob(id);
  await publishGenerationEvent(id, { status: "QUEUED" });
  return retried;
}

export async function getGenerationForUser(id: string, userId: string) {
  const gen = await db.generation.findFirst({
    where: { id, userId },
    include: {
      outputAssets: true,
      inputAssets: { select: { id: true, filename: true, kind: true } },
      events: { orderBy: { createdAt: "asc" }, take: 50 },
      children: { select: { id: true, status: true, createdAt: true } },
    },
  });
  if (!gen) throw new AppError("NOT_FOUND", "Generation not found", 404);
  return gen;
}
