// ─── Moderation pre-check ───────────────────────────────────────────────────
// Provider-aware moderation layer. Runs BEFORE credits are reserved.
// This is a first-pass local screen; provider safety systems are never bypassed
// and provider rejections are mapped to MODERATION_REJECTED downstream.

const BLOCKED_PATTERNS: { pattern: RegExp; label: string }[] = [
  // Minimal, conservative local list — the provider's own filters are authoritative.
  { pattern: /\b(child|minor|underage).{0,40}\b(sex|nude|naked|explicit)\b/i, label: "sexual content involving minors" },
  { pattern: /\b(cs[ae]m|child porn)\b/i, label: "sexual content involving minors" },
];

export interface ModerationResult {
  allowed: boolean;
  reason?: string;
}

export function moderatePrompt(prompt: string): ModerationResult {
  const text = prompt.trim();
  if (!text) return { allowed: false, reason: "Prompt is empty" };
  for (const { pattern, label } of BLOCKED_PATTERNS) {
    if (pattern.test(text)) {
      return { allowed: false, reason: `Blocked: ${label}` };
    }
  }
  return { allowed: true };
}

/** Heuristic: does this error from a provider look like a safety rejection? */
export function isProviderModerationError(message: string): boolean {
  return /moderation|policy|safety|inappropriate|blocked/i.test(message);
}
