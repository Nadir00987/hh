// ─── Credit ledger ──────────────────────────────────────────────────────────
// Append-only ledger + cached balances. EVERY movement happens inside a DB
// transaction and carries an idempotency key — double-charge and double-refund
// are impossible by construction.
//
// Flow:  reserve → (success) finalize  |  (failure/cancel) release
//        charge → (post-charge refund case) refund

import { Prisma } from "@prisma/client";
import { db } from "./db";
import { AppError } from "./errors";

export async function getBalance(userId: string) {
  const bal = await db.creditBalance.upsert({
    where: { userId },
    update: {},
    create: { userId, available: 0, reserved: 0, lifetime: 0 },
  });
  return bal;
}

interface LedgerWrite {
  userId: string;
  type: "GRANT" | "RESERVE" | "CHARGE" | "RELEASE" | "REFUND" | "PURCHASE" | "ADJUST" | "EXPIRE";
  amount: number; // signed
  reason?: string;
  generationId?: string;
  idempotencyKey: string;
  metadata?: Record<string, unknown>;
  createdById?: string;
}

/** Idempotent ledger insert. Returns null if this key was already processed. */
async function insertLedger(tx: Prisma.TransactionClient, w: LedgerWrite, balanceAfter: number) {
  try {
    return await tx.creditLedger.create({
      data: {
        userId: w.userId,
        type: w.type as never,
        amount: w.amount,
        balanceAfter,
        reason: w.reason,
        generationId: w.generationId,
        idempotencyKey: w.idempotencyKey,
        metadata: (w.metadata ?? {}) as Prisma.InputJsonValue,
        createdById: w.createdById,
      },
    });
  } catch (e) {
    if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2002") {
      return null; // idempotency key already seen → already processed
    }
    throw e;
  }
}

/**
 * Reserve credits before a generation starts.
 * Throws INSUFFICIENT_CREDITS without touching anything if balance is low.
 */
export async function reserveCredits(opts: {
  userId: string;
  amount: number;
  generationId: string;
  idempotencyKey: string;
  reason?: string;
}) {
  if (opts.amount <= 0) throw new AppError("VALIDATION_ERROR", "Credit amount must be positive");
  return db.$transaction(async (tx) => {
    const bal = await tx.creditBalance.upsert({
      where: { userId: opts.userId },
      update: {},
      create: { userId: opts.userId, available: 0, reserved: 0, lifetime: 0 },
    });
    if (bal.available < opts.amount) {
      throw new AppError("INSUFFICIENT_CREDITS", undefined, 402);
    }
    const updated = await tx.creditBalance.update({
      where: { userId: opts.userId },
      data: { available: { decrement: opts.amount }, reserved: { increment: opts.amount } },
    });
    const row = await insertLedger(tx, {
      userId: opts.userId,
      type: "RESERVE",
      amount: -opts.amount,
      reason: opts.reason ?? "Generation started",
      generationId: opts.generationId,
      idempotencyKey: opts.idempotencyKey,
    }, updated.available);
    if (!row) throw new AppError("CONFLICT", "Reservation already processed");
    return updated;
  });
}

/** Success path: convert a reservation into a real charge. Idempotent. */
export async function finalizeCharge(opts: {
  userId: string;
  amount: number;
  generationId: string;
  idempotencyKey: string;
}) {
  return db.$transaction(async (tx) => {
    const bal = await tx.creditBalance.upsert({
      where: { userId: opts.userId },
      update: {},
      create: { userId: opts.userId, available: 0, reserved: 0, lifetime: 0 },
    });
    // Clamp: never let reserved go negative if something raced.
    const releaseAmt = Math.min(bal.reserved, opts.amount);
    const updated = await tx.creditBalance.update({
      where: { userId: opts.userId },
      data: { reserved: { decrement: releaseAmt } },
    });
    const row = await insertLedger(tx, {
      userId: opts.userId,
      type: "CHARGE",
      amount: -opts.amount,
      reason: "Generation completed",
      generationId: opts.generationId,
      idempotencyKey: opts.idempotencyKey,
    }, updated.available);
    return { balance: updated, alreadyProcessed: row === null };
  });
}

/** Failure/cancel path: return reserved credits. Idempotent. */
export async function releaseReservation(opts: {
  userId: string;
  amount: number;
  generationId: string;
  idempotencyKey: string;
  reason?: string;
}) {
  return db.$transaction(async (tx) => {
    const bal = await tx.creditBalance.upsert({
      where: { userId: opts.userId },
      update: {},
      create: { userId: opts.userId, available: 0, reserved: 0, lifetime: 0 },
    });
    const releaseAmt = Math.min(bal.reserved, opts.amount);
    const updated = await tx.creditBalance.update({
      where: { userId: opts.userId },
      data: {
        available: { increment: releaseAmt },
        reserved: { decrement: releaseAmt },
      },
    });
    const row = await insertLedger(tx, {
      userId: opts.userId,
      type: "RELEASE",
      amount: releaseAmt,
      reason: opts.reason ?? "Generation failed — reservation released",
      generationId: opts.generationId,
      idempotencyKey: opts.idempotencyKey,
    }, updated.available);
    return { balance: updated, alreadyProcessed: row === null };
  });
}

/** Post-charge refund (e.g. provider failed after finalize — rare). Idempotent. */
export async function refundCharge(opts: {
  userId: string;
  amount: number;
  generationId: string;
  idempotencyKey: string;
  reason?: string;
  createdById?: string;
}) {
  return db.$transaction(async (tx) => {
    const updated = await tx.creditBalance.upsert({
      where: { userId: opts.userId },
      update: { available: { increment: opts.amount } },
      create: { userId: opts.userId, available: opts.amount, reserved: 0, lifetime: 0 },
    });
    const row = await insertLedger(tx, {
      userId: opts.userId,
      type: "REFUND",
      amount: opts.amount,
      reason: opts.reason ?? "Refund",
      generationId: opts.generationId,
      idempotencyKey: opts.idempotencyKey,
      createdById: opts.createdById,
    }, updated.available);
    return { balance: updated, alreadyProcessed: row === null };
  });
}

/** Grant credits (plan allotment, promo, admin). Idempotent. */
export async function grantCredits(opts: {
  userId: string;
  amount: number;
  reason: string;
  idempotencyKey: string;
  createdById?: string;
  metadata?: Record<string, unknown>;
}) {
  if (opts.amount <= 0) throw new AppError("VALIDATION_ERROR", "Grant amount must be positive");
  return db.$transaction(async (tx) => {
    const updated = await tx.creditBalance.upsert({
      where: { userId: opts.userId },
      update: { available: { increment: opts.amount }, lifetime: { increment: opts.amount } },
      create: { userId: opts.userId, available: opts.amount, reserved: 0, lifetime: opts.amount },
    });
    const row = await insertLedger(tx, {
      userId: opts.userId,
      type: "GRANT",
      amount: opts.amount,
      reason: opts.reason,
      idempotencyKey: opts.idempotencyKey,
      createdById: opts.createdById,
      metadata: opts.metadata,
    }, updated.available);
    return { balance: updated, alreadyProcessed: row === null };
  });
}

export async function getLedger(userId: string, limit = 50, cursor?: string) {
  return db.creditLedger.findMany({
    where: { userId },
    orderBy: { createdAt: "desc" },
    take: limit,
    ...(cursor ? { cursor: { id: cursor }, skip: 1 } : {}),
  });
}
