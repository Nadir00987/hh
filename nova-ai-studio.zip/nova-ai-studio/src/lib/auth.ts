// ─── Authentication (Auth.js v5) ────────────────────────────────────────────
// Email/password (bcrypt) + email verification + optional Google/GitHub OAuth.
// Sessions: JWT in httpOnly cookies. Admin is a server-side role check.

import NextAuth from "next-auth";
import Credentials from "next-auth/providers/credentials";
import Google from "next-auth/providers/google";
import GitHub from "next-auth/providers/github";
import { PrismaAdapter } from "@auth/prisma-adapter";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { db } from "./db";
import { getEnv } from "./env";
import { log } from "./logger";

const credentialsSchema = z.object({
  email: z.string().email().max(255),
  password: z.string().min(8).max(128),
});

export const { handlers, auth, signIn, signOut } = NextAuth(() => {
  const env = getEnv();
  return {
    adapter: PrismaAdapter(db),
    session: { strategy: "jwt", maxAge: 30 * 24 * 3600 },
    trustHost: true,
    providers: [
      Credentials({
        name: "Email",
        credentials: { email: { label: "Email", type: "email" }, password: { label: "Password", type: "password" } },
        async authorize(raw) {
          const parsed = credentialsSchema.safeParse(raw);
          if (!parsed.success) return null;
          const { email, password } = parsed.data;
          const user = await db.user.findUnique({ where: { email: email.toLowerCase() } });
          if (!user?.passwordHash) return null;
          if (user.suspended || user.deletedAt) return null;
          const ok = await bcrypt.compare(password, user.passwordHash);
          if (!ok) return null;
          return { id: user.id, email: user.email, name: user.name, image: user.image };
        },
      }),
      ...(env.GOOGLE_CLIENT_ID && env.GOOGLE_CLIENT_SECRET
        ? [Google({ clientId: env.GOOGLE_CLIENT_ID, clientSecret: env.GOOGLE_CLIENT_SECRET })]
        : []),
      ...(env.GITHUB_CLIENT_ID && env.GITHUB_CLIENT_SECRET
        ? [GitHub({ clientId: env.GITHUB_CLIENT_ID, clientSecret: env.GITHUB_CLIENT_SECRET })]
        : []),
    ],
    callbacks: {
      async jwt({ token, user }) {
        if (user?.id) {
          const u = await db.user.findUnique({
            where: { id: user.id },
            select: { role: true, suspended: true },
          });
          token.sub = user.id;
          token.role = u?.role ?? "USER";
          if (u?.suspended) throw new Error("Account suspended");
        }
        return token;
      },
      async session({ session, token }) {
        if (session.user && token.sub) {
          session.user.id = token.sub;
          (session.user as { role?: string }).role = (token.role as string) ?? "USER";
        }
        return session;
      },
    },
    events: {
      async createUser({ user }) {
        if (!user.id) return;
        // Bootstrap: credit balance + free plan grant + profile.
        const email = (user.email ?? "").toLowerCase();
        const adminEmails = (getEnv().ADMIN_EMAILS ?? "").split(",").map((e) => e.trim().toLowerCase()).filter(Boolean);
        await db.$transaction(async (tx) => {
          if (adminEmails.includes(email)) {
            await tx.user.update({ where: { id: user.id }, data: { role: "ADMIN" } });
          }
          await tx.profile.create({ data: { userId: user.id! } });
          await tx.creditBalance.create({ data: { userId: user.id!, available: 0, reserved: 0, lifetime: 0 } });
          const freePlan = await tx.plan.findUnique({ where: { slug: "free" } });
          if (freePlan) {
            await tx.subscription.create({ data: { userId: user.id!, planId: freePlan.id, status: "ACTIVE" } });
            if (freePlan.monthlyCredits > 0) {
              await tx.creditBalance.update({
                where: { userId: user.id! },
                data: { available: { increment: freePlan.monthlyCredits }, lifetime: { increment: freePlan.monthlyCredits } },
              });
              await tx.creditLedger.create({
                data: {
                  userId: user.id!,
                  type: "GRANT",
                  amount: freePlan.monthlyCredits,
                  balanceAfter: freePlan.monthlyCredits,
                  reason: "Free plan signup grant",
                  idempotencyKey: `signup:${user.id}`,
                },
              });
            }
          }
        });
        log.info({ userId: user.id }, "user created");
      },
    },
    pages: {
      signIn: "/login",
      verifyRequest: "/verify",
      error: "/login",
    },
  };
});

// ── Route helpers ────────────────────────────────────────────────────────────

export async function requireUser() {
  const session = await auth();
  if (!session?.user?.id) {
    const { AppError } = await import("./errors");
    throw new AppError("UNAUTHORIZED", undefined, 401);
  }
  const user = await db.user.findUnique({ where: { id: session.user.id } });
  if (!user || user.deletedAt || user.suspended) {
    const { AppError } = await import("./errors");
    throw new AppError(user?.suspended ? "FORBIDDEN" : "UNAUTHORIZED", user?.suspended ? "Account suspended" : undefined, user?.suspended ? 403 : 401);
  }
  return user;
}

/** Server-side admin gate. NEVER rely on hiding UI — call this in every admin route. */
export async function requireAdmin() {
  const user = await requireUser();
  if (user.role !== "ADMIN") {
    const { AppError } = await import("./errors");
    throw new AppError("FORBIDDEN", "Admin access required", 403);
  }
  return user;
}
