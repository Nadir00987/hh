// ─── Email service ──────────────────────────────────────────────────────────
// SMTP via nodemailer when configured; otherwise logs to console in dev.
// Never throws — email failures are logged, not fatal to the request.

import nodemailer from "nodemailer";
import { getEnv } from "./env";
import { log } from "./logger";

let transporter: nodemailer.Transporter | null = null;

function getTransporter(): nodemailer.Transporter | null {
  if (!getEnv().SMTP_HOST) return null;
  if (!transporter) {
    transporter = nodemailer.createTransport({
      host: getEnv().SMTP_HOST,
      port: getEnv().SMTP_PORT ? Number(getEnv().SMTP_PORT) : 587,
      secure: getEnv().SMTP_PORT === "465",
      auth: getEnv().SMTP_USER ? { user: getEnv().SMTP_USER, pass: getEnv().SMTP_PASS } : undefined,
    });
  }
  return transporter;
}

export async function sendEmail(opts: {
  to: string;
  subject: string;
  html: string;
  text?: string;
}): Promise<boolean> {
  const t = getTransporter();
  if (!t) {
    log.info({ to: opts.to, subject: opts.subject }, "email skipped (no SMTP configured)");
    if (getEnv().NODE_ENV === "development") {
      console.log(`[email:dev] To: ${opts.to}\nSubject: ${opts.subject}\n${opts.text ?? opts.html.slice(0, 500)}`);
    }
    return false;
  }
  try {
    await t.sendMail({ from: getEnv().EMAIL_FROM, ...opts });
    return true;
  } catch (e) {
    log.error({ err: e, to: opts.to }, "email send failed");
    return false;
  }
}

export function appUrl(path: string): string {
  const e = getEnv();
  const base = e.APP_URL ?? "http://localhost:3000";
  return `${base.replace(/\/$/, "")}${path}`;
}

export async function sendVerificationEmail(email: string, token: string) {
  const url = appUrl(`/verify?token=${token}`);
  return sendEmail({
    to: email,
    subject: "Verify your Nova AI Studio account",
    html: `<p>Welcome! Click the link below to verify your email:</p><p><a href="${url}">${url}</a></p><p>This link expires in 24 hours.</p>`,
    text: `Verify your account: ${url}`,
  });
}

export async function sendPasswordResetEmail(email: string, token: string) {
  const url = appUrl(`/reset-password?token=${token}`);
  return sendEmail({
    to: email,
    subject: "Reset your Nova AI Studio password",
    html: `<p>Click the link below to reset your password:</p><p><a href="${url}">${url}</a></p><p>This link expires in 1 hour. If you didn't request this, ignore this email.</p>`,
    text: `Reset your password: ${url}`,
  });
}
