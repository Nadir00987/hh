// ─── Job queue ──────────────────────────────────────────────────────────────
// BullMQ + Redis in production. If REDIS_URL is unset, a clearly-labeled
// IN-PROCESS dev queue is used (single instance, jobs lost on restart).
// The interface is identical — swapping is a config change, not a code change.

import { getEnv } from "./env";
import { log } from "./logger";

export const GENERATION_QUEUE = "generations";

export interface GenerationJobData {
  generationId: string;
  enqueuedAt: string;
}

type Processor = (data: GenerationJobData) => Promise<void>;

// ── In-process fallback (dev only) ───────────────────────────────────────────
const devHandlers = new Map<string, Processor>();
let devWarned = false;

function devQueue() {
  if (!devWarned) {
    log.warn("REDIS_URL not set — using IN-PROCESS dev queue (single instance, not for production)");
    devWarned = true;
  }
  return {
    async add(_name: string, data: GenerationJobData) {
      // Process asynchronously but in-process.
      setImmediate(async () => {
        const handler = devHandlers.get(GENERATION_QUEUE);
        if (!handler) {
          log.error({ data }, "no dev worker registered for generation queue");
          return;
        }
        try {
          await handler(data);
        } catch (e) {
          log.error({ err: e, data }, "dev queue job failed");
        }
      });
      return { id: `dev-${Date.now()}` };
    },
  };
}

// ── BullMQ (production) ─────────────────────────────────────────────────────
let bullQueue: { add(n: string, d: GenerationJobData, o?: unknown): Promise<unknown> } | null = null;

async function bull() {
  if (bullQueue) return bullQueue;
  const { REDIS_URL } = getEnv();
  const [{ Queue }, { default: Redis }] = await Promise.all([
    import("bullmq"),
    import("ioredis"),
  ]);
  const connection = new Redis(REDIS_URL as string, { maxRetriesPerRequest: null });
  bullQueue = new Queue(GENERATION_QUEUE, {
    connection: connection as never,
    defaultJobOptions: {
      attempts: 3,
      backoff: { type: "exponential", delay: 10_000 },
      removeOnComplete: 1000,
      removeOnFail: 5000,
    },
  });
  return bullQueue;
}

export async function enqueueGenerationJob(generationId: string) {
  const data: GenerationJobData = { generationId, enqueuedAt: new Date().toISOString() };
  const { REDIS_URL } = getEnv();
  if (!REDIS_URL) {
    await devQueue().add("generate", data);
    return;
  }
  const q = await bull();
  await q.add("generate", data, { jobId: `gen-${generationId}-${Date.now()}` });
  log.info({ generationId }, "job enqueued");
}

/** Register the job processor. Called by worker/index.ts (and dev server). */
export async function registerWorker(processor: Processor) {
  const { REDIS_URL } = getEnv();
  if (!REDIS_URL) {
    devHandlers.set(GENERATION_QUEUE, processor);
    log.info("dev worker registered (in-process)");
    return;
  }
  const [{ Worker }, { default: Redis }] = await Promise.all([
    import("bullmq"),
    import("ioredis"),
  ]);
  const connection = new Redis(REDIS_URL as string, { maxRetriesPerRequest: null });
  const worker = new Worker(GENERATION_QUEUE, async (job) => processor(job.data as GenerationJobData), {
    connection: connection as never,
    concurrency: 5,
  });
  worker.on("failed", (job, err) => log.error({ jobId: job?.id, err }, "job failed"));
  worker.on("completed", (job) => log.info({ jobId: job?.id }, "job completed"));
  log.info("BullMQ worker registered");
}
