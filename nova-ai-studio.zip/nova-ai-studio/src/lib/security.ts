// ─── Security helpers ───────────────────────────────────────────────────────
// SSRF guard, security headers, file validation. Used by API routes + worker.

import { lookup } from "dns/promises";
import { isIP } from "net";

const BLOCKED_HOSTNAMES = new Set(["localhost", "metadata.google.internal"]);
const METADATA_IPS = ["169.254.169.254", "100.100.100.200"]; // cloud metadata

function isPrivateIp(ip: string): boolean {
  if (METADATA_IPS.includes(ip)) return true;
  const v4 = /^(\d+)\.(\d+)\.(\d+)\.(\d+)$/.exec(ip);
  if (v4) {
    const [, a, b] = v4.map(Number);
    return (
      a === 10 || a === 127 ||
      (a === 172 && b >= 16 && b <= 31) ||
      (a === 192 && b === 168) ||
      (a === 169 && b === 254) ||
      a === 0
    );
  }
  // IPv6: loopback, link-local, unique-local
  const l = ip.toLowerCase();
  return l === "::1" || l.startsWith("fe80:") || l.startsWith("fc") || l.startsWith("fd");
}

/** Throws if a URL is not safe to fetch server-side (SSRF protection). */
export async function assertSafeUrl(url: string): Promise<void> {
  let parsed: URL;
  try {
    parsed = new URL(url);
  } catch {
    throw new Error("Invalid URL");
  }
  if (!["http:", "https:"].includes(parsed.protocol)) throw new Error("URL must be http(s)");
  if (BLOCKED_HOSTNAMES.has(parsed.hostname.toLowerCase())) throw new Error("URL host is not allowed");

  // Resolve and check every IP (blocks DNS rebinding to private ranges).
  const host = parsed.hostname;
  const ips = isIP(host) ? [host] : (await lookup(host, { all: true }).catch(() => [])).map((r) => r.address);
  if (!ips.length) throw new Error("Could not resolve URL host");
  for (const ip of ips) {
    if (isPrivateIp(ip)) throw new Error("URL resolves to a private/internal address");
  }
}

export function securityHeaders(): Record<string, string> {
  return {
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "Permissions-Policy": "camera=(), microphone=(), geolocation=()",
    // CSP is intentionally permissive for media blobs; tighten per-route as needed.
    "Content-Security-Policy":
      "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; " +
      "style-src 'self' 'unsafe-inline'; img-src 'self' data: blob: https:; " +
      "media-src 'self' blob: https:; connect-src 'self' https:; font-src 'self' data:;",
  };
}

// ── File validation (never trust extension alone) ────────────────────────────

export const FILE_LIMITS = {
  image: { maxBytes: 25 * 1024 * 1024, mimes: ["image/png", "image/jpeg", "image/webp"] },
  video: { maxBytes: 500 * 1024 * 1024, mimes: ["video/mp4", "video/webm", "video/quicktime"] },
  audio: { maxBytes: 100 * 1024 * 1024, mimes: ["audio/mpeg", "audio/wav", "audio/ogg", "audio/webm"] },
} as const;

const MAGIC: Record<string, number[][]> = {
  "image/png": [[0x89, 0x50, 0x4e, 0x47]],
  "image/jpeg": [[0xff, 0xd8, 0xff]],
  "image/webp": [[0x52, 0x49, 0x46, 0x46]],
  "video/mp4": [[0x00, 0x00, 0x00]],
  "audio/mpeg": [[0x49, 0x44, 0x33], [0xff, 0xfb]],
  "audio/wav": [[0x52, 0x49, 0x46, 0x46]],
};

/** Validate MIME + magic bytes of an uploaded buffer. */
export function validateFile(kind: keyof typeof FILE_LIMITS, declaredMime: string, buffer: Buffer): string {
  const limits = FILE_LIMITS[kind];
  if (buffer.length > limits.maxBytes) {
    throw new Error(`File too large (max ${Math.round(limits.maxBytes / 1024 / 1024)}MB)`);
  }
  const candidates = (limits.mimes as readonly string[]).filter((m) =>
    MAGIC[m]?.some((sig) => sig.every((b, i) => buffer[i] === b)),
  );
  if (!candidates.length) throw new Error("File type not recognized or not allowed");
  if (!candidates.includes(declaredMime)) {
    // Magic bytes win over the declared MIME — use the detected type.
    return candidates[0];
  }
  return declaredMime;
}
