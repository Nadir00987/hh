// ─── Structured logging ─────────────────────────────────────────────────────
// JSON in production, pretty in dev. NEVER log secrets — the redactor scrubs
// known secret patterns from every line.

const SECRET_PATTERNS = [
  /sk-[a-zA-Z0-9-_]{10,}/g,
  /replicate_[a-zA-Z0-9-_]{10,}/gi,
  /(api[_-]?key|token|secret|password)["'=:\s]+[^"'\s,}]+/gi,
];

function redact(value: unknown): unknown {
  if (typeof value === "string") {
    let out = value;
    for (const p of SECRET_PATTERNS) out = out.replace(p, "[REDACTED]");
    return out;
  }
  if (value instanceof Error) {
    return { name: value.name, message: redact(value.message), stack: undefined };
  }
  if (Array.isArray(value)) return value.map(redact);
  if (value && typeof value === "object") {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value)) {
      out[k] = /key|token|secret|password|auth/i.test(k) ? "[REDACTED]" : redact(v);
    }
    return out;
  }
  return value;
}

type Level = "debug" | "info" | "warn" | "error";

function emit(level: Level, ...args: unknown[]) {
  const entry = {
    ts: new Date().toISOString(),
    level,
    ...(args.length === 1 && typeof args[0] === "object"
      ? (redact(args[0]) as Record<string, unknown>)
      : { msg: redact(args.map(String).join(" ")) }),
  };
  const line = JSON.stringify(entry);
  if (level === "error") console.error(line);
  else if (level === "warn") console.warn(line);
  else console.log(line);
}

export const log = {
  debug: (...a: unknown[]) => process.env.NODE_ENV === "development" && emit("debug", ...a),
  info: (...a: unknown[]) => emit("info", ...a),
  warn: (...a: unknown[]) => emit("warn", ...a),
  error: (...a: unknown[]) => emit("error", ...a),
};
