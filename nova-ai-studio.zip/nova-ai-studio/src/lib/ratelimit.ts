// ─── Rate limiting ──────────────────────────────────────────────────────────
// Redis sliding-window when REDIS_URL is set, in-memory fallback otherwise.
// Limits are per-plan; tiers come from the Plan.rateLimitTier field.

import { getEnv } from "./env";

export const RATE_LIMITS: Record<string, Record<string, { limit: number; windowSecs: number }>> = {
  free: {
    generation: { limit: 10, windowSecs: 3600 },
    upload: { limit: 30, windowSecs: 3600 },
    "prompt-enhance": { limit: 20, windowSecs: 3600 },
    auth: { limit: 10, windowSecs: 600 },
    api: { limit: 300, windowSecs: 60 },
  },
  creator: {
    generation: { limit: 60, windowSecs: 3600 },
    upload: { limit: 200, windowSecs: 3600 },
    "prompt-enhance": { limit: 100, windowSecs: 3600 },
    auth: { limit: 20, windowSecs: 600 },
    api: { limit: 1200, windowSecs: 60 },
  },
  pro: {
    generation: { limit: 200, windowSecs: 3600 },
    upload: { limit: 600, windowSecs: 3600 },
    "prompt-enhance": { limit: 300, windowSecs: 3600 },
    auth: { limit: 30, windowSecs: 600 },
    api: { limit: 3000, windowSecs: 60 },
  },
  studio: {
    generation: { limit: 1000, windowSecs: 3600 },
    upload: { limit: 2000, windowSecs: 3600 },
    "prompt-enhance": { limit: 1000, windowSecs: 3600 },
    auth: { limit: 30, windowSecs: 600 },
    api: { limit: 10000, windowSecs: 60 },
  },
};

interface Bucket { count: number; resetAt: number }
const memory = new Map<string, Bucket>();

let redis: { eval(s: string, n: number, ...a: (string | number)[]): Promise<unknown> } | null = null;
async function getRedis() {
  if (redis) return redis;
  const { REDIS_URL } = getEnv();
  if (!REDIS_URL) return null;
  try {
    const { default: Redis } = await import("ioredis");
    redis = new Redis(REDIS_URL, { maxRetriesPerRequest: 1, lazyConnect: true }) as never;
    await (redis as unknown as { connect(): Promise<void> }).connect().catch(() => {});
    return redis;
  } catch {
    return null;
  }
}

const SLIDING_WINDOW_LUA = `
local key = KEYS[1]
local now = tonumber(ARGV[1])
local window = tonumber(ARGV[2])
local limit = tonumber(ARGV[3])
redis.call('ZREMRANGEBYSCORE', key, 0, now - window * 1000)
local count = redis.call('ZCARD', key)
if count < limit then
  redis.call('ZADD', key, now, now .. ':' .. redis.call('INCR', key .. ':seq'))
  redis.call('PEXPIRE', key, window * 1000)
  return {1, limit - count - 1}
else
  return {0, 0}
end`;

export async function checkRateLimit(opts: {
  key: string; // e.g. `user:${userId}` or `ip:${ip}`
  action: keyof typeof RATE_LIMITS.free;
  tier?: string;
}): Promise<{ allowed: boolean; remaining: number; resetAfterSecs: number }> {
  const tier = RATE_LIMITS[opts.tier ?? "free"] ?? RATE_LIMITS.free;
  const rule = tier[opts.action] ?? RATE_LIMITS.free[opts.action];
  const redisClient = await getRedis();
  const redisKey = `rl:${opts.action}:${opts.key}`;

  if (redisClient) {
    try {
      const [allowed, remaining] = (await redisClient.eval(
        SLIDING_WINDOW_LUA, 1, redisKey, Date.now(), rule.windowSecs, rule.limit,
      )) as [number, number];
      return { allowed: allowed === 1, remaining, resetAfterSecs: rule.windowSecs };
    } catch {
      // fall through to memory
    }
  }

  const now = Date.now();
  const bucket = memory.get(redisKey);
  if (!bucket || now >= bucket.resetAt) {
    memory.set(redisKey, { count: 1, resetAt: now + rule.windowSecs * 1000 });
    return { allowed: true, remaining: rule.limit - 1, resetAfterSecs: rule.windowSecs };
  }
  if (bucket.count >= rule.limit) {
    return { allowed: false, remaining: 0, resetAfterSecs: Math.ceil((bucket.resetAt - now) / 1000) };
  }
  bucket.count += 1;
  return { allowed: true, remaining: rule.limit - bucket.count, resetAfterSecs: Math.ceil((bucket.resetAt - now) / 1000) };
}
