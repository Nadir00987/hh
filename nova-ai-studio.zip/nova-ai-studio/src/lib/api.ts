// ─── API route helpers ──────────────────────────────────────────────────────
// Consistent JSON responses, error mapping, and auth-wrapping for route handlers.

import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { AppError, toUserFacing, type ErrorCode } from "./errors";
import { requireUser, requireAdmin } from "./auth";
import { log } from "./logger";
import { checkRateLimit } from "./ratelimit";
import type { User } from "@prisma/client";

export function ok<T>(data: T, init?: ResponseInit) {
  return NextResponse.json({ ok: true, data }, init);
}

export function paginated<T>(items: T[], nextCursor: string | null) {
  return NextResponse.json({ ok: true, data: { items, nextCursor } });
}

export function apiError(code: ErrorCode, status = 400, detail?: string, errorId?: string) {
  return NextResponse.json(
    { ok: false, error: toUserFacing(code, detail, errorId) },
    { status },
  );
}

/** Map thrown errors to JSON responses. Never leaks stacks to the client. */
export function handleApiError(e: unknown, route: string) {
  const errorId = Math.random().toString(36).slice(2, 10);
  if (e instanceof AppError) {
    if (e.status >= 500) log.error({ errorId, route, err: e }, "api error");
    return apiError(e.code, e.status, e.message, e.status >= 500 ? errorId : undefined);
  }
  if (e instanceof z.ZodError) {
    return NextResponse.json(
      { ok: false, error: { ...toUserFacing("VALIDATION_ERROR"), fields: e.flatten().fieldErrors } },
      { status: 422 },
    );
  }
  log.error({ errorId, route, err: e }, "unhandled api error");
  return apiError("UNKNOWN", 500, undefined, errorId);
}

type Handler<TCtx = unknown> = (
  req: NextRequest, ctx: TCtx, user: User,
) => Promise<NextResponse>;

/**
 * Wrap a route handler with: auth + rate limit + error mapping.
 * Usage: export const POST = withAuth(async (req, ctx, user) => {...}, { action: "generation" });
 */
export function withAuth<TCtx = unknown>(
  handler: Handler<TCtx>,
  opts: { action?: "generation" | "upload" | "prompt-enhance" | "auth" | "api"; admin?: boolean } = {},
) {
  return async (req: NextRequest, ctx: TCtx) => {
    try {
      const user = opts.admin ? await requireAdmin() : await requireUser();
      if (opts.action) {
        const tier = await getUserTier(user.id);
        const rl = await checkRateLimit({
          key: `user:${user.id}`,
          action: opts.action,
          tier,
        });
        if (!rl.allowed) {
          return NextResponse.json(
            { ok: false, error: toUserFacing("RATE_LIMITED") },
            { status: 429, headers: { "Retry-After": String(rl.resetAfterSecs) } },
          );
        }
      }
      return await handler(req, ctx, user);
    } catch (e) {
      return handleApiError(e, req.nextUrl.pathname);
    }
  };
}

async function getUserTier(userId: string): Promise<string> {
  const { db } = await import("./db");
  const sub = await db.subscription.findUnique({
    where: { userId },
    include: { plan: { select: { rateLimitTier: true } } },
  });
  return sub?.plan.rateLimitTier ?? "free";
}

/** Parse + validate JSON body with a Zod schema. */
export async function parseBody<T>(req: NextRequest, schema: z.ZodType<T>): Promise<T> {
  const json = await req.json().catch(() => null);
  return schema.parse(json);
}
