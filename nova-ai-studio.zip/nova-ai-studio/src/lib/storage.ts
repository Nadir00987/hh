// ─── File storage ───────────────────────────────────────────────────────────
// S3-compatible object storage via presigned URLs (production) or a local-disk
// adapter (dev). Large files NEVER pass through the app server: the browser
// uploads straight to storage, then registers the Asset row.

import { createHash, randomUUID } from "crypto";
import { promises as fs } from "fs";
import path from "path";
import { getEnv } from "./env";
import { log } from "./logger";

export interface StorageAdapter {
  readonly kind: "s3" | "local";
  /** URL the browser PUTs the file to. */
  presignedUploadUrl(opts: { key: string; contentType: string; sizeBytes: number }): Promise<{ url: string; headers?: Record<string, string> }>;
  /** URL the browser GETs the file from (time-limited). */
  presignedDownloadUrl(key: string, expiresSecs?: number): Promise<string>;
  deleteObject(key: string): Promise<void>;
  /** Server-side fetch (worker downloading provider results). */
  putBuffer(key: string, body: Buffer, contentType: string): Promise<void>;
}

const LOCAL_DIR = path.join(process.cwd(), "storage");

async function localAdapter(): Promise<StorageAdapter> {
  await fs.mkdir(LOCAL_DIR, { recursive: true });
  const base = getEnv().APP_URL;
  return {
    kind: "local",
    async presignedUploadUrl({ key, contentType }) {
      // Dev only: the Next.js server handles the PUT via /api/assets/upload.
      return { url: `${base}/api/assets/local-upload?key=${encodeURIComponent(key)}`, headers: { "x-content-type": contentType } };
    },
    async presignedDownloadUrl(key) {
      return `${base}/api/assets/local-file?key=${encodeURIComponent(key)}`;
    },
    async deleteObject(key) {
      await fs.unlink(path.join(LOCAL_DIR, key)).catch(() => {});
    },
    async putBuffer(key, body) {
      const full = path.join(LOCAL_DIR, key);
      await fs.mkdir(path.dirname(full), { recursive: true });
      await fs.writeFile(full, body);
    },
  };
}

async function s3Adapter(): Promise<StorageAdapter> {
  const env = getEnv();
  const [{ S3Client, PutObjectCommand, GetObjectCommand, DeleteObjectCommand }, { getSignedUrl }] =
    await Promise.all([import("@aws-sdk/client-s3"), import("@aws-sdk/s3-request-presigner")]);
  const client = new S3Client({
    region: env.STORAGE_REGION,
    endpoint: env.STORAGE_ENDPOINT,
    credentials: { accessKeyId: env.STORAGE_ACCESS_KEY!, secretAccessKey: env.STORAGE_SECRET_KEY! },
    forcePathStyle: true,
  });
  const Bucket = env.STORAGE_BUCKET;
  return {
    kind: "s3",
    async presignedUploadUrl({ key, contentType }) {
      const url = await getSignedUrl(client, new PutObjectCommand({ Bucket, Key: key, ContentType: contentType }), { expiresIn: 900 });
      return { url };
    },
    async presignedDownloadUrl(key, expiresSecs = 3600) {
      return getSignedUrl(client, new GetObjectCommand({ Bucket, Key: key }), { expiresIn: expiresSecs });
    },
    async deleteObject(key) {
      await client.send(new DeleteObjectCommand({ Bucket, Key: key }));
    },
    async putBuffer(key, body, contentType) {
      await client.send(new PutObjectCommand({ Bucket, Key: key, Body: body, ContentType: contentType }));
    },
  };
}

let cached: StorageAdapter | null = null;

export async function getStorage(): Promise<StorageAdapter> {
  if (cached) return cached;
  const env = getEnv();
  cached = env.STORAGE_ENDPOINT && env.STORAGE_ACCESS_KEY ? await s3Adapter() : await localAdapter();
  if (cached.kind === "local") log.warn("Using LOCAL disk storage (dev only) — set STORAGE_* for production");
  return cached;
}

/** Deterministic, user-scoped storage key. */
export function storageKey(userId: string, kind: string, filename: string): string {
  const safe = filename.replace(/[^a-zA-Z0-9._-]/g, "_").slice(0, 120);
  const hash = createHash("sha256").update(userId).digest("hex").slice(0, 12);
  return `${kind}/${hash}/${randomUUID()}-${safe}`;
}

/** Download a remote URL to a buffer with SSRF protection. */
export async function fetchBuffer(url: string, maxBytes = 500 * 1024 * 1024): Promise<{ buffer: Buffer; contentType: string }> {
  const { assertSafeUrl } = await import("./security");
  assertSafeUrl(url);
  const res = await fetch(url, { redirect: "follow" });
  if (!res.ok) throw new Error(`Fetch failed: ${res.status}`);
  const contentType = res.headers.get("content-type") ?? "application/octet-stream";
  const buf = Buffer.from(await res.arrayBuffer());
  if (buf.length > maxBytes) throw new Error("File too large");
  return { buffer: buf, contentType: contentType.split(";")[0] };
}
