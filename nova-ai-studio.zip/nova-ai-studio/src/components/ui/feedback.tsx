import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function EmptyState({
  icon,
  title,
  body,
  action,
  className,
}: {
  icon?: ReactNode;
  title: string;
  body?: string;
  action?: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("flex flex-col items-center justify-center px-6 py-16 text-center", className)}>
      {icon && (
        <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary-soft text-primary">
          {icon}
        </div>
      )}
      <h3 className="type-h3">{title}</h3>
      {body && <p className="type-small mt-2 max-w-sm text-muted">{body}</p>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

export function Skeleton({ className }: { className?: string }) {
  return <div className={cn("skeleton", className)} aria-hidden />;
}

export function Progress({ value, indeterminate }: { value?: number | null; indeterminate?: boolean }) {
  const showIndeterminate = indeterminate || value == null;
  return (
    <div
      role="progressbar"
      aria-valuenow={showIndeterminate ? undefined : Math.round(value ?? 0)}
      aria-valuemin={0}
      aria-valuemax={100}
      className="h-1.5 w-full overflow-hidden rounded-full bg-surface-active"
    >
      <div
        className={cn(
          "h-full rounded-full bg-primary transition-micro",
          showIndeterminate && "w-1/3 animate-[progress-slide_1.2s_ease-in-out_infinite]",
        )}
        style={showIndeterminate ? undefined : { width: `${Math.min(100, Math.max(0, value ?? 0))}%` }}
      />
      <style>{`@keyframes progress-slide { 0% { margin-left: -33%; } 100% { margin-left: 100%; } }`}</style>
    </div>
  );
}
