import { cn } from "@/lib/utils";

const tones: Record<string, string> = {
  default: "bg-surface-hover text-foreground border-border",
  primary: "bg-primary-soft text-primary border-primary/20",
  success: "bg-success/10 text-success border-success/20",
  warning: "bg-warning/10 text-warning border-warning/20",
  error: "bg-error/10 text-error border-error/20",
  info: "bg-info/10 text-info border-info/20",
  muted: "bg-transparent text-muted border-border",
};

export function Badge({
  tone = "default",
  className,
  children,
}: {
  tone?: keyof typeof tones;
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[0.75rem] font-medium leading-5",
        tones[tone],
        className,
      )}
    >
      {children}
    </span>
  );
}

export function StatusDot({ status }: { status: string }) {
  const color =
    status === "COMPLETED" ? "bg-success"
    : status === "FAILED" ? "bg-error"
    : status === "CANCELLED" ? "bg-muted"
    : "bg-primary";
  const pulse = ["QUEUED", "PROCESSING", "GENERATING", "FINALIZING"].includes(status);
  return (
    <span className="relative flex h-2 w-2" aria-hidden>
      {pulse && <span className={cn("absolute inline-flex h-full w-full animate-ping rounded-full opacity-60", color)} />}
      <span className={cn("relative inline-flex h-2 w-2 rounded-full", color)} />
    </span>
  );
}
