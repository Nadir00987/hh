"use client";

import { useEffect, useState, type ReactNode } from "react";
import { Topbar } from "./topbar";
import { CommandPalette } from "./command-palette";

export function AppChrome({
  user,
  credits,
  children,
}: {
  user: { name?: string | null; email?: string | null; image?: string | null };
  credits: number;
  children?: ReactNode;
}) {
  const [paletteOpen, setPaletteOpen] = useState(false);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setPaletteOpen((o) => !o);
      }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, []);

  return (
    <>
      <Topbar user={user} credits={credits} onOpenPalette={() => setPaletteOpen(true)} />
      <CommandPalette open={paletteOpen} onClose={() => setPaletteOpen(false)} />
      {children}
    </>
  );
}
