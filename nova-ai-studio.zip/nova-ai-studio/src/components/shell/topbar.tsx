"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Search, Bell, Coins, ChevronDown, LogOut, User as UserIcon, CreditCard } from "lucide-react";
import { formatCredits } from "@/lib/utils";

export function Topbar({
  user,
  credits,
  onOpenPalette,
}: {
  user: { name?: string | null; email?: string | null; image?: string | null };
  credits: number;
  onOpenPalette: () => void;
}) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [notifCount, setNotifCount] = useState(0);

  useEffect(() => {
    fetch("/api/notifications?unread=true")
      .then((r) => r.json())
      .then((j) => j.ok && setNotifCount(j.data.unread))
      .catch(() => {});
  }, []);

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b border-border bg-background/90 px-4 backdrop-blur lg:px-6">
      <div className="w-10 lg:hidden" /> {/* spacer for mobile menu button */}
      <button
        onClick={onOpenPalette}
        className="flex h-10 max-w-md flex-1 items-center gap-2.5 rounded-lg border border-border bg-surface px-3.5 text-muted hover:border-border-strong hover:text-foreground transition-micro"
        aria-label="Search (Ctrl+K)"
      >
        <Search className="h-4 w-4 shrink-0" />
        <span className="type-small hidden sm:block">Search projects, generations, files…</span>
        <kbd className="ml-auto hidden rounded border border-border px-1.5 py-0.5 text-[0.6875rem] text-faint md:block">
          ⌘K
        </kbd>
      </button>

      <div className="ml-auto flex items-center gap-2">
        <Link
          href="/settings/billing"
          className="flex items-center gap-1.5 rounded-lg border border-border bg-surface px-3 py-2 text-[0.8125rem] font-semibold hover:border-border-strong transition-micro"
          title="Credit balance"
        >
          <Coins className="h-4 w-4 text-primary" />
          <span className="tabular-nums">{formatCredits(credits)}</span>
        </Link>

        <Link
          href="/notifications"
          className="relative rounded-lg p-2.5 text-muted hover:bg-surface-hover hover:text-foreground transition-micro"
          aria-label={`Notifications${notifCount ? `, ${notifCount} unread` : ""}`}
        >
          <Bell className="h-5 w-5" />
          {notifCount > 0 && (
            <span className="absolute right-1.5 top-1.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-error px-1 text-[0.625rem] font-bold text-white">
              {notifCount > 9 ? "9+" : notifCount}
            </span>
          )}
        </Link>

        <div className="relative">
          <button
            onClick={() => setMenuOpen((o) => !o)}
            className="flex items-center gap-1.5 rounded-lg p-1.5 hover:bg-surface-hover transition-micro"
            aria-haspopup="menu"
            aria-expanded={menuOpen}
            aria-label="Account menu"
          >
            {user.image ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={user.image} alt="" className="h-8 w-8 rounded-full object-cover" />
            ) : (
              <span className="flex h-8 w-8 items-center justify-center rounded-full bg-primary-soft text-sm font-bold text-primary">
                {(user.name ?? user.email ?? "?")[0]?.toUpperCase()}
              </span>
            )}
            <ChevronDown className="h-4 w-4 text-muted" />
          </button>
          {menuOpen && (
            <>
              <div className="fixed inset-0 z-40" onClick={() => setMenuOpen(false)} />
              <div role="menu" className="panel absolute right-0 z-50 mt-2 w-60 p-2 shadow-panel">
                <div className="px-3 py-2.5">
                  <p className="type-small truncate font-semibold">{user.name ?? "Account"}</p>
                  <p className="type-caption truncate">{user.email}</p>
                </div>
                <div className="border-t border-border pt-1">
                  <MenuLink href="/settings" icon={<UserIcon className="h-4 w-4" />} label="Profile settings" onClick={() => setMenuOpen(false)} />
                  <MenuLink href="/settings/billing" icon={<CreditCard className="h-4 w-4" />} label="Billing & credits" onClick={() => setMenuOpen(false)} />
                  <Link
                    href="/api/auth/signout"
                    onClick={() => setMenuOpen(false)}
                    className="flex items-center gap-2.5 rounded-lg px-3 py-2 text-[0.875rem] text-muted hover:bg-surface-hover hover:text-foreground transition-micro"
                    role="menuitem"
                  >
                    <LogOut className="h-4 w-4" /> Sign out
                  </Link>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  );
}

function MenuLink({ href, icon, label, onClick }: { href: string; icon: React.ReactNode; label: string; onClick: () => void }) {
  return (
    <Link
      href={href}
      onClick={onClick}
      role="menuitem"
      className="flex items-center gap-2.5 rounded-lg px-3 py-2 text-[0.875rem] text-muted hover:bg-surface-hover hover:text-foreground transition-micro"
    >
      {icon} {label}
    </Link>
  );
}
