"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard, Sparkles, FolderKanban, Library, LayoutTemplate,
  Wrench, History, Settings, LifeBuoy, ShieldCheck, ChevronLeft, Menu, X,
} from "lucide-react";
import { useState } from "react";

const NAV = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/create", label: "Create", icon: Sparkles },
  { href: "/projects", label: "Projects", icon: FolderKanban },
  { href: "/library", label: "Library", icon: Library },
  { href: "/templates", label: "Templates", icon: LayoutTemplate },
  { href: "/tools", label: "AI Tools", icon: Wrench },
  { href: "/history", label: "History", icon: History },
];

const BOTTOM = [
  { href: "/settings", label: "Settings", icon: Settings },
  { href: "/help", label: "Help", icon: LifeBuoy },
];

export function Sidebar({ isAdmin }: { isAdmin: boolean }) {
  const pathname = usePathname();
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  const link = (item: { href: string; label: string; icon: typeof LayoutDashboard }) => {
    const active = pathname === item.href || pathname.startsWith(item.href + "/");
    const Icon = item.icon;
    return (
      <Link
        key={item.href}
        href={item.href}
        onClick={() => setMobileOpen(false)}
        title={collapsed ? item.label : undefined}
        aria-current={active ? "page" : undefined}
        className={cn(
          "group flex items-center gap-3 rounded-lg px-3 py-2 text-[0.875rem] font-medium transition-micro",
          active
            ? "bg-primary-soft text-foreground"
            : "text-muted hover:bg-surface-hover hover:text-foreground",
          collapsed && "justify-center px-0",
        )}
      >
        <Icon className="h-[18px] w-[18px] shrink-0" aria-hidden />
        {!collapsed && <span className="truncate">{item.label}</span>}
        {active && !collapsed && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-primary" aria-hidden />}
      </Link>
    );
  };

  const body = (
    <div className="flex h-full flex-col">
      <div className={cn("flex items-center gap-2.5 px-4 pt-5 pb-4", collapsed && "justify-center px-0")}>
        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-primary text-lg font-bold text-white">
          N
        </div>
        {!collapsed && (
          <div className="min-w-0">
            <p className="truncate text-[0.9375rem] font-bold leading-tight">Nova AI Studio</p>
            <p className="type-caption">Creative workspace</p>
          </div>
        )}
      </div>

      <nav aria-label="Primary" className="flex-1 space-y-1 overflow-y-auto px-3 thin-scroll">
        {NAV.map(link)}
        {isAdmin && link({ href: "/admin", label: "Admin", icon: ShieldCheck })}
      </nav>

      <nav aria-label="Secondary" className="space-y-1 border-t border-border px-3 py-3">
        {BOTTOM.map(link)}
      </nav>

      <div className="hidden border-t border-border p-3 lg:block">
        <button
          onClick={() => setCollapsed((c) => !c)}
          className="flex w-full items-center justify-center gap-2 rounded-lg py-2 text-muted hover:bg-surface-hover hover:text-foreground transition-micro"
          aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
        >
          <ChevronLeft className={cn("h-4 w-4 transition-micro", collapsed && "rotate-180")} />
          {!collapsed && <span className="type-small">Collapse</span>}
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Mobile top bar toggle */}
      <button
        className="fixed left-4 top-4 z-40 rounded-lg bg-surface p-2 border border-border lg:hidden"
        onClick={() => setMobileOpen(true)}
        aria-label="Open navigation"
      >
        <Menu className="h-5 w-5" />
      </button>

      {/* Mobile drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden" role="dialog" aria-modal="true" aria-label="Navigation">
          <div className="absolute inset-0 bg-black/60" onClick={() => setMobileOpen(false)} />
          <div className="absolute inset-y-0 left-0 w-72 bg-surface border-r border-border animate-[drawer-in_200ms_ease-out]">
            <button
              className="absolute right-3 top-4 rounded-lg p-1.5 text-muted hover:bg-surface-hover"
              onClick={() => setMobileOpen(false)}
              aria-label="Close navigation"
            >
              <X className="h-5 w-5" />
            </button>
            {body}
          </div>
          <style>{`@keyframes drawer-in { from { transform: translateX(-100%); } }`}</style>
        </div>
      )}

      {/* Desktop sidebar */}
      <aside
        className={cn(
          "sticky top-0 hidden h-screen shrink-0 border-r border-border bg-surface transition-panel lg:block",
          collapsed ? "w-[76px]" : "w-60",
        )}
      >
        {body}
      </aside>
    </>
  );
}
