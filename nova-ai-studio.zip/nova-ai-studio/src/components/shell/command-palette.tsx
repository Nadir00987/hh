"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { cn } from "@/lib/utils";
import {
  Clapperboard, Image, FolderKanban, Library, Upload, Settings,
  Moon, Sun, Sparkles, Search, FileText, LayoutTemplate,
} from "lucide-react";

interface Command {
  id: string;
  label: string;
  hint?: string;
  icon: React.ReactNode;
  run: () => void;
}

export function CommandPalette({ open, onClose }: { open: boolean; onClose: () => void }) {
  const router = useRouter();
  const [query, setQuery] = useState("");
  const [index, setIndex] = useState(0);
  const [results, setResults] = useState<{ id: string; label: string; sub?: string; href: string }[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);
  const debounce = useRef<ReturnType<typeof setTimeout>>();

  const toggleTheme = useCallback(() => {
    const el = document.documentElement;
    const next = el.getAttribute("data-theme") === "light" ? "dark" : "light";
    el.setAttribute("data-theme", next);
    localStorage.setItem("nova-theme", next);
    document.cookie = `nova-theme=${next};path=/;max-age=31536000`;
  }, []);

  const commands: Command[] = [
    { id: "cv", label: "Create video", hint: "Studio", icon: <Clapperboard className="h-4 w-4" />, run: () => router.push("/studio/video") },
    { id: "ci", label: "Create image", hint: "Studio", icon: <Image className="h-4 w-4" />, run: () => router.push("/studio/image") },
    { id: "cs", label: "Write a script", hint: "Studio", icon: <FileText className="h-4 w-4" />, run: () => router.push("/studio/content/script") },
    { id: "op", label: "Open projects", icon: <FolderKanban className="h-4 w-4" />, run: () => router.push("/projects") },
    { id: "ol", label: "Open library", icon: <Library className="h-4 w-4" />, run: () => router.push("/library") },
    { id: "ot", label: "Browse templates", icon: <LayoutTemplate className="h-4 w-4" />, run: () => router.push("/templates") },
    { id: "oh", label: "Open history", icon: <Sparkles className="h-4 w-4" />, run: () => router.push("/history") },
    { id: "up", label: "Upload media", icon: <Upload className="h-4 w-4" />, run: () => router.push("/library?upload=1") },
    { id: "st", label: "Open settings", icon: <Settings className="h-4 w-4" />, run: () => router.push("/settings") },
    { id: "th", label: "Toggle dark / light mode", icon: <Moon className="h-4 w-4" />, run: toggleTheme },
  ];

  // Debounced global search.
  useEffect(() => {
    if (!open || !query.trim()) { setResults([]); return; }
    clearTimeout(debounce.current);
    debounce.current = setTimeout(async () => {
      try {
        const r = await fetch(`/api/search?q=${encodeURIComponent(query.trim())}&limit=6`);
        const j = await r.json();
        if (j.ok) setResults(j.data.items);
      } catch { /* ignore */ }
    }, 250);
    return () => clearTimeout(debounce.current);
  }, [query, open]);

  useEffect(() => {
    if (open) {
      setQuery(""); setIndex(0); setResults([]);
      setTimeout(() => inputRef.current?.focus(), 30);
    }
  }, [open ]);

  const filtered = commands.filter((c) => c.label.toLowerCase().includes(query.toLowerCase()));
  const total = filtered.length + results.length;

  const runAt = useCallback((i: number) => {
    if (i < filtered.length) filtered[i].run();
    else {
      const r = results[i - filtered.length];
      if (r) router.push(r.href);
    }
    onClose();
  }, [filtered, results, router, onClose]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      else if (e.key === "ArrowDown") { e.preventDefault(); setIndex((i) => (i + 1) % Math.max(total, 1)); }
      else if (e.key === "ArrowUp") { e.preventDefault(); setIndex((i) => (i - 1 + Math.max(total, 1)) % Math.max(total, 1)); }
      else if (e.key === "Enter" && total > 0) runAt(index);
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, total, index, runAt, onClose]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[90] flex items-start justify-center px-4 pt-[12vh]" role="dialog" aria-modal="true" aria-label="Command palette">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="panel relative w-full max-w-xl overflow-hidden shadow-panel animate-[dialog-in_150ms_ease-out]">
        <div className="flex items-center gap-3 border-b border-border px-4">
          <Search className="h-4 w-4 text-muted" />
          <input
            ref={inputRef}
            value={query}
            onChange={(e) => { setQuery(e.target.value); setIndex(0); }}
            placeholder="Type a command or search…"
            className="h-12 w-full bg-transparent text-[0.9375rem] placeholder:text-faint focus:outline-none"
            aria-label="Command palette input"
            role="combobox"
            aria-expanded
            aria-controls="cmd-list"
          />
          <kbd className="rounded border border-border px-1.5 py-0.5 text-[0.6875rem] text-faint">esc</kbd>
        </div>
        <div id="cmd-list" role="listbox" className="max-h-[40vh] overflow-y-auto p-2 thin-scroll">
          {total === 0 && (
            <p className="type-small px-3 py-6 text-center text-muted">
              {query ? "No matches found." : "Type to search your workspace."}
            </p>
          )}
          {filtered.map((c, i) => (
            <PaletteRow key={c.id} active={i === index} onClick={() => runAt(i)} icon={c.icon} label={c.label} hint={c.hint} />
          ))}
          {results.length > 0 && (
            <p className="type-label px-3 pb-1 pt-3">Results</p>
          )}
          {results.map((r, i) => (
            <PaletteRow
              key={r.id}
              active={filtered.length + i === index}
              onClick={() => runAt(filtered.length + i)}
              icon={<Search className="h-4 w-4" />}
              label={r.label}
              hint={r.sub}
            />
          ))}
        </div>
        <div className="flex items-center gap-4 border-t border-border px-4 py-2.5">
          <span className="type-caption">↑↓ navigate</span>
          <span className="type-caption">↵ select</span>
          <span className="type-caption ml-auto flex items-center gap-1">
            {document.documentElement.getAttribute("data-theme") === "light" ? <Sun className="h-3 w-3" /> : <Moon className="h-3 w-3" />}
          </span>
        </div>
      </div>
      <style>{`@keyframes dialog-in { from { opacity: 0; transform: translateY(-8px) scale(0.99); } }`}</style>
    </div>
  );
}

function PaletteRow({ active, onClick, icon, label, hint }: {
  active: boolean; onClick: () => void; icon: React.ReactNode; label: string; hint?: string;
}) {
  return (
    <button
      role="option"
      aria-selected={active}
      onClick={onClick}
      onMouseEnter={(e) => e.currentTarget.focus()}
      className={cn(
        "flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-[0.875rem] transition-micro",
        active ? "bg-primary-soft text-foreground" : "text-muted",
      )}
    >
      <span className={cn(active ? "text-primary" : "text-faint")}>{icon}</span>
      <span className="flex-1 truncate">{label}</span>
      {hint && <span className="type-caption">{hint}</span>}
    </button>
  );
}
