import { NextResponse, type NextRequest } from "next/server";
import { securityHeaders } from "@/lib/security";

const PROTECTED_PREFIXES = [
  "/dashboard", "/create", "/studio", "/projects", "/library",
  "/templates", "/tools", "/history", "/settings", "/admin",
];

/**
 * Edge-safe middleware: security headers everywhere + UX-level auth redirect.
 * Real authorization happens server-side (requireUser/requireAdmin) — this
 * redirect is a convenience, not a security boundary.
 */
export function middleware(req: NextRequest) {
  const res = NextResponse.next();
  for (const [k, v] of Object.entries(securityHeaders())) res.headers.set(k, v);

  const { pathname } = req.nextUrl;
  const needsAuth = PROTECTED_PREFIXES.some((p) => pathname === p || pathname.startsWith(p + "/"));

  if (needsAuth) {
    const sessionToken =
      req.cookies.get("authjs.session-token")?.value ??
      req.cookies.get("__Secure-authjs.session-token")?.value;
    if (!sessionToken) {
      const url = req.nextUrl.clone();
      url.pathname = "/login";
      url.searchParams.set("callbackUrl", pathname);
      return NextResponse.redirect(url);
    }
  }
  return res;
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|api/auth|api/webhooks).*)"],
};
