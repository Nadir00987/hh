"use client";

import { Suspense, useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import { Button } from "@/components/ui/button";

function VerifyForm() {
  const params = useSearchParams();
  const token = params.get("token");
  const [state, setState] = useState<"loading" | "ok" | "error">("loading");
  const [message, setMessage] = useState("");

  useEffect(() => {
    if (!token) { setState("error"); setMessage("Missing verification token."); return; }
    fetch("/api/auth/verify", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token }),
    })
      .then((r) => r.json())
      .then((j) => {
        if (j.ok) setState("ok");
        else { setState("error"); setMessage(j.error?.message ?? "Verification failed."); }
      })
      .catch(() => { setState("error"); setMessage("Network error."); });
  }, [token]);

  return (
    <div className="text-center">
      {state === "loading" && <p className="text-muted">Verifying your email…</p>}
      {state === "ok" && (
        <>
          <h1 className="text-2xl font-bold">Email verified</h1>
          <p className="mt-3 text-muted">Your account is active. Welcome to the studio.</p>
          <Link href="/login"><Button className="mt-6">Sign in</Button></Link>
        </>
      )}
      {state === "error" && (
        <>
          <h1 className="text-2xl font-bold">Verification failed</h1>
          <p className="mt-3 text-muted">{message}</p>
          <Link href="/login" className="mt-6 inline-block text-primary hover:underline">Back to sign in</Link>
        </>
      )}
    </div>
  );
}

export default function VerifyPage() {
  return (
    <Suspense fallback={<p className="text-muted">Loading…</p>}>
      <VerifyForm />
    </Suspense>
  );
}
