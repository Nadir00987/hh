import Link from "next/link";

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen">
      <div className="hidden w-1/2 flex-col justify-between bg-gradient-to-br from-primary/20 via-surface to-background p-12 lg:flex">
        <Link href="/" className="text-xl font-bold tracking-tight">
          NOVA <span className="text-primary">AI STUDIO</span>
        </Link>
        <div>
          <h2 className="text-3xl font-bold leading-tight">
            The unified AI creative studio.
          </h2>
          <p className="mt-4 max-w-md text-muted">
            Generate video, images, voice, and scripts from one workspace —
            with real-time progress, version history, and project organization.
          </p>
        </div>
        <p className="text-sm text-faint">Production-ready AI generation infrastructure.</p>
      </div>
      <div className="flex w-full items-center justify-center p-8 lg:w-1/2">
        <div className="w-full max-w-md">{children}</div>
      </div>
    </div>
  );
}
