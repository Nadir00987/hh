"use client";

import { Suspense, useState } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

function ResetForm() {
  const params = useSearchParams();
  const token = params.get("token");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await fetch("/api/auth/reset-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token, password }),
      });
      const json = await res.json();
      if (!json.ok) setError(json.error?.message ?? "Reset failed.");
      else setDone(true);
    } catch {
      setError("Network error. Try again.");
    } finally {
      setLoading(false);
    }
  }

  if (!token) {
    return (
      <div className="text-center">
        <h1 className="text-2xl font-bold">Invalid link</h1>
        <p className="mt-3 text-muted">This reset link is missing its token.</p>
        <Link href="/forgot-password" className="mt-6 inline-block text-primary hover:underline">
          Request a new link
        </Link>
      </div>
    );
  }

  if (done) {
    return (
      <div className="text-center">
        <h1 className="text-2xl font-bold">Password updated</h1>
        <p className="mt-3 text-muted">Sign in with your new password.</p>
        <Link href="/login"><Button className="mt-6">Sign in</Button></Link>
      </div>
    );
  }

  return (
    <div>
      <h1 className="text-2xl font-bold">Choose a new password</h1>
      <form onSubmit={onSubmit} className="mt-8 space-y-4">
        <div>
          <label htmlFor="password" className="mb-1.5 block text-sm font-medium">New password</label>
          <Input id="password" type="password" required autoComplete="new-password"
            minLength={8} value={password} onChange={(e) => setPassword(e.target.value)}
            placeholder="At least 8 characters" />
        </div>
        {error && <p className="rounded-lg bg-error/10 px-3 py-2 text-sm text-error" role="alert">{error}</p>}
        <Button type="submit" className="w-full" loading={loading}>Update password</Button>
      </form>
    </div>
  );
}

export default function ResetPasswordPage() {
  return (
    <Suspense fallback={<p className="text-muted">Loading…</p>}>
      <ResetForm />
    </Suspense>
  );
}
