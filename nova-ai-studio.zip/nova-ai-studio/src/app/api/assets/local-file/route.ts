import { NextRequest, NextResponse } from "next/server";
import path from "path";
import { promises as fs } from "fs";
import { handleApiError } from "@/lib/api";
import { AppError } from "@/lib/errors";

const LOCAL_DIR = path.join(process.cwd(), "storage");

const MIME_BY_EXT: Record<string, string> = {
  png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", webp: "image/webp", gif: "image/gif",
  mp4: "video/mp4", webm: "video/webm", mov: "video/quicktime",
  mp3: "audio/mpeg", wav: "audio/wav", ogg: "audio/ogg",
};

/** Dev-only local file server. Keys contain a random UUID and are unguessable. */
export async function GET(req: NextRequest) {
  try {
    const key = req.nextUrl.searchParams.get("key") ?? "";
    if (!/^[a-z]+\/[0-9a-f]{12}\/[a-zA-Z0-9._-]+$/.test(key)) {
      throw new AppError("NOT_FOUND", "File not found.", 404);
    }
    const full = path.join(LOCAL_DIR, key);
    if (!full.startsWith(LOCAL_DIR + path.sep)) {
      throw new AppError("NOT_FOUND", "File not found.", 404);
    }
    const buf = await fs.readFile(full).catch(() => null);
    if (!buf) throw new AppError("NOT_FOUND", "File not found.", 404);
    const ext = key.split(".").pop()?.toLowerCase() ?? "";
    return new NextResponse(buf, {
      headers: {
        "Content-Type": MIME_BY_EXT[ext] ?? "application/octet-stream",
        "Content-Length": String(buf.length),
        "Cache-Control": "public, max-age=31536000, immutable",
      },
    });
  } catch (e) {
    return handleApiError(e, "/api/assets/local-file");
  }
}
