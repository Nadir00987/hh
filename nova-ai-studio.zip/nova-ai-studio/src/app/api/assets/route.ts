import { db } from "@/lib/db";
import { paginated, withAuth } from "@/lib/api";

/** List the current user's assets (library). */
export const GET = withAuth(async (req, _ctx, user) => {
  const limit = Math.min(Number(req.nextUrl.searchParams.get("limit") ?? 24), 100);
  const cursor = req.nextUrl.searchParams.get("cursor") ?? undefined;
  const kind = req.nextUrl.searchParams.get("kind") ?? undefined;

  const items = await db.asset.findMany({
    where: { userId: user.id, deletedAt: null, ...(kind ? { kind: kind as never } : {}) },
    orderBy: { createdAt: "desc" },
    take: limit + 1,
    ...(cursor ? { cursor: { id: cursor }, skip: 1 } : {}),
    select: {
      id: true, kind: true, filename: true, mimeType: true,
      sizeBytes: true, storageKey: true, createdAt: true,
    },
  });
  const hasMore = items.length > limit;
  const page = hasMore ? items.slice(0, limit) : items;
  return paginated(page, hasMore ? page[page.length - 1].id : null);
});
