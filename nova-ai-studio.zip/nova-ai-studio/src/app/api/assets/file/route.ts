import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handleApiError } from "@/lib/api";
import { getStorage } from "@/lib/storage";
import { AppError } from "@/lib/errors";

/**
 * Serve a user's asset file.
 * For S3: redirects to a short-lived presigned URL (never proxies bytes).
 * For local dev: streams the file.
 */
export async function GET(req: NextRequest) {
  try {
    const user = await requireUser();
    const id = req.nextUrl.searchParams.get("id");
    const download = req.nextUrl.searchParams.get("download") === "1";
    if (!id) throw new AppError("VALIDATION_ERROR", "Missing asset id.", 422);

    const asset = await db.asset.findFirst({
      where: { id, userId: user.id, deletedAt: null },
      select: { storageKey: true, mimeType: true, filename: true },
    });
    if (!asset) throw new AppError("NOT_FOUND", "Asset not found.", 404);

    const storage = await getStorage();
    if (storage.kind === "s3") {
      const url = await storage.presignedDownloadUrl(asset.storageKey, 300);
      return NextResponse.redirect(url);
    }
    // Local: serve bytes directly
    const localUrl = await storage.presignedDownloadUrl(asset.storageKey);
    const res = await fetch(localUrl);
    if (!res.ok) throw new AppError("NOT_FOUND", "File not found.", 404);
    const buf = Buffer.from(await res.arrayBuffer());
    return new NextResponse(buf, {
      headers: {
        "Content-Type": asset.mimeType,
        "Content-Length": String(buf.length),
        ...(download ? { "Content-Disposition": `attachment; filename="${asset.filename}"` } : {}),
        "Cache-Control": "private, max-age=300",
      },
    });
  } catch (e) {
    return handleApiError(e, "/api/assets/file");
  }
}
