import { NextRequest, NextResponse } from "next/server";
import { createHash } from "crypto";
import path from "path";
import { promises as fs } from "fs";
import { requireUser } from "@/lib/auth";
import { handleApiError } from "@/lib/api";
import { AppError } from "@/lib/errors";

const LOCAL_DIR = path.join(process.cwd(), "storage");

/**
 * Dev-only local storage upload target.
 * The client PUTs raw file bytes here after obtaining a key from /api/assets/upload.
 */
export async function PUT(req: NextRequest) {
  try {
    const user = await requireUser();
    const key = req.nextUrl.searchParams.get("key") ?? "";
    const expectedHash = createHash("sha256").update(user.id).digest("hex").slice(0, 12);
    if (!/^[a-z]+\/[0-9a-f]{12}\/[a-zA-Z0-9._-]+$/.test(key) || !key.includes(expectedHash)) {
      throw new AppError("FORBIDDEN", "Invalid upload key.", 403);
    }
    // Prevent path traversal
    const full = path.join(LOCAL_DIR, key);
    if (!full.startsWith(LOCAL_DIR + path.sep)) {
      throw new AppError("FORBIDDEN", "Invalid upload key.", 403);
    }
    const buf = Buffer.from(await req.arrayBuffer());
    if (buf.length > 500 * 1024 * 1024) {
      throw new AppError("FILE_TOO_LARGE", "File exceeds the 500MB limit.", 413);
    }
    await fs.mkdir(path.dirname(full), { recursive: true });
    await fs.writeFile(full, buf);
    return NextResponse.json({ ok: true, data: { key, sizeBytes: buf.length } });
  } catch (e) {
    return handleApiError(e, "/api/assets/local-upload");
  }
}
