import { z } from "zod";
import { createHash } from "crypto";
import { db } from "@/lib/db";
import { ok, parseBody, withAuth } from "@/lib/api";
import { AppError } from "@/lib/errors";
const completeSchema = z.object({
  key: z.string().min(1).max(500),
  kind: z.enum(["image", "video", "audio"]),
  contentType: z.string().min(1).max(120),
  sizeBytes: z.number().int().positive(),
  projectId: z.string().optional(),
  name: z.string().max(200).optional(),
});

/** Register an uploaded file as an Asset after the client PUTs it to the presigned URL. */
export const POST = withAuth(async (req, _ctx, user) => {
  const input = await parseBody(req, completeSchema);
  // The key embeds sha256(userId) — recompute to prove this upload was issued to this user.
  // Prevents claiming other users' uploads.
  const expectedHash = createHash("sha256").update(user.id).digest("hex").slice(0, 12);
  const keyPattern = new RegExp(`^${input.kind}/${expectedHash}/[a-zA-Z0-9._-]+$`);
  if (!keyPattern.test(input.key)) {
    throw new AppError("FORBIDDEN", "Invalid upload key.", 403);
  }
  const asset = await db.asset.create({
    data: {
      userId: user.id,
      kind: input.kind.toUpperCase() as "IMAGE" | "VIDEO" | "AUDIO",
      filename: input.name ?? input.key.split("/").pop() ?? "upload",
      storageKey: input.key,
      mimeType: input.contentType,
      sizeBytes: input.sizeBytes,
      source: "upload",
    },
  });
  if (input.projectId) {
    const project = await db.project.findFirst({
      where: { id: input.projectId, userId: user.id },
      select: { id: true },
    });
    if (project) {
      await db.projectAsset.create({ data: { projectId: project.id, assetId: asset.id } }).catch(() => {});
    }
  }
  return ok(asset, { status: 201 });
}, { action: "upload" });
