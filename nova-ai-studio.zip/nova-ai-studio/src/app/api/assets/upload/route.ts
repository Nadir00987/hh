import { z } from "zod";
import { ok, parseBody, withAuth } from "@/lib/api";
import { AppError } from "@/lib/errors";
import { getStorage, storageKey } from "@/lib/storage";
import { FILE_LIMITS } from "@/lib/security";
import { randomUUID } from "crypto";

const requestSchema = z.object({
  kind: z.enum(["image", "video", "audio"]),
  contentType: z.string().min(1).max(120),
  sizeBytes: z.number().int().positive().max(500 * 1024 * 1024),
});

/**
 * Step 1 of upload: request a presigned PUT URL.
 * Step 2 (client): PUT the file bytes to the returned URL.
 * Step 3 (client): POST /api/assets/complete to register the asset.
 */
export const POST = withAuth(async (req, _ctx, user) => {
  const input = await parseBody(req, requestSchema);
  const limits = FILE_LIMITS[input.kind];
  if (!(limits.mimes as readonly string[]).includes(input.contentType)) {
    throw new AppError("VALIDATION_ERROR", `Unsupported content type for ${input.kind}.`, 422);
  }
  if (input.sizeBytes > limits.maxBytes) {
    throw new AppError("FILE_TOO_LARGE", `File exceeds the ${Math.round(limits.maxBytes / 1024 / 1024)}MB limit.`, 413);
  }
  const ext = input.contentType.split("/")[1]?.split("+")[0] ?? "bin";
  const key = storageKey(user.id, input.kind, `${randomUUID()}.${ext}`);
  const storage = await getStorage();
  const { url, headers } = await storage.presignedUploadUrl({
    key,
    contentType: input.contentType,
    sizeBytes: input.sizeBytes,
  });
  return ok({ key, uploadUrl: url, headers: headers ?? {}, contentType: input.contentType }, { status: 201 });
}, { action: "upload" });
