import { z } from "zod";
import { db } from "@/lib/db";
import { ok, parseBody, withAuth } from "@/lib/api";

const updateSchema = z.object({
  name: z.string().min(1).max(100).nullable().optional(),
});

export const GET = withAuth(async (_req, _ctx, user) => {
  const u = await db.user.findUnique({
    where: { id: user.id },
    select: { id: true, name: true, email: true, image: true, createdAt: true },
  });
  return ok(u);
});

export const PATCH = withAuth(async (req, _ctx, user) => {
  const input = await parseBody(req, updateSchema);
  const u = await db.user.update({
    where: { id: user.id },
    data: { ...(input.name !== undefined ? { name: input.name } : {}) },
    select: { id: true, name: true, email: true },
  });
  return ok(u);
});
