import { NextRequest } from "next/server";
import { z } from "zod";
import { randomUUID } from "crypto";
import { getBalance, getLedger } from "@/lib/credits";
import { ok, paginated, withAuth } from "@/lib/api";

export const GET = withAuth(async (req: NextRequest, _ctx: unknown, user) => {
  const url = req.nextUrl;
  if (url.searchParams.has("ledger")) {
    const limit = Math.min(Number(url.searchParams.get("limit") ?? 50), 100);
    const cursor = url.searchParams.get("cursor") ?? undefined;
    const rows = await getLedger(user.id, limit + 1, cursor);
    const hasMore = rows.length > limit;
    const page = hasMore ? rows.slice(0, limit) : rows;
    return paginated(page, hasMore ? page[page.length - 1].id : null);
  }
  const balance = await getBalance(user.id);
  return ok(balance);
});

const grantSchema = z.object({
  userId: z.string(),
  amount: z.number().int().positive().max(1000000),
  reason: z.string().max(255).default("admin_grant"),
});

/** Admin-only: grant credits. */
export const POST = withAuth(async (req: NextRequest, _ctx: unknown, user) => {
  const { grantCredits } = await import("@/lib/credits");
  const body = grantSchema.parse(await req.json());
  const result = await grantCredits({
    userId: body.userId,
    amount: body.amount,
    reason: body.reason,
    idempotencyKey: `admin-grant:${randomUUID()}`,
    createdById: user.id,
  });
  return ok(result, { status: 201 });
}, { admin: true });
