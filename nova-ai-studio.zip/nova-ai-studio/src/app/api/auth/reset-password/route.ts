import { NextRequest } from "next/server";
import { z } from "zod";
import bcrypt from "bcryptjs";
import { db } from "@/lib/db";
import { ok, handleApiError, parseBody } from "@/lib/api";
import { AppError } from "@/lib/errors";

const schema = z.object({
  token: z.string().min(1),
  password: z.string().min(8).max(128),
});

export async function POST(req: NextRequest) {
  try {
    const { token, password } = await parseBody(req, schema);
    const vt = await db.verificationToken.findUnique({ where: { token } });
    if (!vt || !vt.identifier.startsWith("reset:")) {
      throw new AppError("INVALID_TOKEN", "This reset link is invalid.", 400);
    }
    if (vt.expires < new Date()) {
      await db.verificationToken.delete({ where: { token } }).catch(() => {});
      throw new AppError("TOKEN_EXPIRED", "This reset link has expired.", 400);
    }
    const email = vt.identifier.slice("reset:".length);
    const passwordHash = await bcrypt.hash(password, 12);
    await db.$transaction([
      db.user.update({ where: { email }, data: { passwordHash } }),
      db.verificationToken.delete({ where: { token } }),
      // Invalidate all sessions for security
      db.session.deleteMany({ where: { user: { email } } }),
    ]);
    return ok({ reset: true });
  } catch (e) {
    return handleApiError(e, "/api/auth/reset-password");
  }
}
