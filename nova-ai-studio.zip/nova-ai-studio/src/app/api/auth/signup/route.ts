import { NextRequest } from "next/server";
import { z } from "zod";
import bcrypt from "bcryptjs";
import { db } from "@/lib/db";
import { ok, handleApiError, parseBody } from "@/lib/api";
import { AppError } from "@/lib/errors";
import { checkRateLimit } from "@/lib/ratelimit";
import { sendVerificationEmail } from "@/lib/email";
import { randomUUID } from "crypto";

const schema = z.object({
  name: z.string().min(1).max(100).optional(),
  email: z.string().email().max(255),
  password: z.string().min(8).max(128),
});

export async function POST(req: NextRequest) {
  try {
    const rl = await checkRateLimit({ key: `ip:${req.headers.get("x-forwarded-for") ?? "unknown"}`, action: "auth", tier: "free" });
    if (!rl.allowed) throw new AppError("RATE_LIMITED", undefined, 429);

    const { name, email, password } = await parseBody(req, schema);
    const normalized = email.toLowerCase().trim();

    const existing = await db.user.findUnique({ where: { email: normalized } });
    if (existing) throw new AppError("EMAIL_TAKEN", "An account with this email already exists.", 409);

    const passwordHash = await bcrypt.hash(password, 12);
    const user = await db.user.create({
      data: {
        name: name?.trim() || null,
        email: normalized,
        passwordHash,
        profile: { create: {} },
        creditBalance: { create: { available: 0, reserved: 0, lifetime: 0 } },
      },
      select: { id: true, email: true, name: true },
    });

    // Verification token (24h)
    const token = randomUUID();
    await db.verificationToken.create({
      data: {
        identifier: `verify:${normalized}`,
        token,
        expires: new Date(Date.now() + 24 * 3600 * 1000),
      },
    });
    await sendVerificationEmail(normalized, token);

    // Audit
    await db.auditLog.create({
      data: { actorId: user.id, action: "auth.signup", target: `user:${user.id}` },
    }).catch(() => {});

    return ok({ id: user.id, email: user.email });
  } catch (e) {
    return handleApiError(e, "/api/auth/signup");
  }
}
