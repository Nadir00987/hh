import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { ok, handleApiError, parseBody } from "@/lib/api";
import { sendPasswordResetEmail } from "@/lib/email";
import { randomUUID } from "crypto";

const schema = z.object({ email: z.string().email().max(255) });

export async function POST(req: NextRequest) {
  try {
    const { email } = await parseBody(req, schema);
    const normalized = email.toLowerCase().trim();
    // Always respond OK to avoid user enumeration.
    const user = await db.user.findUnique({ where: { email: normalized }, select: { id: true } });
    if (user) {
      const token = randomUUID();
      await db.verificationToken.create({
        data: {
          identifier: `reset:${normalized}`,
          token,
          expires: new Date(Date.now() + 3600 * 1000),
        },
      });
      await sendPasswordResetEmail(normalized, token);
    }
    return ok({ sent: true });
  } catch (e) {
    return handleApiError(e, "/api/auth/forgot-password");
  }
}
