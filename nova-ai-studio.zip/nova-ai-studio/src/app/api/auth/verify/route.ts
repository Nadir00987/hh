import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { ok, handleApiError, parseBody } from "@/lib/api";
import { AppError } from "@/lib/errors";

const schema = z.object({ token: z.string().min(1) });

export async function POST(req: NextRequest) {
  try {
    const { token } = await parseBody(req, schema);
    const vt = await db.verificationToken.findUnique({ where: { token } });
    if (!vt || !vt.identifier.startsWith("verify:")) {
      throw new AppError("INVALID_TOKEN", "This verification link is invalid.", 400);
    }
    if (vt.expires < new Date()) {
      await db.verificationToken.delete({ where: { token } }).catch(() => {});
      throw new AppError("TOKEN_EXPIRED", "This verification link has expired.", 400);
    }
    const email = vt.identifier.slice("verify:".length);
    await db.$transaction([
      db.user.update({ where: { email }, data: { emailVerified: new Date() } }),
      db.verificationToken.delete({ where: { token } }),
    ]);
    return ok({ verified: true });
  } catch (e) {
    return handleApiError(e, "/api/auth/verify");
  }
}
