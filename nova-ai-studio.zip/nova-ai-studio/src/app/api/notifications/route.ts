import { z } from "zod";
import { db } from "@/lib/db";
import { ok, paginated, parseBody, withAuth } from "@/lib/api";
import { AppError } from "@/lib/errors";

export const GET = withAuth(async (req, _ctx, user) => {
  const limit = Math.min(Number(req.nextUrl.searchParams.get("limit") ?? 30), 100);
  const cursor = req.nextUrl.searchParams.get("cursor") ?? undefined;
  const unreadOnly = req.nextUrl.searchParams.get("unread") === "1";
  const items = await db.notification.findMany({
    where: { userId: user.id, ...(unreadOnly ? { read: false } : {}) },
    orderBy: { createdAt: "desc" },
    take: limit + 1,
    ...(cursor ? { cursor: { id: cursor }, skip: 1 } : {}),
  });
  const hasMore = items.length > limit;
  const page = hasMore ? items.slice(0, limit) : items;
  const unreadCount = await db.notification.count({ where: { userId: user.id, read: false } });
  const res = paginated(page, hasMore ? page[page.length - 1].id : null);
  res.headers.set("X-Unread-Count", String(unreadCount));
  return res;
});

const readSchema = z.object({
  ids: z.array(z.string()).max(100).optional(),
  all: z.boolean().optional(),
});

/** Mark notifications as read. */
export const POST = withAuth(async (req, _ctx, user) => {
  const input = await parseBody(req, readSchema);
  if (input.all) {
    await db.notification.updateMany({
      where: { userId: user.id, read: false },
      data: { read: true },
    });
  } else if (input.ids?.length) {
    await db.notification.updateMany({
      where: { id: { in: input.ids }, userId: user.id },
      data: { read: true },
    });
  } else {
    throw new AppError("VALIDATION_ERROR", "Provide ids or all=true.", 422);
  }
  return ok({ read: true });
});
