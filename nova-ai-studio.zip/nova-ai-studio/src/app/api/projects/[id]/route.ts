import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { ok, parseBody, withAuth } from "@/lib/api";
import { AppError } from "@/lib/errors";

const updateSchema = z.object({
  name: z.string().min(1).max(120).optional(),
  description: z.string().max(2000).nullable().optional(),
  color: z.string().regex(/^#[0-9a-fA-F]{6}$/).nullable().optional(),
  coverAssetId: z.string().nullable().optional(),
});

export const GET = withAuth(async (_req: NextRequest, ctx: { params: { id: string } }, user) => {
  const project = await db.project.findFirst({
    where: { id: ctx.params.id, userId: user.id },
    include: {
      generations: {
        orderBy: { createdAt: "desc" },
        take: 24,
        select: {
          id: true, type: true, status: true, progress: true, createdAt: true,
          outputAssets: { select: { id: true, kind: true, storageKey: true, mimeType: true } },
        },
      },
      assets: {
        orderBy: { addedAt: "desc" },
        take: 24,
        select: {
          asset: { select: { id: true, kind: true, storageKey: true, mimeType: true, filename: true, createdAt: true } },
        },
      },
    },
  });
  if (!project) throw new AppError("NOT_FOUND", "Project not found.", 404);
  return ok(project);
});

export const PATCH = withAuth(async (req: NextRequest, ctx: { params: { id: string } }, user) => {
  const input = await parseBody(req, updateSchema);
  const project = await db.project.findFirst({ where: { id: ctx.params.id, userId: user.id }, select: { id: true } });
  if (!project) throw new AppError("NOT_FOUND", "Project not found.", 404);
  const updated = await db.project.update({
    where: { id: project.id },
    data: {
      ...(input.name ? { name: input.name.trim() } : {}),
      ...(input.description !== undefined ? { description: input.description } : {}),
      ...(input.color !== undefined ? { color: input.color } : {}),
      ...(input.coverAssetId !== undefined ? { coverAssetId: input.coverAssetId } : {}),
    },
  });
  return ok(updated);
});

export const DELETE = withAuth(async (_req: NextRequest, ctx: { params: { id: string } }, user) => {
  const project = await db.project.findFirst({ where: { id: ctx.params.id, userId: user.id }, select: { id: true } });
  if (!project) throw new AppError("NOT_FOUND", "Project not found.", 404);
  // Unlink generations/assets rather than deleting user content
  await db.$transaction([
    db.generation.updateMany({ where: { projectId: project.id }, data: { projectId: null } }),
    db.projectAsset.deleteMany({ where: { projectId: project.id } }),
    db.project.delete({ where: { id: project.id } }),
  ]);
  return ok({ deleted: true });
});
