import { z } from "zod";
import { db } from "@/lib/db";
import { ok, paginated, parseBody, withAuth } from "@/lib/api";

const createSchema = z.object({
  name: z.string().min(1).max(120),
  description: z.string().max(2000).optional(),
  color: z.string().regex(/^#[0-9a-fA-F]{6}$/).optional(),
});

export const POST = withAuth(async (req, _ctx, user) => {
  const input = await parseBody(req, createSchema);
  const project = await db.project.create({
    data: { userId: user.id, name: input.name.trim(), description: input.description, color: input.color },
  });
  // Audit
  await db.auditLog.create({
    data: { actorId: user.id, action: "project.create", target: `project:${project.id}` },
  }).catch(() => {});
  return ok(project, { status: 201 });
});

export const GET = withAuth(async (req, _ctx, user) => {
  const limit = Math.min(Number(req.nextUrl.searchParams.get("limit") ?? 50), 100);
  const cursor = req.nextUrl.searchParams.get("cursor") ?? undefined;
  const items = await db.project.findMany({
    where: { userId: user.id },
    orderBy: { updatedAt: "desc" },
    take: limit + 1,
    ...(cursor ? { cursor: { id: cursor }, skip: 1 } : {}),
    include: {
      _count: { select: { generations: true, assets: true } },
    },
  });
  const hasMore = items.length > limit;
  const page = hasMore ? items.slice(0, limit) : items;
  return paginated(page, hasMore ? page[page.length - 1].id : null);
});
