import { NextRequest } from "next/server";
import { getModelRegistry } from "@/lib/ai/registry";
import { ok, handleApiError } from "@/lib/api";
import { generationTypeSchema } from "@/lib/validation";

/** Public model catalog — only enabled, configured models. No API keys leak. */
export async function GET(req: NextRequest) {
  try {
    const rawType = req.nextUrl.searchParams.get("type");
    const type = rawType ? generationTypeSchema.parse(rawType) : undefined;
    const models = await getModelRegistry();
    const filtered = type ? models.filter((m) => m.type === type) : models;
    return ok(filtered.map((m) => ({
      id: m.id,
      name: m.name,
      providerId: m.providerId,
      providerName: m.providerName,
      type: m.type,
      capabilities: m.capabilities,
      enabled: m.enabled,
      configured: m.configured,
    })));
  } catch (e) {
    return handleApiError(e, "/api/models");
  }
}
