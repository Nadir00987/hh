import { z } from "zod";
import { ok, parseBody, withAuth } from "@/lib/api";
import { getTextProvider } from "@/lib/ai/provider-factory";
import { moderatePrompt } from "@/lib/moderation";
import { generationTypeSchema } from "@/lib/validation";
import { AppError } from "@/lib/errors";

const schema = z.object({
  prompt: z.string().min(1).max(4000),
  type: generationTypeSchema.default("TEXT_TO_VIDEO"),
});

/**
 * Enhance a rough prompt into a production-quality generation prompt
 * using the configured text provider. Returns the original prompt if no
 * text provider is configured.
 */
export const POST = withAuth(async (req) => {
  const input = await parseBody(req, schema);

  const mod = moderatePrompt(input.prompt);
  if (!mod.allowed) {
    throw new AppError("MODERATION_REJECTED", mod.reason ?? "This prompt can't be used.", 422);
  }

  const provider = getTextProvider("openai-compatible");
  if (!provider) {
    return ok({ enhanced: input.prompt, providerUsed: false, reason: "no_text_provider" });
  }

  const systemPrompt = `You are a prompt engineer for AI media generation. Rewrite the user's rough idea into a rich, detailed, production-quality prompt for ${input.type.toLowerCase().replace(/_/g, " ")}. Include subject, action, setting, lighting, camera/motion details where relevant, style, and mood. Return ONLY the rewritten prompt, no preamble.`;
  try {
    const text = (await provider.completeText({
      systemPrompt,
      userPrompt: input.prompt,
      maxTokens: 500,
    })).trim();
    return ok({ enhanced: text || input.prompt, providerUsed: true });
  } catch {
    return ok({ enhanced: input.prompt, providerUsed: false, reason: "provider_error" });
  }
}, { action: "prompt-enhance" });
