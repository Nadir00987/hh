import { z } from "zod";
import { db } from "@/lib/db";
import { ok, paginated, parseBody, withAuth } from "@/lib/api";
import { createGeneration } from "@/lib/generations";
import { generationTypeSchema, generationStatusSchema } from "@/lib/validation";
import { AppError } from "@/lib/errors";

const createSchema = z.object({
  type: generationTypeSchema,
  modelId: z.string().min(1).max(120),
  prompt: z.string().min(1).max(8000),
  negativePrompt: z.string().max(4000).optional(),
  settings: z.record(z.string(), z.unknown()).default({}),
  projectId: z.string().optional(),
  parentId: z.string().optional(),
  idempotencyKey: z.string().max(120).optional(),
});

export const POST = withAuth(async (req, _ctx, user) => {
  const input = await parseBody(req, createSchema);
  if (input.projectId) {
    const project = await db.project.findFirst({
      where: { id: input.projectId, userId: user.id },
      select: { id: true },
    });
    if (!project) throw new AppError("NOT_FOUND", "Project not found.", 404);
  }
  const gen = await createGeneration({
    userId: user.id,
    type: input.type,
    modelId: input.modelId,
    prompt: input.prompt,
    negativePrompt: input.negativePrompt,
    settings: input.settings as Record<string, unknown>,
    projectId: input.projectId,
    parentId: input.parentId,
    idempotencyKey: input.idempotencyKey,
  });
  return ok(gen, { status: 201 });
}, { action: "generation" });

const listQuery = z.object({
  cursor: z.string().optional(),
  limit: z.coerce.number().min(1).max(100).default(24),
  status: generationStatusSchema.optional(),
  type: generationTypeSchema.optional(),
  projectId: z.string().optional(),
});

const generationSelect = {
  id: true,
  type: true,
  status: true,
  prompt: true,
  model: true,
  provider: true,
  progress: true,
  creditsReserved: true,
  creditsCharged: true,
  errorMessage: true,
  createdAt: true,
  completedAt: true,
  outputAssets: {
    select: { id: true, kind: true, storageKey: true, mimeType: true, thumbnailKey: true },
  },
} as const;

export const GET = withAuth(async (req, _ctx, user) => {
  const q = listQuery.parse(Object.fromEntries(req.nextUrl.searchParams));
  const items = await db.generation.findMany({
    where: {
      userId: user.id,
      ...(q.status ? { status: q.status } : {}),
      ...(q.type ? { type: q.type } : {}),
      ...(q.projectId ? { projectId: q.projectId } : {}),
    },
    orderBy: { createdAt: "desc" },
    take: q.limit + 1,
    ...(q.cursor ? { cursor: { id: q.cursor }, skip: 1 } : {}),
    select: generationSelect,
  });
  const hasMore = items.length > q.limit;
  const page = hasMore ? items.slice(0, q.limit) : items;
  return paginated(page, hasMore ? page[page.length - 1].id : null);
});
