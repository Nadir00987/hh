import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { handleApiError } from "@/lib/api";
import { subscribeToGeneration } from "@/lib/realtime";

/**
 * Server-Sent Events stream for a single generation.
 * Emits: status updates, progress, completion/failure.
 * Auth is checked before the stream opens.
 */
export async function GET(req: NextRequest, ctx: { params: { id: string } }) {
  try {
    const user = await requireUser();
    const gen = await db.generation.findFirst({
      where: { id: ctx.params.id, userId: user.id },
      select: { id: true, status: true, progress: true },
    });
    if (!gen) {
      return new Response(JSON.stringify({ ok: false, error: { code: "NOT_FOUND" } }), {
        status: 404,
        headers: { "Content-Type": "application/json" },
      });
    }

    const stream = new ReadableStream({
      async start(controller) {
        const enc = new TextEncoder();
        const send = (event: string, data: unknown) => {
          controller.enqueue(enc.encode(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`));
        };

        // Initial state
        send("state", { id: gen.id, status: gen.status, progress: gen.progress });

        const unsubscribe = await subscribeToGeneration(gen.id, (update) => {
          send("update", update);
          if (["COMPLETED", "FAILED", "CANCELLED"].includes(update.status)) {
            // Give the client a beat to process, then close
            setTimeout(() => {
              try { controller.close(); } catch { /* already closed */ }
              unsubscribe();
            }, 500);
          }
        });

        // Heartbeat to keep proxies alive
        const hb = setInterval(() => {
          try { controller.enqueue(enc.encode(`: heartbeat\n\n`)); }
          catch { clearInterval(hb); }
        }, 25000);

        req.signal.addEventListener("abort", () => {
          clearInterval(hb);
          unsubscribe();
          try { controller.close(); } catch { /* noop */ }
        });
      },
    });

    return new Response(stream, {
      headers: {
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache, no-transform",
        Connection: "keep-alive",
        "X-Accel-Buffering": "no",
      },
    });
  } catch (e) {
    return handleApiError(e, "/api/generations/[id]/events");
  }
}
