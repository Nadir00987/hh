import { NextRequest } from "next/server";
import { withAuth, ok } from "@/lib/api";
import { transitionGeneration, getGenerationForUser } from "@/lib/generations";
import { AppError } from "@/lib/errors";

/** Cancel a queued/processing generation. Releases reserved credits. */
export const POST = withAuth(async (_req: NextRequest, ctx: { params: { id: string } }, user) => {
  const gen = await getGenerationForUser(ctx.params.id, user.id);
  if (!gen) throw new AppError("NOT_FOUND", "Generation not found.", 404);
  if (["COMPLETED", "FAILED", "CANCELLED"].includes(gen.status)) {
    throw new AppError("INVALID_STATE", `Cannot cancel a ${gen.status.toLowerCase()} generation.`, 409);
  }
  const updated = await transitionGeneration(gen.id, "CANCELLED", { message: "Cancelled by user" });
  return ok({ id: updated.id, status: updated.status });
});
