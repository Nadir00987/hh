import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, withAuth } from "@/lib/api";
import { getGenerationForUser } from "@/lib/generations";

export const GET = withAuth(async (_req: NextRequest, ctx: { params: { id: string } }, user) => {
  const gen = await getGenerationForUser(ctx.params.id, user.id);
  if (!gen) {
    const { AppError } = await import("@/lib/errors");
    throw new AppError("NOT_FOUND", "Generation not found.", 404);
  }
  // Include recent events for the detail view
  const events = await db.generationEvent.findMany({
    where: { generationId: gen.id },
    orderBy: { createdAt: "asc" },
    take: 50,
    select: { id: true, fromStatus: true, toStatus: true, message: true, createdAt: true },
  });
  return ok({ ...gen, events });
});
