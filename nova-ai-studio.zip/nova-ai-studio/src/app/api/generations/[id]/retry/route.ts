import { NextRequest } from "next/server";
import { z } from "zod";
import { withAuth, ok, parseBody } from "@/lib/api";
import { retryGeneration } from "@/lib/generations";

const schema = z.object({
  prompt: z.string().min(1).max(8000).optional(),
  settings: z.record(z.string(), z.unknown()).optional(),
  modelId: z.string().min(1).max(120).optional(),
});

/** Retry a failed/cancelled generation — creates a new generation linked via parentId. */
export const POST = withAuth(async (req: NextRequest, ctx: { params: { id: string } }, user) => {
  const body = await parseBody(req, schema);
  const gen = await retryGeneration(ctx.params.id, user.id, {
    prompt: body.prompt,
    settings: body.settings as Record<string, unknown> | undefined,
    modelId: body.modelId,
  });
  return ok(gen, { status: 201 });
}, { action: "generation" });
