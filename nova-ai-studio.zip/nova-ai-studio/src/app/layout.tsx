import type { Metadata, Viewport } from "next";
import localFont from "next/font/local";
import "./globals.css";
import { ToastProvider } from "@/components/ui/toast";

const geistSans = localFont({
  src: "./fonts/GeistVF.woff",
  variable: "--font-geist-sans",
  weight: "100 900",
});

export const metadata: Metadata = {
  metadataBase: new URL(process.env.APP_URL ?? "http://localhost:3000"),
  title: {
    default: "Nova AI Studio — Create. Generate. Transform.",
    template: "%s · Nova AI Studio",
  },
  description:
    "Nova AI Studio is a professional AI creative studio: generate videos, images, voice and scripts from one unified workspace.",
  openGraph: {
    title: "Nova AI Studio — Create. Generate. Transform.",
    description: "Professional AI creative studio: video, image, audio and content generation in one workspace.",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Nova AI Studio",
    description: "Professional AI creative studio: video, image, audio and content generation.",
  },
  robots: { index: true, follow: true },
};

export const viewport: Viewport = {
  themeColor: "#09090b",
  width: "device-width",
  initialScale: 1,
};

// Set the theme before first paint to avoid a flash of the wrong theme.
const themeInit = `(function(){try{var t=localStorage.getItem('nova-theme')||document.cookie.match(/nova-theme=(dark|light)/)?.[1]||'dark';document.documentElement.setAttribute('data-theme',t);}catch(e){document.documentElement.setAttribute('data-theme','dark');}})();`;

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap"
          rel="stylesheet"
        />
        <script dangerouslySetInnerHTML={{ __html: themeInit }} />
      </head>
      <body className={`${geistSans.variable} antialiased`}>
        <ToastProvider>{children}</ToastProvider>
      </body>
    </html>
  );
}
