import Link from "next/link";
import { auth } from "@/lib/auth";
import { redirect } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Sparkles, Zap, FolderKanban, Bell, Shield, Layers } from "lucide-react";

const FEATURES = [
  { icon: Sparkles, title: "AI Video Generation", desc: "Text-to-video, image-to-video, and video extension with live progress streaming." },
  { icon: Layers, title: "Images, Audio & More", desc: "Image generation and editing, text-to-speech, music, scripts, and storyboards." },
  { icon: Zap, title: "Honest Credits", desc: "Reserve → charge or release. Failed jobs refund automatically. Every transaction logged." },
  { icon: FolderKanban, title: "Projects & Library", desc: "Organize generations and assets into projects with full version lineage." },
  { icon: Bell, title: "Realtime Everything", desc: "Live job status via SSE, in-app notifications, and a complete event timeline." },
  { icon: Shield, title: "Security First", desc: "Server-side authorization on every route, audit logging, and no fake generations — ever." },
];

export default async function LandingPage() {
  const session = await auth();
  if (session?.user?.id) redirect("/dashboard");

  return (
    <div className="min-h-screen">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-5">
        <span className="text-xl font-bold tracking-tight">NOVA <span className="text-primary">AI STUDIO</span></span>
        <div className="flex gap-3">
          <Link href="/login"><Button variant="ghost">Sign in</Button></Link>
          <Link href="/signup"><Button>Get started</Button></Link>
        </div>
      </header>

      <main>
        <section className="mx-auto max-w-6xl px-6 py-20 text-center lg:py-28">
          <h1 className="mx-auto max-w-3xl text-4xl font-bold leading-tight tracking-tight lg:text-6xl">
            The unified AI creative studio
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg text-muted">
            Generate video, images, voice, and scripts from one workspace —
            with realtime progress, honest credit billing, and project organization.
          </p>
          <div className="mt-8 flex justify-center gap-4">
            <Link href="/signup"><Button size="lg">Start creating free</Button></Link>
            <Link href="/login"><Button size="lg" variant="secondary">Sign in</Button></Link>
          </div>
          <p className="mt-4 text-sm text-faint">No fake generations. Real providers, real progress, real results.</p>
        </section>

        <section className="mx-auto max-w-6xl px-6 pb-20">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {FEATURES.map((f) => (
              <div key={f.title} className="rounded-xl border border-border bg-surface p-6">
                <f.icon className="h-6 w-6 text-primary" />
                <h3 className="mt-4 font-semibold">{f.title}</h3>
                <p className="mt-2 text-sm text-muted">{f.desc}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="border-t border-border">
          <div className="mx-auto max-w-6xl px-6 py-16 text-center">
            <h2 className="text-2xl font-bold">Ready to create?</h2>
            <p className="mt-2 text-muted">Your studio is one signup away.</p>
            <Link href="/signup"><Button size="lg" className="mt-6">Get started</Button></Link>
          </div>
        </section>
      </main>

      <footer className="border-t border-border">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-6 text-sm text-faint">
          <span>NOVA AI STUDIO</span>
          <span>Built for creators.</span>
        </div>
      </footer>
    </div>
  );
}
