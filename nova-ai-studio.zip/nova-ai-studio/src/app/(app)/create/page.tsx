"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Textarea, Select } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Sparkles, Wand2, AlertCircle } from "lucide-react";

interface Model {
  id: string;
  name: string;
  providerId: string;
  providerName: string;
  type: string;
  capabilities: Record<string, unknown>;
  enabled: boolean;
  configured: boolean;
}

const TYPE_GROUPS: { label: string; types: string[] }[] = [
  { label: "Video", types: ["TEXT_TO_VIDEO", "IMAGE_TO_VIDEO", "VIDEO_TO_VIDEO", "VIDEO_EXTEND"] },
  { label: "Image", types: ["TEXT_TO_IMAGE", "IMAGE_EDIT", "BACKGROUND_REMOVE", "IMAGE_UPSCALE"] },
  { label: "Audio", types: ["TEXT_TO_SPEECH", "VOICE_CLONE", "SOUND_EFFECT", "MUSIC"] },
  { label: "Content", types: ["SUBTITLES", "SCRIPT", "STORYBOARD", "PROMPT_ENHANCE"] },
];

export default function CreatePage() {
  const router = useRouter();
  const [models, setModels] = useState<Model[]>([]);
  const [loadingModels, setLoadingModels] = useState(true);
  const [type, setType] = useState("TEXT_TO_VIDEO");
  const [modelId, setModelId] = useState("");
  const [prompt, setPrompt] = useState("");
  const [enhancing, setEnhancing] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetch("/api/models")
      .then((r) => r.json())
      .then((j) => { if (j.ok) setModels(j.data); })
      .finally(() => setLoadingModels(false));
    // Pick up a template from the templates page
    try {
      const raw = sessionStorage.getItem("nova-template");
      if (raw) {
        const t = JSON.parse(raw) as { type?: string; prompt?: string };
        if (t.type) setType(t.type);
        if (t.prompt) setPrompt(t.prompt);
        sessionStorage.removeItem("nova-template");
      }
    } catch { /* ignore */ }
  }, []);

  const typeModels = useMemo(() => models.filter((m) => m.type === type && m.enabled), [models, type]);
  const selected = typeModels.find((m) => m.id === modelId) ?? typeModels[0];

  useEffect(() => {
    if (selected && modelId !== selected.id) setModelId(selected.id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [type, models]);

  async function enhance() {
    if (!prompt.trim() || enhancing) return;
    setEnhancing(true);
    try {
      const res = await fetch("/api/prompts/enhance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt, type }),
      });
      const json = await res.json();
      if (json.ok && json.data.enhanced) setPrompt(json.data.enhanced);
    } finally {
      setEnhancing(false);
    }
  }

  async function submit() {
    if (!selected || !prompt.trim() || submitting) return;
    setError(null);
    setSubmitting(true);
    try {
      const res = await fetch("/api/generations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type,
          modelId: selected.id,
          prompt: prompt.trim(),
          settings: {},
          idempotencyKey: `ui:${Date.now()}:${Math.random().toString(36).slice(2)}`,
        }),
      });
      const json = await res.json();
      if (!json.ok) {
        setError(json.error?.message ?? "Generation failed to start.");
      } else {
        router.push(`/generations/${json.data.id}`);
      }
    } catch {
      setError("Network error. Try again.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="mx-auto max-w-4xl space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Create</h1>
        <p className="mt-1 text-muted">Describe what you want — pick a model and generate.</p>
      </div>

      <div className="rounded-xl border border-border bg-surface p-6 space-y-6">
        <div>
          <label className="mb-2 block text-sm font-medium">What are you making?</label>
          <div className="flex flex-wrap gap-2">
            {TYPE_GROUPS.flatMap((g) => g.types).map((t) => (
              <button key={t} type="button" onClick={() => setType(t)}
                className={`rounded-lg border px-3 py-2 text-sm transition-micro ${type === t
                  ? "border-primary bg-primary-soft text-primary"
                  : "border-border text-muted hover:border-border-strong hover:text-foreground"}`}>
                {t.replace(/_/g, " ").toLowerCase().replace(/\b\w/g, (c) => c.toUpperCase())}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label htmlFor="model" className="mb-2 block text-sm font-medium">Model</label>
          {loadingModels ? (
            <p className="text-sm text-muted">Loading models…</p>
          ) : typeModels.length === 0 ? (
            <p className="rounded-lg bg-warning/10 px-3 py-2 text-sm text-warning">
              No models available for this type yet.
            </p>
          ) : (
            <>
              <Select id="model" value={selected?.id ?? ""} onChange={(e) => setModelId(e.target.value)}>
                {typeModels.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.name} — {m.providerName}{m.configured ? "" : " (not configured)"}
                  </option>
                ))}
              </Select>
              {selected && !selected.configured && (
                <p className="mt-2 flex items-start gap-2 rounded-lg bg-warning/10 px-3 py-2 text-sm text-warning">
                  <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
                  This model&apos;s provider isn&apos;t configured on the server yet.
                  Generation will fail — pick a configured model or ask your admin to add API keys.
                </p>
              )}
            </>
          )}
        </div>

        <div>
          <div className="mb-2 flex items-center justify-between">
            <label htmlFor="prompt" className="text-sm font-medium">Prompt</label>
            <Button variant="ghost" size="sm" onClick={enhance} disabled={!prompt.trim() || enhancing}>
              <Wand2 className="h-3.5 w-3.5" /> {enhancing ? "Enhancing…" : "Enhance with AI"}
            </Button>
          </div>
          <Textarea id="prompt" value={prompt} onChange={(e) => setPrompt(e.target.value)}
            placeholder="A cinematic drone shot over a misty forest at dawn…" rows={5} />
        </div>

        {error && (
          <p className="rounded-lg bg-error/10 px-3 py-2 text-sm text-error" role="alert">{error}</p>
        )}

        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-sm text-muted">
            {selected && (
              <>
                <Badge tone={selected.configured ? "success" : "warning"}>
                  {selected.configured ? "Ready" : "Not configured"}
                </Badge>
                <span className="text-faint">{selected.providerName}</span>
              </>
            )}
          </div>
          <Button size="lg" onClick={submit} loading={submitting}
            disabled={!selected || !prompt.trim() || !selected.configured}>
            <Sparkles className="h-4 w-4" /> Generate
          </Button>
        </div>
      </div>

      <div className="rounded-xl border border-border bg-surface p-6">
        <h2 className="font-semibold">Available providers</h2>
        <div className="mt-3 flex flex-wrap gap-2">
          {Array.from(new Set(models.map((m) => m.providerName))).map((p) => {
            const provModels = models.filter((m) => m.providerName === p);
            const anyConfigured = provModels.some((m) => m.configured);
            return (
              <Badge key={p} tone={anyConfigured ? "success" : "default"}>
                {p} {anyConfigured ? "●" : "○"}
              </Badge>
            );
          })}
        </div>
        <p className="mt-3 text-sm text-faint">
          ● configured and ready · ○ needs API keys in the server environment
        </p>
      </div>
    </div>
  );
}
