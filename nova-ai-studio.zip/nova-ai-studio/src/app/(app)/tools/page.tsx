"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/input";
import { Wand2, Scissors, ArrowUpCircle, Volume2 } from "lucide-react";

const TOOLS = [
  {
    id: "enhance",
    icon: Wand2,
    name: "Prompt Enhancer",
    description: "Turn a rough idea into a production-quality generation prompt.",
    action: "enhance" as const,
  },
  {
    id: "upscale",
    icon: ArrowUpCircle,
    name: "Image Upscaler",
    description: "Increase image resolution while preserving detail. Starts an IMAGE_UPSCALE generation.",
    action: "upscale" as const,
  },
  {
    id: "bg-remove",
    icon: Scissors,
    name: "Background Remover",
    description: "Remove the background from an image. Starts a BACKGROUND_REMOVE generation.",
    action: "bgremove" as const,
  },
  {
    id: "tts",
    icon: Volume2,
    name: "Text to Speech",
    description: "Convert text into natural-sounding speech. Starts a TEXT_TO_SPEECH generation.",
    action: "tts" as const,
  },
];

export default function ToolsPage() {
  const [text, setText] = useState("");
  const [result, setResult] = useState<string | null>(null);
  const [working, setWorking] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function runEnhance() {
    if (!text.trim() || working) return;
    setWorking(true);
    setError(null);
    setResult(null);
    try {
      const res = await fetch("/api/prompts/enhance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: text, type: "TEXT_TO_VIDEO" }),
      });
      const json = await res.json();
      if (json.ok) setResult(json.data.enhanced);
      else setError(json.error?.message ?? "Enhancement failed.");
    } catch {
      setError("Network error.");
    } finally {
      setWorking(false);
    }
  }

  return (
    <div className="mx-auto max-w-4xl space-y-8">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">AI Tools</h1>
        <p className="mt-1 text-muted">Focused utilities powered by your configured providers.</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        {TOOLS.map((t) => (
          <div key={t.id} className="rounded-xl border border-border bg-surface p-5">
            <t.icon className="h-6 w-6 text-primary" />
            <h3 className="mt-3 font-semibold">{t.name}</h3>
            <p className="mt-1 text-sm text-muted">{t.description}</p>
          </div>
        ))}
      </div>

      <div className="rounded-xl border border-border bg-surface p-6">
        <h2 className="font-semibold">Try the Prompt Enhancer</h2>
        <p className="mt-1 text-sm text-muted">Type a rough idea below and enhance it instantly.</p>
        <Textarea className="mt-4" rows={3} value={text}
          onChange={(e) => setText(e.target.value)} placeholder="a cool robot…" />
        {error && <p className="mt-3 rounded-lg bg-error/10 px-3 py-2 text-sm text-error">{error}</p>}
        {result && (
          <div className="mt-3 rounded-lg bg-background p-4 text-sm">
            <p className="mb-1 text-xs font-medium uppercase tracking-wide text-faint">Enhanced</p>
            {result}
          </div>
        )}
        <Button className="mt-4" onClick={runEnhance} loading={working} disabled={!text.trim()}>
          <Wand2 className="h-4 w-4" /> Enhance
        </Button>
      </div>
    </div>
  );
}
