"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { EmptyState } from "@/components/ui/feedback";
import { FolderKanban, Plus } from "lucide-react";

interface Project { id: string; name: string; description: string | null; updatedAt: string; _count?: { generations: number } }

export default function ProjectsPage() {
  const [items, setItems] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [name, setName] = useState("");
  const [creating, setCreating] = useState(false);

  async function load() {
    setLoading(true);
    try {
      const res = await fetch("/api/projects");
      const json = await res.json();
      if (json.ok) setItems(json.data.items);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, []);

  async function create() {
    if (!name.trim() || creating) return;
    setCreating(true);
    try {
      const res = await fetch("/api/projects", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: name.trim() }),
      });
      const json = await res.json();
      if (json.ok) { setName(""); load(); }
    } finally {
      setCreating(false);
    }
  }

  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Projects</h1>
        <p className="mt-1 text-muted">Organize generations and assets into projects.</p>
      </div>

      <div className="flex gap-2 rounded-xl border border-border bg-surface p-4">
        <Input value={name} onChange={(e) => setName(e.target.value)}
          placeholder="New project name…" onKeyDown={(e) => e.key === "Enter" && create()} />
        <Button onClick={create} loading={creating} disabled={!name.trim()}>
          <Plus className="h-4 w-4" /> Create
        </Button>
      </div>

      {items.length === 0 && !loading ? (
        <EmptyState title="No projects yet" body="Create a project to organize your work."
          icon={<FolderKanban className="h-8 w-8" />} />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((p) => (
            <Link key={p.id} href={`/projects/${p.id}`}
              className="rounded-xl border border-border bg-surface p-5 transition-micro hover:border-border-strong">
              <div className="flex items-center gap-2">
                <FolderKanban className="h-5 w-5 text-primary" />
                <h3 className="font-semibold">{p.name}</h3>
              </div>
              {p.description && <p className="mt-2 line-clamp-2 text-sm text-muted">{p.description}</p>}
              <p className="mt-3 text-xs text-faint">
                {p._count?.generations ?? 0} generations · updated {new Date(p.updatedAt).toLocaleDateString()}
              </p>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
