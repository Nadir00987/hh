"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import { EmptyState } from "@/components/ui/feedback";
import { ArrowLeft } from "lucide-react";

interface ProjectDetail {
  id: string;
  name: string;
  description: string | null;
  generations: { id: string; type: string; status: string; createdAt: string; outputAssets: { id: string }[] }[];
  assets: { asset: { id: string; filename: string; mimeType: string } }[];
}

const STATUS_TONE: Record<string, "default" | "success" | "warning" | "error" | "info"> = {
  QUEUED: "default", PROCESSING: "info", GENERATING: "info", FINALIZING: "info",
  COMPLETED: "success", FAILED: "error", CANCELLED: "warning",
};

export default function ProjectDetailPage() {
  const params = useParams();
  const id = params.id as string;
  const [project, setProject] = useState<ProjectDetail | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetch(`/api/projects/${id}`)
      .then((r) => r.json())
      .then((j) => {
        if (j.ok) setProject(j.data);
        else setError(j.error?.message ?? "Not found.");
      })
      .catch(() => setError("Network error."));
  }, [id]);

  if (error) return <EmptyState title="Not found" body={error} />;
  if (!project) return <p className="text-muted">Loading…</p>;

  return (
    <div className="mx-auto max-w-6xl space-y-8">
      <Link href="/projects" className="inline-flex items-center gap-2 text-sm text-muted hover:text-foreground">
        <ArrowLeft className="h-4 w-4" /> All projects
      </Link>
      <div>
        <h1 className="text-2xl font-bold tracking-tight">{project.name}</h1>
        {project.description && <p className="mt-1 text-muted">{project.description}</p>}
      </div>

      <div>
        <h2 className="mb-4 text-lg font-semibold">Generations</h2>
        {project.generations.length === 0 ? (
          <p className="text-sm text-muted">No generations in this project yet.</p>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {project.generations.map((g) => (
              <Link key={g.id} href={`/generations/${g.id}`}
                className="rounded-xl border border-border bg-surface p-4 transition-micro hover:border-border-strong">
                <div className="flex items-center justify-between gap-2">
                  <Badge tone={STATUS_TONE[g.status] ?? "default"}>{g.status}</Badge>
                  <span className="text-xs text-faint">{g.type.replace(/_/g, " ")}</span>
                </div>
                <p className="mt-2 text-xs text-faint">{new Date(g.createdAt).toLocaleString()}</p>
              </Link>
            ))}
          </div>
        )}
      </div>

      <div>
        <h2 className="mb-4 text-lg font-semibold">Assets</h2>
        {project.assets.length === 0 ? (
          <p className="text-sm text-muted">No assets in this project yet.</p>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {project.assets.map(({ asset: a }) => (
              <div key={a.id} className="overflow-hidden rounded-xl border border-border bg-surface">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={`/api/assets/file?id=${a.id}`} alt={a.filename}
                  className="aspect-video w-full object-cover" loading="lazy" />
                <p className="truncate p-3 text-sm">{a.filename}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
