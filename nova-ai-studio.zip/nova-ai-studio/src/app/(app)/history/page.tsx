"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import { EmptyState } from "@/components/ui/feedback";
import { Select } from "@/components/ui/input";
import { Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";

interface Gen {
  id: string;
  type: string;
  status: string;
  prompt: string;
  createdAt: string;
}

const STATUS_TONE: Record<string, "default" | "success" | "warning" | "error" | "info"> = {
  QUEUED: "default", PROCESSING: "info", GENERATING: "info", FINALIZING: "info",
  COMPLETED: "success", FAILED: "error", CANCELLED: "warning",
};

export default function HistoryPage() {
  const [items, setItems] = useState<Gen[]>([]);
  const [loading, setLoading] = useState(true);
  const [status, setStatus] = useState("");
  const [cursor, setCursor] = useState<string | null>(null);

  async function load(next?: string) {
    setLoading(true);
    try {
      const qs = new URLSearchParams({ limit: "24" });
      if (status) qs.set("status", status);
      if (next) qs.set("cursor", next);
      const res = await fetch(`/api/generations?${qs}`);
      const json = await res.json();
      if (json.ok) {
        setItems((prev) => next ? [...prev, ...json.data.items] : json.data.items);
        setCursor(json.data.nextCursor);
      }
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { setItems([]); load(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [status]);

  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">History</h1>
          <p className="mt-1 text-muted">Every generation, newest first.</p>
        </div>
        <div className="flex gap-2">
          <Select value={status} onChange={(e) => setStatus(e.target.value)} aria-label="Filter by status">
            <option value="">All statuses</option>
            {Object.keys(STATUS_TONE).map((s) => <option key={s} value={s}>{s}</option>)}
          </Select>
          <Link href="/create"><Button><Sparkles className="h-4 w-4" /> New</Button></Link>
        </div>
      </div>

      {items.length === 0 && !loading ? (
        <EmptyState title="No generations yet"
          body="Your generation history will appear here."
          action={<Link href="/create"><Button>Create your first</Button></Link>} />
      ) : (
        <>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {items.map((g) => (
              <Link key={g.id} href={`/generations/${g.id}`}
                className="rounded-xl border border-border bg-surface p-4 transition-micro hover:border-border-strong">
                <div className="flex items-center justify-between gap-2">
                  <Badge tone={STATUS_TONE[g.status] ?? "default"}>{g.status}</Badge>
                  <span className="text-xs text-faint">{g.type.replace(/_/g, " ")}</span>
                </div>
                <p className="mt-3 line-clamp-2 text-sm">{g.prompt}</p>
                <p className="mt-2 text-xs text-faint">{new Date(g.createdAt).toLocaleString()}</p>
              </Link>
            ))}
          </div>
          {cursor && (
            <div className="text-center">
              <Button variant="secondary" onClick={() => load(cursor)} disabled={loading}>
                {loading ? "Loading…" : "Load more"}
              </Button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
