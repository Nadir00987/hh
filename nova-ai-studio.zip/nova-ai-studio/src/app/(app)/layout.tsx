import { redirect } from "next/navigation";
import { auth } from "@/lib/auth";
import { db } from "@/lib/db";
import { Sidebar } from "@/components/shell/sidebar";
import { AppChrome } from "@/components/shell/app-chrome";
import { MobileNavClient } from "@/components/shell/mobile-nav";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const session = await auth();
  if (!session?.user?.id) redirect("/login");

  const [user, balance] = await Promise.all([
    db.user.findUnique({
      where: { id: session.user.id },
      select: { id: true, name: true, email: true, image: true, role: true, suspended: true },
    }),
    db.creditBalance.findUnique({ where: { userId: session.user.id } }),
  ]);
  if (!user || user.suspended) redirect("/login");

  return (
    <div className="flex min-h-screen">
      <Sidebar isAdmin={user.role === "ADMIN"} />
      <div className="flex min-w-0 flex-1 flex-col">
        <AppChrome
          user={{ name: user.name, email: user.email, image: user.image }}
          credits={balance?.available ?? 0}
        />
        <main className="min-w-0 flex-1 px-4 py-6 lg:px-8">{children}</main>
      </div>
      {/* Mobile bottom nav */}
      <nav
        aria-label="Mobile"
        className="fixed inset-x-0 bottom-0 z-30 flex border-t border-border bg-surface/95 backdrop-blur lg:hidden"
      >
        <MobileNavClient />
      </nav>
      <div className="h-16 lg:hidden" /> {/* spacer */}
    </div>
  );
}
