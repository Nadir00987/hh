"use client";

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function SettingsPage() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  useEffect(() => {
    fetch("/api/user/profile")
      .then((r) => r.json())
      .then((j) => {
        if (j.ok) { setName(j.data.name ?? ""); setEmail(j.data.email ?? ""); }
      });
  }, []);

  async function save() {
    setSaving(true);
    setMessage(null);
    try {
      const res = await fetch("/api/user/profile", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: name.trim() || null }),
      });
      const json = await res.json();
      setMessage(json.ok ? "Profile updated." : json.error?.message ?? "Update failed.");
    } catch {
      setMessage("Network error.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="mx-auto max-w-2xl space-y-8">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Settings</h1>
        <p className="mt-1 text-muted">Manage your account.</p>
      </div>

      <div className="rounded-xl border border-border bg-surface p-6 space-y-4">
        <h2 className="font-semibold">Profile</h2>
        <div>
          <label htmlFor="name" className="mb-1.5 block text-sm font-medium">Name</label>
          <Input id="name" value={name} onChange={(e) => setName(e.target.value)} />
        </div>
        <div>
          <label htmlFor="email" className="mb-1.5 block text-sm font-medium">Email</label>
          <Input id="email" value={email} disabled className="opacity-60" />
          <p className="mt-1 text-xs text-faint">Email changes require verification — contact support.</p>
        </div>
        {message && <p className="text-sm text-muted">{message}</p>}
        <Button onClick={save} loading={saving}>Save changes</Button>
      </div>

      <div className="rounded-xl border border-border bg-surface p-6">
        <h2 className="font-semibold">Billing</h2>
        <p className="mt-1 text-sm text-muted">
          Credits power every generation. View your balance and purchase history.
        </p>
        <a href="/settings/billing" className="mt-3 inline-block text-sm text-primary hover:underline">
          Go to billing →
        </a>
      </div>
    </div>
  );
}
