"use client";

import { useEffect, useState } from "react";
import { Badge } from "@/components/ui/badge";

interface Balance { available: number; reserved: number; lifetime: number }
interface LedgerRow {
  id: string; amount: number; type: string; reason: string; createdAt: string;
  generationId: string | null;
}

const TYPE_TONE: Record<string, "success" | "error" | "warning" | "default"> = {
  GRANT: "success", CHARGE: "error", REFUND: "success", RELEASE: "warning",
  RESERVE: "warning", ADJUST: "default",
};

export default function BillingPage() {
  const [balance, setBalance] = useState<Balance | null>(null);
  const [rows, setRows] = useState<LedgerRow[]>([]);

  useEffect(() => {
    fetch("/api/credits").then((r) => r.json()).then((j) => {
      if (j.ok) setBalance(j.data);
    });
    fetch("/api/credits?ledger=1&limit=50").then((r) => r.json()).then((j) => {
      if (j.ok) setRows(j.data.items);
    });
  }, []);

  return (
    <div className="mx-auto max-w-4xl space-y-8">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Billing & Credits</h1>
        <p className="mt-1 text-muted">Every generation reserves credits up front — failed or cancelled jobs release them back.</p>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div className="rounded-xl border border-border bg-surface p-5">
          <div className="text-sm text-muted">Available</div>
          <div className="mt-1 text-3xl font-bold">{balance?.available ?? "—"}</div>
        </div>
        <div className="rounded-xl border border-border bg-surface p-5">
          <div className="text-sm text-muted">Reserved</div>
          <div className="mt-1 text-3xl font-bold">{balance?.reserved ?? "—"}</div>
        </div>
        <div className="rounded-xl border border-border bg-surface p-5">
          <div className="text-sm text-muted">Lifetime earned</div>
          <div className="mt-1 text-3xl font-bold">{balance?.lifetime ?? "—"}</div>
        </div>
      </div>

      <div className="rounded-xl border border-border bg-surface p-6">
        <h2 className="mb-4 font-semibold">Transaction history</h2>
        {rows.length === 0 ? (
          <p className="text-sm text-muted">No transactions yet.</p>
        ) : (
          <div className="divide-y divide-border">
            {rows.map((r) => (
              <div key={r.id} className="flex items-center justify-between gap-4 py-3">
                <div className="flex items-center gap-3">
                  <Badge tone={TYPE_TONE[r.type] ?? "default"}>{r.type}</Badge>
                  <div>
                    <p className="text-sm">{r.reason}</p>
                    <p className="text-xs text-faint">{new Date(r.createdAt).toLocaleString()}</p>
                  </div>
                </div>
                <span className={`font-mono text-sm ${r.amount >= 0 ? "text-success" : "text-error"}`}>
                  {r.amount >= 0 ? "+" : ""}{r.amount}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="rounded-xl border border-border bg-surface p-6">
        <h2 className="font-semibold">Get more credits</h2>
        <p className="mt-1 text-sm text-muted">
          Credit purchases are handled through Stripe. This deployment doesn&apos;t have
          billing enabled yet — contact your administrator.
        </p>
      </div>
    </div>
  );
}
