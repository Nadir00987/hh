"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress, EmptyState } from "@/components/ui/feedback";
import { ArrowLeft, RotateCcw, XCircle, Download } from "lucide-react";

interface Generation {
  id: string;
  type: string;
  status: string;
  prompt: string;
  model: string;
  provider: string;
  progress: number | null;
  creditsReserved: number;
  creditsCharged: number;
  errorMessage: string | null;
  createdAt: string;
  completedAt: string | null;
  outputAssets: { id: string; kind: string; storageKey: string; mimeType: string }[];
  events: { id: string; fromStatus: string; toStatus: string; message: string | null; createdAt: string }[];
}

const STATUS_TONE: Record<string, "default" | "success" | "warning" | "error" | "info"> = {
  QUEUED: "default", PROCESSING: "info", GENERATING: "info", FINALIZING: "info",
  COMPLETED: "success", FAILED: "error", CANCELLED: "warning",
};

const TERMINAL = ["COMPLETED", "FAILED", "CANCELLED"];

export default function GenerationDetailPage() {
  const params = useParams();
  const router = useRouter();
  const id = params.id as string;
  const [gen, setGen] = useState<Generation | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [acting, setActing] = useState(false);

  useEffect(() => {
    fetch(`/api/generations/${id}`)
      .then((r) => r.json())
      .then((j) => {
        if (j.ok) setGen(j.data);
        else setError(j.error?.message ?? "Not found.");
      })
      .catch(() => setError("Network error."));

    const es = new EventSource(`/api/generations/${id}/events`);
    es.addEventListener("update", (e) => {
      const update = JSON.parse((e as MessageEvent).data);
      setGen((g) => g ? { ...g, status: update.status, progress: update.progress ?? g.progress } : g);
    });
    es.onerror = () => es.close();
    return () => es.close();
  }, [id]);

  async function cancel() {
    if (acting || !confirm("Cancel this generation? Reserved credits will be released.")) return;
    setActing(true);
    try {
      const res = await fetch(`/api/generations/${id}/cancel`, { method: "POST" });
      const json = await res.json();
      if (json.ok) setGen((g) => g ? { ...g, status: "CANCELLED" } : g);
    } finally {
      setActing(false);
    }
  }

  async function retry() {
    if (acting) return;
    setActing(true);
    try {
      const res = await fetch(`/api/generations/${id}/retry`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });
      const json = await res.json();
      if (json.ok) router.push(`/generations/${json.data.id}`);
    } finally {
      setActing(false);
    }
  }

  if (error) {
    return (
      <div className="mx-auto max-w-3xl">
        <EmptyState title="Not found" body={error}
          action={<Link href="/history"><Button variant="secondary">Back to history</Button></Link>} />
      </div>
    );
  }
  if (!gen) return <p className="text-muted">Loading…</p>;

  const isTerminal = TERMINAL.includes(gen.status);

  return (
    <div className="mx-auto max-w-4xl space-y-6">
      <Link href="/history" className="inline-flex items-center gap-2 text-sm text-muted hover:text-foreground">
        <ArrowLeft className="h-4 w-4" /> Back to history
      </Link>

      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <Badge tone={STATUS_TONE[gen.status] ?? "default"}>{gen.status}</Badge>
          <span className="text-sm text-muted">{gen.type.replace(/_/g, " ")}</span>
        </div>
        <div className="flex gap-2">
          {!isTerminal && (
            <Button variant="danger" size="sm" onClick={cancel} disabled={acting}>
              <XCircle className="h-4 w-4" /> Cancel
            </Button>
          )}
          {(gen.status === "FAILED" || gen.status === "CANCELLED") && (
            <Button variant="secondary" size="sm" onClick={retry} disabled={acting}>
              <RotateCcw className="h-4 w-4" /> Retry
            </Button>
          )}
        </div>
      </div>

      {!isTerminal && (
        <div className="rounded-xl border border-border bg-surface p-6">
          <p className="mb-3 text-sm text-muted">
            {gen.status === "QUEUED" ? "Waiting in queue…" : "Working on it…"}
          </p>
          <Progress value={gen.progress} indeterminate={gen.progress == null} />
        </div>
      )}

      {gen.status === "FAILED" && gen.errorMessage && (
        <div className="rounded-xl border border-error/20 bg-error/10 p-6">
          <h3 className="font-semibold text-error">Generation failed</h3>
          <p className="mt-2 text-sm">{gen.errorMessage}</p>
          <p className="mt-2 text-sm text-muted">Reserved credits were released back to your balance.</p>
        </div>
      )}

      {gen.outputAssets.length > 0 && (
        <div className="rounded-xl border border-border bg-surface p-6">
          <h3 className="mb-4 font-semibold">Output</h3>
          <div className="grid gap-4 sm:grid-cols-2">
            {gen.outputAssets.map((a) => (
              <div key={a.id} className="overflow-hidden rounded-lg border border-border">
                {a.kind === "VIDEO" ? (
                  <video src={`/api/assets/file?id=${a.id}`} controls className="w-full" preload="metadata" />
                ) : a.mimeType.startsWith("audio/") ? (
                  <audio src={`/api/assets/file?id=${a.id}`} controls className="w-full" />
                ) : (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={`/api/assets/file?id=${a.id}`} alt="Generated output" className="w-full" />
                )}
                <div className="flex items-center justify-between p-3">
                  <span className="text-xs text-faint">{a.mimeType}</span>
                  <a href={`/api/assets/file?id=${a.id}&download=1`}
                    className="inline-flex items-center gap-1 text-sm text-primary hover:underline">
                    <Download className="h-3.5 w-3.5" /> Download
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="rounded-xl border border-border bg-surface p-6 space-y-3">
        <h3 className="font-semibold">Details</h3>
        <dl className="grid grid-cols-[140px_1fr] gap-2 text-sm">
          <dt className="text-muted">Prompt</dt><dd>{gen.prompt}</dd>
          <dt className="text-muted">Model</dt><dd>{gen.model} <span className="text-faint">({gen.provider})</span></dd>
          <dt className="text-muted">Credits</dt>
          <dd>{gen.creditsCharged > 0 ? `${gen.creditsCharged} charged` : `${gen.creditsReserved} reserved`}</dd>
          <dt className="text-muted">Created</dt><dd>{new Date(gen.createdAt).toLocaleString()}</dd>
          {gen.completedAt && <><dt className="text-muted">Completed</dt><dd>{new Date(gen.completedAt).toLocaleString()}</dd></>}
        </dl>
      </div>

      {gen.events.length > 0 && (
        <div className="rounded-xl border border-border bg-surface p-6">
          <h3 className="mb-4 font-semibold">Timeline</h3>
          <ol className="space-y-2 text-sm">
            {gen.events.map((e) => (
              <li key={e.id} className="flex gap-3">
                <span className="text-faint">{new Date(e.createdAt).toLocaleTimeString()}</span>
                <span>{e.fromStatus} → <strong>{e.toStatus}</strong></span>
                {e.message && <span className="text-muted">{e.message}</span>}
              </li>
            ))}
          </ol>
        </div>
      )}
    </div>
  );
}
