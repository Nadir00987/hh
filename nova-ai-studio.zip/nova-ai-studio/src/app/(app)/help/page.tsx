export default function HelpPage() {
  const faqs = [
    {
      q: "How do credits work?",
      a: "Every generation reserves credits before it starts. When the job completes successfully, the reservation is charged. If it fails or you cancel it, the credits are released back to your balance automatically.",
    },
    {
      q: "Why does my generation say a provider is not configured?",
      a: "NOVA connects to real AI providers (like Replicate). Your administrator needs to add the provider's API key to the server environment. Unconfigured models are clearly marked — we never fake a generation.",
    },
    {
      q: "Can I see progress while something generates?",
      a: "Yes. Open any generation to watch live status updates stream in. You'll also get a notification when it completes or fails.",
    },
    {
      q: "What can I do with my outputs?",
      a: "Preview, download, add to projects, and organize everything in your library. Generations keep a full timeline of status changes.",
    },
    {
      q: "Is my content private?",
      a: "Your generations, assets, and projects are visible only to you. Admins can only access what the role explicitly permits, and every admin action is audit-logged.",
    },
  ];

  return (
    <div className="mx-auto max-w-3xl space-y-8">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Help</h1>
        <p className="mt-1 text-muted">Quick answers to common questions.</p>
      </div>
      <div className="space-y-4">
        {faqs.map((f) => (
          <details key={f.q} className="rounded-xl border border-border bg-surface p-5">
            <summary className="cursor-pointer font-semibold">{f.q}</summary>
            <p className="mt-3 text-sm text-muted">{f.a}</p>
          </details>
        ))}
      </div>
    </div>
  );
}
