"use client";

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Select } from "@/components/ui/input";
import { EmptyState } from "@/components/ui/feedback";
import { Download, Image as ImageIcon } from "lucide-react";

interface Asset {
  id: string;
  kind: string;
  filename: string;
  mimeType: string;
  sizeBytes: number;
  createdAt: string;
}

function fmtSize(b: number) {
  if (b > 1e9) return `${(b / 1e9).toFixed(1)} GB`;
  if (b > 1e6) return `${(b / 1e6).toFixed(1)} MB`;
  if (b > 1e3) return `${(b / 1e3).toFixed(0)} KB`;
  return `${b} B`;
}

export default function LibraryPage() {
  const [items, setItems] = useState<Asset[]>([]);
  const [loading, setLoading] = useState(true);
  const [kind, setKind] = useState("");
  const [cursor, setCursor] = useState<string | null>(null);

  async function load(next?: string) {
    setLoading(true);
    try {
      const qs = new URLSearchParams({ limit: "24" });
      if (kind) qs.set("kind", kind);
      if (next) qs.set("cursor", next);
      const res = await fetch(`/api/assets?${qs}`);
      const json = await res.json();
      if (json.ok) {
        setItems((prev) => next ? [...prev, ...json.data.items] : json.data.items);
        setCursor(json.data.nextCursor);
      }
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { setItems([]); load(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [kind]);

  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Library</h1>
          <p className="mt-1 text-muted">All your uploaded and generated assets.</p>
        </div>
        <Select value={kind} onChange={(e) => setKind(e.target.value)} aria-label="Filter by kind">
          <option value="">All kinds</option>
          <option value="IMAGE">Images</option>
          <option value="VIDEO">Videos</option>
          <option value="AUDIO">Audio</option>
        </Select>
      </div>

      {items.length === 0 && !loading ? (
        <EmptyState title="Library is empty" body="Upload inputs or generate media to fill your library."
          icon={<ImageIcon className="h-8 w-8" />} />
      ) : (
        <>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {items.map((a) => (
              <div key={a.id} className="overflow-hidden rounded-xl border border-border bg-surface">
                <div className="aspect-video bg-background">
                  {a.kind === "VIDEO" ? (
                    <video src={`/api/assets/file?id=${a.id}`} className="h-full w-full object-cover" preload="metadata" />
                  ) : a.mimeType.startsWith("audio/") ? (
                    <div className="flex h-full items-center justify-center text-muted">Audio</div>
                  ) : (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={`/api/assets/file?id=${a.id}`} alt={a.filename} className="h-full w-full object-cover" loading="lazy" />
                  )}
                </div>
                <div className="p-3">
                  <p className="truncate text-sm font-medium">{a.filename}</p>
                  <div className="mt-1 flex items-center justify-between text-xs text-faint">
                    <span>{fmtSize(a.sizeBytes)}</span>
                    <a href={`/api/assets/file?id=${a.id}&download=1`}
                      className="inline-flex items-center gap-1 text-primary hover:underline">
                      <Download className="h-3.5 w-3.5" /> Download
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
          {cursor && (
            <div className="text-center">
              <Button variant="secondary" onClick={() => load(cursor)} disabled={loading}>
                {loading ? "Loading…" : "Load more"}
              </Button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
