"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { LayoutTemplate, ArrowRight } from "lucide-react";

interface Template {
  id: string;
  name: string;
  description: string;
  type: string;
  prompt: string;
  category: string;
}

const TEMPLATES: Template[] = [
  {
    id: "cinematic-drone",
    name: "Cinematic Drone Shot",
    description: "Sweeping aerial cinematography with dramatic lighting.",
    type: "TEXT_TO_VIDEO",
    category: "Video",
    prompt: "Cinematic drone shot, slow push-in over a misty mountain valley at golden hour, volumetric light rays through pine trees, 35mm film look, shallow depth of field, epic scale, photorealistic, 24fps",
  },
  {
    id: "product-hero",
    name: "Product Hero Shot",
    description: "Studio-quality product photography style.",
    type: "TEXT_TO_IMAGE",
    category: "Image",
    prompt: "Professional product photography of a premium perfume bottle on reflective black surface, dramatic rim lighting, soft studio glow, ultra-detailed, 8k, commercial advertising style",
  },
  {
    id: "portrait-editorial",
    name: "Editorial Portrait",
    description: "High-fashion editorial portrait style.",
    type: "TEXT_TO_IMAGE",
    category: "Image",
    prompt: "Editorial fashion portrait, dramatic side lighting, textured background, confident expression, shot on medium format film, rich tones, Vogue magazine style",
  },
  {
    id: "lofi-music",
    name: "Lo-fi Background Track",
    description: "Chill lo-fi hip hop instrumental.",
    type: "MUSIC",
    category: "Audio",
    prompt: "Lo-fi hip hop instrumental, warm vinyl crackle, mellow electric piano chords, soft boom-bap drums at 80 BPM, cozy late-night study vibe",
  },
  {
    id: "trailer-voiceover",
    name: "Movie Trailer Voiceover",
    description: "Deep dramatic narration for trailers.",
    type: "TEXT_TO_SPEECH",
    category: "Audio",
    prompt: "In a world where nothing is as it seems, one hero must rise. Deep, dramatic movie trailer narrator voice, slow deliberate pacing, powerful and commanding.",
  },
  {
    id: "startup-pitch-script",
    name: "Startup Pitch Script",
    description: "Compelling 60-second pitch structure.",
    type: "SCRIPT",
    category: "Content",
    prompt: "Write a compelling 60-second startup pitch script. Structure: hook with a surprising statistic, the problem, our unique solution, traction proof points, and a clear call to action for investors.",
  },
];

const CATEGORIES = ["All", "Video", "Image", "Audio", "Content"];

export default function TemplatesPage() {
  const router = useRouter();
  const [category, setCategory] = useState("All");
  const filtered = category === "All" ? TEMPLATES : TEMPLATES.filter((t) => t.category === category);

  function applyTemplate(t: Template) {
    // Store in sessionStorage for the create page to pick up
    sessionStorage.setItem("nova-template", JSON.stringify({ type: t.type, prompt: t.prompt }));
    router.push("/create");
  }

  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Templates</h1>
        <p className="mt-1 text-muted">Battle-tested starting points. One click to the studio.</p>
      </div>

      <div className="flex gap-2">
        {CATEGORIES.map((c) => (
          <button key={c} onClick={() => setCategory(c)}
            className={`rounded-lg border px-3 py-1.5 text-sm transition-micro ${category === c
              ? "border-primary bg-primary-soft text-primary"
              : "border-border text-muted hover:text-foreground"}`}>
            {c}
          </button>
        ))}
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {filtered.map((t) => (
          <div key={t.id} className="flex flex-col rounded-xl border border-border bg-surface p-5">
            <div className="flex items-center justify-between">
              <LayoutTemplate className="h-5 w-5 text-primary" />
              <Badge tone="default">{t.type.replace(/_/g, " ")}</Badge>
            </div>
            <h3 className="mt-3 font-semibold">{t.name}</h3>
            <p className="mt-1 text-sm text-muted">{t.description}</p>
            <p className="mt-3 line-clamp-3 flex-1 rounded-lg bg-background p-3 text-xs text-muted">{t.prompt}</p>
            <Button className="mt-4" variant="secondary" onClick={() => applyTemplate(t)}>
              Use template <ArrowRight className="h-4 w-4" />
            </Button>
          </div>
        ))}
      </div>
    </div>
  );
}
