import Link from "next/link";
import { auth } from "@/lib/auth";
import { db } from "@/lib/db";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { EmptyState } from "@/components/ui/feedback";
import { Sparkles, FolderKanban, Clock, Zap } from "lucide-react";

const STATUS_TONE: Record<string, "default" | "success" | "warning" | "error" | "info"> = {
  QUEUED: "default",
  PROCESSING: "info",
  GENERATING: "info",
  FINALIZING: "info",
  COMPLETED: "success",
  FAILED: "error",
  CANCELLED: "warning",
};

export default async function DashboardPage() {
  const session = await auth();
  const userId = session!.user!.id;

  const [balance, recent, projectCount, activeCount] = await Promise.all([
    db.creditBalance.findUnique({ where: { userId } }),
    db.generation.findMany({
      where: { userId },
      orderBy: { createdAt: "desc" },
      take: 6,
      select: {
        id: true, type: true, status: true, prompt: true, createdAt: true,
        outputAssets: { select: { id: true, storageKey: true, mimeType: true } },
      },
    }),
    db.project.count({ where: { userId } }),
    db.generation.count({ where: { userId, status: { in: ["QUEUED", "PROCESSING", "GENERATING", "FINALIZING"] } } }),
  ]);

  return (
    <div className="mx-auto max-w-6xl space-y-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Dashboard</h1>
          <p className="mt-1 text-muted">Your creative workspace at a glance.</p>
        </div>
        <Link href="/create"><Button><Sparkles className="h-4 w-4" /> New creation</Button></Link>
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div className="rounded-xl border border-border bg-surface p-5">
          <div className="flex items-center gap-2 text-sm text-muted"><Zap className="h-4 w-4" /> Credits</div>
          <div className="mt-2 text-3xl font-bold">{balance?.available ?? 0}</div>
          <Link href="/settings/billing" className="mt-2 inline-block text-sm text-primary hover:underline">Get more</Link>
        </div>
        <div className="rounded-xl border border-border bg-surface p-5">
          <div className="flex items-center gap-2 text-sm text-muted"><Clock className="h-4 w-4" /> Active jobs</div>
          <div className="mt-2 text-3xl font-bold">{activeCount}</div>
          <Link href="/history" className="mt-2 inline-block text-sm text-primary hover:underline">View history</Link>
        </div>
        <div className="rounded-xl border border-border bg-surface p-5">
          <div className="flex items-center gap-2 text-sm text-muted"><FolderKanban className="h-4 w-4" /> Projects</div>
          <div className="mt-2 text-3xl font-bold">{projectCount}</div>
          <Link href="/projects" className="mt-2 inline-block text-sm text-primary hover:underline">Manage</Link>
        </div>
        <div className="rounded-xl border border-border bg-surface p-5">
          <div className="text-sm text-muted">This month</div>
          <div className="mt-2 text-3xl font-bold">{recent.length}</div>
          <div className="mt-2 text-sm text-faint">generations started</div>
        </div>
      </div>

      <div>
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-semibold">Recent generations</h2>
          <Link href="/history" className="text-sm text-primary hover:underline">View all</Link>
        </div>
        {recent.length === 0 ? (
          <EmptyState
            title="Nothing created yet"
            body="Start your first AI generation — video, image, voice, or script."
            action={<Link href="/create"><Button><Sparkles className="h-4 w-4" /> Create</Button></Link>}
          />
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {recent.map((g) => (
              <Link key={g.id} href={`/generations/${g.id}`}
                className="group rounded-xl border border-border bg-surface p-4 transition-micro hover:border-border-strong">
                <div className="flex items-center justify-between gap-2">
                  <Badge tone={STATUS_TONE[g.status] ?? "default"}>{g.status}</Badge>
                  <span className="text-xs text-faint">{g.type.replace(/_/g, " ")}</span>
                </div>
                <p className="mt-3 line-clamp-2 text-sm">{g.prompt}</p>
                <p className="mt-2 text-xs text-faint">{g.createdAt.toLocaleString()}</p>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
