# NOVA AI STUDIO — Technical Architecture

> Production-ready AI Creative Studio SaaS. This document is the single source of
> truth for how the system is designed, before any module is implemented.

## 1. Final Technical Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        CLIENT (Browser)                         │
│  Next.js App Router · React Server Components · Tailwind CSS    │
│  Design-system components · SSE client · Command palette        │
└───────────────┬─────────────────────────────────────────────────┘
                │ HTTPS (signed URLs for media, never proxied blobs)
┌───────────────▼─────────────────────────────────────────────────┐
│                    NEXT.JS SERVER (Node)                        │
│  Route Handlers (`src/app/api/**`) — REST, Zod-validated        │
│  Server Actions for mutations where appropriate                 │
│  Auth.js v5 sessions (JWT, httpOnly cookies)                    │
│  Middleware: auth gate, rate limiting, security headers         │
│  SSE endpoint: /api/generations/:id/events (realtime status)     │
│  Webhook receivers: /api/webhooks/:provider (signed, idempotent) │
└───┬──────────┬──────────────┬───────────────┬────────────────────┘
    │          │              │               │
┌───▼───┐ ┌───▼────┐ ┌───────▼──────┐ ┌──────▼─────────┐
│Postgre│ │ Redis  │ │ S3-compatible│ │ AI Providers   │
│  SQL  │ │ BullMQ │ │   storage    │ │ (server-side)  │
│Prisma │ │ queue  │ │ signed URLs  │ │ pluggable      │
└───────┘ └────────┘ └──────────────┘ └────────────────┘
```

**Stack (per spec §62, no unnecessary tech):**

| Layer      | Choice                                                                 |
|------------|------------------------------------------------------------------------|
| Frontend   | Next.js 14 (App Router), React 18, TypeScript (strict), Tailwind CSS    |
| Backend    | Next.js Route Handlers + a BullMQ worker process (`worker/`)           |
| Database   | PostgreSQL 15+, Prisma ORM (typed, migrations)                         |
| Auth       | Auth.js v5 — email/password (bcrypt), email verification, OAuth stubs  |
| Queue      | Redis + BullMQ (`generation` queue, retries w/ backoff, DLQ)           |
| Realtime   | Server-Sent Events (no extra infra; upgradeable to WS later)           |
| Storage    | S3-compatible (AWS SDK v3) via presigned URLs; local-disk dev adapter  |
| Validation | Zod on every API boundary                                              |
| Rate limit | Redis sliding-window, per-plan limits                                  |
| Tests      | Vitest (unit) + Playwright-ready e2e layout                            |
| Logging    | Structured JSON logs (pino-style), no secret leakage                   |

**Key principles**

- Secrets live only in server env vars; the browser never sees provider keys.
- Every generation is a persisted, auditable DB row with a full lifecycle.
- Credits move only inside DB transactions: reserve → finalize | refund.
- Webhooks are signature-verified and idempotent (stored event IDs).
- The UI never fakes generation: unconfigured providers render an explicit
  "not configured" state with setup guidance.

## 2. Database Schema (summary — full DDL in `prisma/schema.prisma`)

Core tables (per spec §45):

- `users`, `profiles`, `accounts`, `sessions`, `verification_tokens` (Auth.js)
- `plans`, `subscriptions`, `credit_ledger` (append-only), `credit_balances`
- `projects`, `assets` (media files), `project_assets`
- `generations` (the central job record), `generation_attempts`,
  `generation_events` (status timeline), `webhook_events` (idempotency)
- `ai_providers`, `ai_models`, `model_capabilities` (capability-driven UI)
- `prompts`, `prompt_templates`, `templates` (user + curated)
- `notifications`, `usage_events` (analytics), `api_keys` (user keys, hashed),
  `audit_logs`, `admin_users` (role via `users.role`)

Generation status enum: `queued → processing → generating → finalizing →
completed | failed | cancelled`. Terminal states never transition again
(enforced in a single `transitionGeneration()` service).

## 3. Application Folder Structure

```
nova-ai-studio/
├── ARCHITECTURE.md            # this file
├── README.md                  # setup / deployment guide
├── .env.example
├── docker-compose.yml         # postgres + redis for local dev
├── prisma/
│   ├── schema.prisma
│   └── seed.ts                # plans, curated templates, model registry seed
├── worker/
│   └── index.ts               # BullMQ worker: executes generation jobs
├── src/
│   ├── app/
│   │   ├── (marketing)/       # landing, pricing, faq  (public)
│   │   ├── (auth)/            # login, signup, verify, forgot, reset
│   │   ├── (app)/             # authenticated shell
│   │   │   ├── dashboard/
│   │   │   ├── create/        # creation hub
│   │   │   ├── studio/
│   │   │   │   ├── video/     # text/image/video-to-video, extend
│   │   │   │   ├── image/
│   │   │   │   ├── audio/     # tts, sfx, music
│   │   │   │   └── content/   # script, storyboard, prompt studio
│   │   │   ├── projects/ library/ templates/ tools/ history/
│   │   │   ├── settings/ admin/
│   │   │   └── layout.tsx     # sidebar shell
│   │   └── api/
│   │       ├── auth/[...nextauth]/
│   │       ├── generations/   # POST, GET, :id/retry|cancel, :id/events (SSE)
│   │       ├── projects/ assets/ models/ credits/ usage/
│   │       ├── prompts/ templates/ notifications/ search/
│   │       ├── billing/ admin/ share/ export/
│   │       └── webhooks/[provider]/
│   ├── components/
│   │   ├── ui/                # design-system primitives
│   │   ├── studio/            # generation workspace components
│   │   ├── marketing/
│   │   └── providers.tsx
│   ├── lib/
│   │   ├── ai/
│   │   │   ├── types.ts       # VideoProvider, ImageProvider, ... interfaces
│   │   │   ├── registry.ts    # model registry → capabilities → UI
│   │   │   └── providers/
│   │   │       ├── pollinations.ts  # image (works without API key)
│   │   │       ├── replicate.ts     # video/image (REPLICATE_API_TOKEN)
│   │   │       └── openai-compat.ts # text/LLM (OPENAI_API_KEY + BASE_URL)
│   │   ├── auth.ts  db.ts  env.ts  errors.ts  validation.ts
│   │   ├── credits.ts         # reserve / finalize / refund (transactional)
│   │   ├── generations.ts     # lifecycle service (create, transition, retry)
│   │   ├── queue.ts           # BullMQ wrapper + in-process dev fallback
│   │   ├── storage.ts         # S3 presigned URLs + local dev adapter
│   │   ├── realtime.ts        # SSE event bus
│   │   ├── ratelimit.ts  moderation.ts  analytics.ts  security.ts
│   │   └── tokens.ts          # design tokens (TS mirror of CSS vars)
│   ├── hooks/  utils/
│   └── styles/ (or app/globals.css)
├── tests/                     # vitest: credits, validation, adapters, perms
└── docs/                      # provider setup, webhooks, billing, deployment
```

## 4. AI Provider Abstraction

```ts
// src/lib/ai/types.ts
interface GenerationInput {
  prompt: string; negativePrompt?: string;
  modelId: string; settings: Record<string, unknown>;
  inputAssets: { url: string; kind: 'image'|'video'|'audio'; label?: string }[];
  idempotencyKey: string; userId: string;
}
interface ProviderJob { providerJobId: string; status: ProviderStatus; progress?: number; }
interface AIVideoProvider {
  readonly id: string;                       // 'replicate'
  generateVideo(input: GenerationInput): Promise<ProviderJob>;
  getJobStatus(providerJobId: string): Promise<ProviderJob>;
  cancelJob?(providerJobId: string): Promise<void>;
  getCapabilities(): ProviderCapabilities;   // truthful, no invented progress
}
```

- `src/lib/ai/registry.ts` loads `ai_providers` / `ai_models` from the DB
  (seeded from `config/models.json`), each with a typed capabilities object.
- The frontend model selector renders **only** from capabilities: unsupported
  controls are hidden/disabled, never faked.
- Provider SDK calls happen **only** in `worker/` (server). Keys come from
  `process.env`, validated at boot by `src/lib/env.ts` (zod).
- Fallback (§68): if a second provider declares identical capability coverage,
  the worker may fail over and records `provider` on the attempt.

Shipped providers:

| Provider            | Media | Key required | Notes                              |
|---------------------|-------|--------------|------------------------------------|
| `pollinations`      | image | none         | Free tier; real generation, no key |
| `replicate`         | video, image | `REPLICATE_API_TOKEN` | Real async jobs + webhooks |
| `openai-compatible` | text  | `OPENAI_API_KEY` (+ optional `OPENAI_BASE_URL`) | Prompt enhance, scripts |

Anything without credentials renders the §70 "not configured" state.

## 5. Generation-Job Lifecycle

```
User clicks Generate
  → POST /api/generations (zod) → auth, rate-limit, moderation pre-check
  → credits.reserve(userId, cost)            [DB transaction]
  → generations.create(status=queued) + generation_events row
  → queue.add('generate', { generationId }) [BullMQ]
  → 202 { id, status } ; UI subscribes to SSE /api/generations/:id/events

Worker picks up job:
  queued → processing   (validate inputs, upload refs → storage)
       → generating    (provider.generateVideo → providerJobId saved)
       → [poll | webhook] → progress events (only real provider progress)
       → finalizing    (download result → storage → asset row)
       → completed     (credits.finalize, notification, usage_events)
  on error → failed     (credits.refund per policy, error_code mapped to
                         user-friendly message + recovery hints)
  user cancel → cancelled (provider.cancelJob best-effort, refund)

Retries: POST /api/generations/:id/retry creates a NEW attempt row linked to
the same generation (version history); idempotency keys prevent double-charge.
```

SSE: the API route subscribes to a Redis pub/sub channel
`generation:{id}`; the worker publishes transitions. No polling from the
client; no fake percentages — progress bars reflect provider-reported values
or indeterminate state-based steps.

## 6. Design System

CSS custom properties (dark default, light via `[data-theme="light"]`):

`--background --foreground --surface --surface-hover --border --muted
 --primary --primary-hover --success --warning --error --info`

- One brand accent (indigo/violet family, configurable in `tokens.ts`).
- Typography scale: display / h1 / h2 / h3 / body / small / caption / label
  with fixed size·weight·leading·tracking; Inter (system fallback stack).
- Components in `src/components/ui/`: Button, Input, Textarea, Select, Dialog,
  Dropdown, Tooltip, Toast, Tabs, Slider, Progress, Badge, Skeleton, Avatar,
  CommandPalette, Dropzone, VideoPlayer, CompareSlider, EmptyState.
- `prefers-reduced-motion` respected; focus-visible rings everywhere;
  semantic HTML + ARIA on all interactive primitives.
- Responsive: sidebar → collapsed rail → mobile drawer; bottom nav on mobile.

## 7. Security Model (summary of §50/§88)

- Auth.js sessions, httpOnly cookies, CSRF via SameSite + origin check.
- Every data query scoped by `userId` server-side; admin behind `role=admin`
  checked in a `requireAdmin()` helper on every admin route (never UI-only).
- Zod validation on all inputs; file MIME sniffing + size limits; SSRF guard
  on URL fetches (private-IP blocklist); security headers in middleware.
- Webhooks: HMAC signature verify, replay window, idempotency table.
- Rate limits per plan on generations, uploads, auth, prompt-enhance.
- Audit log for admin actions, credit adjustments, sharing changes.

## 8. Deployment

- `docker-compose.yml` for Postgres + Redis locally; production targets any
  Node host (VPS, Render, Railway, Fly) — `next build && next start` plus
  `node worker/index.js` (or `npm run worker`) as a second process.
- Migrations: `prisma migrate deploy`. Env documented in `.env.example`.
- Storage: any S3-compatible endpoint (AWS, R2, MinIO).

Full setup/deployment steps live in `README.md`.
