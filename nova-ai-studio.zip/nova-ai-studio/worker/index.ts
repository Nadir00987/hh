// ─── Generation worker ──────────────────────────────────────────────────────
// Background process: picks up queued generations and drives them through the
// provider lifecycle. Run as a separate process in production:
//
//   npm run worker     (tsx worker/index.ts)
//
// In dev without REDIS_URL the in-process queue calls the same processor.

import { db } from "@/lib/db";
import { getEnv } from "@/lib/env";
import { log } from "@/lib/logger";
import { registerWorker, type GenerationJobData } from "@/lib/queue";
import { transitionGeneration } from "@/lib/generations";
import { getVideoProvider, getImageProvider } from "@/lib/ai/provider-factory";
import { normalizeProviderStatus, type GenerationInput, type ProviderJobState } from "@/lib/ai/types";
import { mapProviderError, toUserFacing } from "@/lib/errors";
import { getStorage, fetchBuffer, storageKey } from "@/lib/storage";
import { publishGenerationEvent } from "@/lib/realtime";

const POLL_INTERVAL_MS = 8_000;
const MAX_JOB_AGE_MS = 60 * 60 * 1000; // 1h — then JOB_EXPIRED

async function resolveReferenceUrls(generationId: string) {
  const gen = await db.generation.findUnique({
    where: { id: generationId },
    include: { inputAssets: true },
  });
  if (!gen) throw new Error("Generation not found");
  const storage = await getStorage();
  return Promise.all(
    gen.inputAssets.map(async (a) => ({
      url: await storage.presignedDownloadUrl(a.storageKey),
      kind: a.kind.toLowerCase() as "image" | "video" | "audio",
    })),
  );
}

async function finalizeOutputs(generationId: string, outputUrls: string[]) {
  const gen = await db.generation.findUnique({ where: { id: generationId } });
  if (!gen) throw new Error("Generation not found");
  const storage = await getStorage();

  await transitionGeneration(generationId, "FINALIZING", { message: "Saving results" });

  const isVideo = gen.type.includes("VIDEO");
  const ext = isVideo ? "mp4" : "png";
  const mime = isVideo ? "video/mp4" : "image/png";

  for (let i = 0; i < outputUrls.length; i++) {
    const url = outputUrls[i];
    const { buffer, contentType } = await fetchBuffer(url);
    const key = storageKey(gen.userId, isVideo ? "video" : "image", `gen-${generationId.slice(0, 8)}-${i}.${ext}`);
    await storage.putBuffer(key, buffer, contentType.startsWith("image/") || contentType.startsWith("video/") ? contentType : mime);
    const asset = await db.asset.create({
      data: {
        userId: gen.userId,
        kind: isVideo ? "VIDEO" : "IMAGE",
        filename: `${gen.type.toLowerCase()}-${generationId.slice(0, 8)}-${i}.${ext}`,
        mimeType: contentType.split(";")[0],
        sizeBytes: buffer.length,
        storageKey: key,
        source: "generation",
      },
    });
    await db.generation.update({
      where: { id: generationId },
      data: { outputAssets: { connect: { id: asset.id } } },
    });
    if (gen.projectId) {
      await db.projectAsset.create({ data: { projectId: gen.projectId, assetId: asset.id } }).catch(() => {});
    }
    await publishGenerationEvent(generationId, { status: "FINALIZING", outputAssetId: asset.id });
  }
}

async function processJob(data: GenerationJobData) {
  const { generationId } = data;
  const gen = await db.generation.findUnique({ where: { id: generationId } });
  if (!gen) {
    log.warn({ generationId }, "job for missing generation — skipping");
    return;
  }
  if (gen.status !== "QUEUED") {
    log.info({ generationId, status: gen.status }, "job not queued — skipping");
    return;
  }
  if (Date.now() - gen.createdAt.getTime() > MAX_JOB_AGE_MS) {
    await transitionGeneration(generationId, "FAILED", {
      errorCode: "JOB_EXPIRED",
      errorMessage: toUserFacing("JOB_EXPIRED").message,
    });
    return;
  }

  const isVideo = gen.type.includes("VIDEO");
  const adapter = isVideo ? getVideoProvider(gen.provider) : getImageProvider(gen.provider);
  if (!adapter) {
    await transitionGeneration(generationId, "FAILED", {
      errorCode: "PROVIDER_NOT_CONFIGURED",
      errorMessage: toUserFacing("PROVIDER_NOT_CONFIGURED").message,
    });
    return;
  }

  // Record this attempt.
  const attemptCount = await db.generationAttempt.count({ where: { generationId } });
  await db.generationAttempt.create({
    data: { generationId, attemptNumber: attemptCount + 1, provider: gen.provider, model: gen.model, status: "PROCESSING" },
  });

  try {
    await transitionGeneration(generationId, "PROCESSING", { message: "Preparing request" });

    const inputAssets = await resolveReferenceUrls(generationId);
    const input: GenerationInput = {
      prompt: gen.prompt,
      negativePrompt: gen.negativePrompt ?? undefined,
      modelId: gen.model,
      settings: (gen.settings ?? {}) as Record<string, unknown>,
      inputAssets,
      idempotencyKey: gen.idempotencyKey,
      userId: gen.userId,
    };

    await transitionGeneration(generationId, "GENERATING", { message: "Submitting to provider" });
    const started: ProviderJobState = isVideo
      ? await (adapter as ReturnType<typeof getVideoProvider>)!.generateVideo(input)
      : await (adapter as ReturnType<typeof getImageProvider>)!.generateImage(input);

    await db.generationAttempt.updateMany({
      where: { generationId, attemptNumber: attemptCount + 1 },
      data: { providerJobId: started.providerJobId, status: "GENERATING" },
    });
    await transitionGeneration(generationId, "GENERATING", {
      providerJobId: started.providerJobId,
      progress: started.progress ?? null,
      message: "Generating",
    });

    // If the provider finished synchronously, finalize now.
    let state = started;
    if (normalizeProviderStatus(state.status) === "completed") {
      await finalizeOutputs(generationId, state.outputUrls ?? []);
      await transitionGeneration(generationId, "COMPLETED", { message: "Generation completed" });
      await notifyUser(gen.userId, generationId, true);
      return;
    }

    // Otherwise poll until terminal (webhooks also update via /api/webhooks/*).
    const deadline = Date.now() + MAX_JOB_AGE_MS;
    while (Date.now() < deadline) {
      await sleep(POLL_INTERVAL_MS);
      const current = await db.generation.findUnique({ where: { id: generationId }, select: { status: true } });
      if (!current || ["COMPLETED", "FAILED", "CANCELLED"].includes(current.status)) return; // webhook or user handled it

      const polled: ProviderJobState = isVideo
        ? await (adapter as ReturnType<typeof getVideoProvider>)!.getJobStatus(state.providerJobId)
        : await (adapter as ReturnType<typeof getImageProvider>)!.getJobStatus(state.providerJobId);
      state = polled;
      const normalized = normalizeProviderStatus(polled.status);

      if (normalized === "completed") {
        await finalizeOutputs(generationId, polled.outputUrls ?? []);
        await transitionGeneration(generationId, "COMPLETED", { message: "Generation completed" });
        await db.generationAttempt.updateMany({
          where: { generationId, attemptNumber: attemptCount + 1 },
          data: { status: "COMPLETED", completedAt: new Date() },
        });
        await notifyUser(gen.userId, generationId, true);
        return;
      }
      if (normalized === "failed" || normalized === "cancelled") {
        const { code } = mapProviderError(new Error(polled.errorMessage ?? "Provider failed"));
        await transitionGeneration(generationId, normalized === "cancelled" ? "CANCELLED" : "FAILED", {
          errorCode: code,
          errorMessage: polled.errorMessage ?? toUserFacing(code).message,
        });
        await notifyUser(gen.userId, generationId, false);
        return;
      }
      // Still running — publish real progress only if the provider gave us a number.
      if (typeof polled.progress === "number") {
        await transitionGeneration(generationId, "GENERATING", { progress: polled.progress });
      }
    }

    await transitionGeneration(generationId, "FAILED", {
      errorCode: "JOB_EXPIRED",
      errorMessage: toUserFacing("JOB_EXPIRED").message,
    });
  } catch (err) {
    const { code, detail } = mapProviderError(err);
    log.error({ generationId, err }, "generation job failed");
    await transitionGeneration(generationId, "FAILED", {
      errorCode: code,
      errorMessage: detail || toUserFacing(code).message,
    }).catch(() => {});
    await db.generationAttempt.updateMany({
      where: { generationId, attemptNumber: attemptCount + 1 },
      data: { status: "FAILED", completedAt: new Date(), errorCode: code, errorMessage: detail },
    }).catch(() => {});
    await notifyUser(gen.userId, generationId, false).catch(() => {});
    throw err; // let BullMQ retry with backoff
  }
}

async function notifyUser(userId: string, generationId: string, success: boolean) {
  await db.notification.create({
    data: {
      userId,
      type: success ? "GENERATION_COMPLETED" : "GENERATION_FAILED",
      title: success ? "Generation completed" : "Generation failed",
      body: success ? "Your media is ready." : "See History for details and retry options.",
      link: `/history/${generationId}`,
    },
  });
}

function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

async function main() {
  getEnv(); // validate at boot
  await registerWorker(processJob);
  log.info("generation worker running");
  // Keep the process alive for the in-process dev queue.
  if (!getEnv().REDIS_URL) {
    setInterval(() => {}, 60_000);
  }
}

main().catch((e) => {
  log.error({ err: e }, "worker crashed");
  process.exit(1);
});
