// ─── Database seed ──────────────────────────────────────────────────────────
// Plans, AI providers + models (from config/models.json), curated templates.
// Run: npx prisma db seed   (see package.json prisma.seed)

import { PrismaClient } from "@prisma/client";
import { readFileSync } from "fs";
import { join } from "path";

const db = new PrismaClient();

async function main() {
  // ── Plans (prices configurable; 0 = not set) ──────────────────────────────
  const plans = [
    { slug: "free", name: "Free", description: "Explore the studio", monthlyCredits: 25, priceCents: 0, interval: "MONTH" as const, rateLimitTier: "free", sortOrder: 0, features: { maxProjects: 3, historyDays: 7 } },
    { slug: "creator", name: "Creator", description: "For regular creators", monthlyCredits: 500, priceCents: 0, interval: "MONTH" as const, rateLimitTier: "creator", sortOrder: 1, features: { maxProjects: 25, historyDays: 90 } },
    { slug: "pro", name: "Pro", description: "For professionals", monthlyCredits: 2000, priceCents: 0, interval: "MONTH" as const, rateLimitTier: "pro", sortOrder: 2, features: { maxProjects: 100, historyDays: 365, priority: true } },
    { slug: "studio", name: "Studio", description: "For teams & high volume", monthlyCredits: 8000, priceCents: 0, interval: "MONTH" as const, rateLimitTier: "studio", sortOrder: 3, features: { maxProjects: 1000, historyDays: 365 * 3, priority: true, api: true } },
  ];
  for (const p of plans) {
    await db.plan.upsert({ where: { slug: p.slug }, update: { ...p }, create: { ...p } });
  }

  // ── Providers + models ────────────────────────────────────────────────────
  const registry = JSON.parse(readFileSync(join(__dirname, "..", "config", "models.json"), "utf8")) as {
    providers: { id: string; name: string; description: string; enabled: boolean }[];
    models: { id: string; providerId: string; name: string; type: string; enabled: boolean; capabilities: unknown; sortOrder: number }[];
  };
  for (const p of registry.providers) {
    await db.aiProvider.upsert({
      where: { id: p.id },
      update: { name: p.name, description: p.description, enabled: p.enabled },
      create: { id: p.id, name: p.name, description: p.description, enabled: p.enabled },
    });
  }
  for (const m of registry.models) {
    await db.aiModel.upsert({
      where: { id: m.id },
      update: { name: m.name, type: m.type as never, enabled: m.enabled, capabilities: m.capabilities as never, sortOrder: m.sortOrder, providerId: m.providerId },
      create: { id: m.id, providerId: m.providerId, name: m.name, type: m.type as never, enabled: m.enabled, capabilities: m.capabilities as never, sortOrder: m.sortOrder },
    });
  }

  // ── Curated prompt templates ──────────────────────────────────────────────
  const templates = [
    {
      title: "Cinematic Product Shot",
      description: "Premium product reveal for ads",
      category: "ads", type: "TEXT_TO_VIDEO",
      structure: "Cinematic product shot of {{product}}, {{environment}}, dramatic {{lighting}} lighting, slow dolly-in camera move, shallow depth of field, ultra-detailed, 4k commercial style",
      settings: { duration: 5, aspectRatio: "16:9" },
    },
    {
      title: "UGC Testimonial Hook",
      description: "First 3 seconds for TikTok/Reels",
      category: "tiktok", type: "SCRIPT",
      structure: "Hook (0-3s): {{hook}}\nProblem: {{problem}}\nSolution: {{product}} — {{benefit}}\nCTA: {{cta}}",
      settings: {},
    },
    {
      title: "YouTube Intro Sequence",
      description: "High-energy channel intro",
      category: "youtube", type: "TEXT_TO_VIDEO",
      structure: "Dynamic intro sequence: {{topic}} exploding into view, energetic camera sweep, bold {{color_scheme}} palette, motion graphics energy, 16:9",
      settings: { duration: 5, aspectRatio: "16:9" },
    },
    {
      title: "Cinematic Portrait",
      description: "Moody character portrait",
      category: "cinematic", type: "TEXT_TO_IMAGE",
      structure: "Cinematic portrait of {{subject}}, {{mood}} atmosphere, Rembrandt lighting, 85mm lens look, shallow depth of field, film grain, ultra detailed",
      settings: { aspectRatio: "3:4" },
    },
  ];
  for (const t of templates) {
    const exists = await db.promptTemplate.findFirst({ where: { title: t.title } });
    if (!exists) {
      await db.promptTemplate.create({ data: { ...t, type: t.type as never, settings: t.settings } });
    }
  }

  console.log("Seed complete: plans, providers, models, templates");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());
