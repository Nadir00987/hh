# NOVA AI STUDIO

A production-ready **AI Video Generator + unified AI Creative Studio SaaS**.

Generate video, images, audio, and content from one workspace — with realtime
progress, honest credit billing (reserve → charge or release), project
organization, and provider-independent AI integrations.

> **No fake generations.** If a provider isn't configured, the UI says so
> clearly instead of simulating success. Every button performs a real action
> or explains why it's unavailable.

---

## Features

- **AI Generation** — Text-to-video, image-to-video, text-to-image, image editing,
  text-to-speech, music, scripts, storyboards via pluggable providers
  (Replicate, Pollinations, OpenAI-compatible)
- **Realtime updates** — Live job status via Server-Sent Events, in-app notifications
- **Honest credits** — Transactional reserve → charge / release / refund semantics.
  Failed or cancelled jobs refund automatically. Full ledger history.
- **Projects & Library** — Organize generations and assets, track version lineage
- **Prompt templates** — Curated starting points, one click to the studio
- **AI tools** — Prompt enhancer, upscaler, background remover, TTS
- **Admin** — User management, credit grants, audit logs
- **Security** — Server-side authorization on every route, rate limiting,
  audit logging, bcrypt passwords, hashed tokens

---

## Tech Stack

- **Frontend:** Next.js 14 (App Router), React 18, TypeScript (strict), Tailwind CSS
- **Backend:** Next.js API routes, Prisma ORM
- **Database:** PostgreSQL
- **Queue:** Redis + BullMQ (production), in-process fallback (development)
- **Auth:** Auth.js v5 (credentials + optional Google/GitHub OAuth)
- **Storage:** S3-compatible (production), local disk (development)
- **Realtime:** Server-Sent Events + Redis pub/sub

---

## Quick Start (Development)

### Prerequisites

- Node.js 20+
- PostgreSQL 15+ (or use Docker)
- Redis (optional — dev falls back to in-process queue)

### 1. Install dependencies

```bash
npm install
```

### 2. Configure environment

```bash
cp .env.example .env
```

Edit `.env` with your values:

```env
DATABASE_URL="postgresql://user:password@localhost:5432/nova"
AUTH_SECRET="generate-with-openssl-rand-base64-32"
APP_URL="http://localhost:3000"

# Optional: AI providers (unconfigured providers show as "not configured")
REPLICATE_API_TOKEN="r8_..."
POLLINATIONS_ENABLED="true"
OPENAI_API_KEY="sk-..."
OPENAI_BASE_URL="https://api.openai.com/v1"

# Optional: production services
REDIS_URL="redis://localhost:6379"
STORAGE_ENDPOINT="https://s3.amazonaws.com"
STORAGE_BUCKET="nova-assets"
STORAGE_ACCESS_KEY="..."
STORAGE_SECRET_KEY="..."

# Optional: email (dev logs emails to console without SMTP)
SMTP_HOST="smtp.example.com"
SMTP_PORT="587"
SMTP_USER="..."
SMTP_PASS="..."
EMAIL_FROM="noreply@example.com"

# Optional: OAuth
GOOGLE_CLIENT_ID="..."
GOOGLE_CLIENT_SECRET="..."
```

### 3. Set up the database

```bash
npx prisma migrate dev
npx prisma db seed
```

The seed creates the model registry from `config/models.json` and an admin user
(set `ADMIN_EMAILS` in `.env` to designate admins).

### 4. Run the app

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

### 5. Run the worker (separate terminal)

```bash
npm run worker
```

The worker processes generation jobs from the queue. In development without
Redis, jobs run in-process but the worker still handles provider polling.

---

## Production Deployment

### With Docker (recommended)

```bash
docker compose up --build -d
```

`docker-compose.yml` includes the app, worker, PostgreSQL, and Redis.
Set production env vars in `.env` before deploying.

### Manual deployment

1. **Database:** Provision PostgreSQL 15+. Run `npx prisma migrate deploy`.
2. **Redis:** Provision Redis for BullMQ + SSE pub/sub.
3. **Storage:** Configure S3-compatible storage (`STORAGE_*` vars).
4. **Build:** `npm run build`
5. **Start:** `npm start` (web) + `npm run worker` (job processor)
6. **Env:** Set `NODE_ENV=production`, `AUTH_SECRET`, `APP_URL` to your domain.

### Environment checklist for production

- [ ] `AUTH_SECRET` — strong random value (32+ bytes)
- [ ] `DATABASE_URL` — production Postgres with SSL
- [ ] `REDIS_URL` — production Redis
- [ ] `STORAGE_*` — S3 bucket (never use local disk in production)
- [ ] `APP_URL` — your canonical HTTPS domain
- [ ] Provider keys (`REPLICATE_API_TOKEN`, etc.) — server env only
- [ ] `SMTP_*` — for verification and password-reset emails
- [ ] Review `config/models.json` — disable any unverified model IDs

---

## Project Structure

```
src/
  app/
    (app)/              # Authenticated app pages (dashboard, create, library…)
    (auth)/             # Public auth pages (login, signup, verify…)
    api/                # API routes
      auth/             # signup, verify, forgot/reset password
      generations/      # CRUD + cancel/retry + SSE events
      assets/           # upload, complete, file serving
      credits/          # balance + ledger
      projects/         # project CRUD
      models/           # public model catalog
      prompts/enhance/  # AI prompt enhancement
      user/profile      # profile management
  components/
    ui/                 # Design system primitives
    shell/              # App chrome (sidebar, header, command palette)
  lib/
    ai/                 # Provider adapters + model registry (server-only)
    credits.ts          # Transactional credit ledger
    generations.ts      # Generation lifecycle + state machine
    queue.ts            # BullMQ / in-process queue
    storage.ts          # S3 / local storage adapters
    realtime.ts         # SSE + Redis pub/sub
worker/                 # Standalone job processor
prisma/                 # Schema, migrations, seed
config/models.json      # Centralized model registry
```

---

## API Overview

All `/api/*` routes (except auth endpoints and the public model catalog) require
authentication. Responses are `{ ok: true, data }` or `{ ok: false, error }`.

| Route | Method | Description |
|---|---|---|
| `/api/auth/signup` | POST | Create account (rate-limited) |
| `/api/auth/verify` | POST | Verify email token |
| `/api/auth/forgot-password` | POST | Request reset (no enumeration) |
| `/api/auth/reset-password` | POST | Reset with token |
| `/api/models` | GET | Public model catalog (no keys leak) |
| `/api/generations` | GET/POST | List / create generation |
| `/api/generations/[id]` | GET | Generation detail + timeline |
| `/api/generations/[id]/cancel` | POST | Cancel (releases credits) |
| `/api/generations/[id]/retry` | POST | Retry as new generation |
| `/api/generations/[id]/events` | GET | SSE live updates |
| `/api/credits` | GET | Balance (+ `?ledger=1` for history) |
| `/api/projects` | GET/POST | List / create projects |
| `/api/assets` | GET | List library assets |
| `/api/assets/upload` | POST | Presigned upload URL |
| `/api/assets/complete` | POST | Register uploaded asset |
| `/api/assets/file` | GET | Serve asset (auth + ownership check) |
| `/api/prompts/enhance` | POST | AI prompt enhancement |
| `/api/notifications` | GET/POST | List / mark-read |
| `/api/user/profile` | GET/PATCH | Profile |

---

## Credits System

Credits use **transactional reserve → charge or release** semantics:

1. **Reserve** — When a generation starts, credits are reserved (not yet charged).
   Balance decreases, `reserved` increases, ledger records `RESERVE`.
2. **Charge** — On success, the reservation converts to a charge (`CHARGE`).
3. **Release** — On failure or cancellation, the reservation is released
   (`RELEASE`) — credits return to the available balance.
4. **Refund** — Admin-issued refunds (`REFUND`).
5. **Grant** — Admin or purchase grants (`GRANT`).

All operations are idempotent (via `idempotencyKey`) and run inside Prisma
transactions: balance mutation and ledger write are atomic.

---

## Testing

```bash
npm test          # vitest run
npx tsc --noEmit  # typecheck
npm run build     # production build + lint
```

Tests cover moderation, validation schemas, and the error catalog.
Database-dependent paths (credits, state machine) are validated via
typecheck and require a live Postgres for integration testing.

---

## Security

- Every data API route enforces authentication server-side (`withAuth`)
- User ownership checked on every resource access
- Rate limiting on auth, generation, upload, and AI endpoints
- Passwords hashed with bcrypt; email/reset tokens SHA-256 hashed at rest
- Provider API keys live only in server environment variables — never sent to the client
- Upload validation: MIME allowlist, magic-byte sniffing, size limits
- Audit logging for admin actions
- No fake data: unconfigured providers are clearly labeled, never simulated

---

## License

Proprietary — all rights reserved.
